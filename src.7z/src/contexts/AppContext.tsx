import React, { createContext, useContext, useReducer, ReactNode } from 'react';
import { AppState, AppEvent } from '@/types';
import { useAuth } from './AuthContext';
// import { useWebSocket } from '@/hooks/useWebSocket'; // COMENTADO

// Initial state
const initialState: AppState = {
  notifications: [],
  isOnline: true,
  theme: 'light',
  sidebarOpen: false,
  loading: false
};

// Reducer
const appReducer = (state: AppState, action: AppEvent): AppState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'TOGGLE_SIDEBAR':
      return { ...state, sidebarOpen: !state.sidebarOpen };
    case 'SET_THEME':
      return { ...state, theme: action.payload };
    case 'ADD_NOTIFICATION':
      return { 
        ...state, 
        notifications: [...state.notifications, action.payload] 
      };
    case 'REMOVE_NOTIFICATION':
      return {
        ...state,
        notifications: state.notifications.filter(n => n.id !== action.payload)
      };
    case 'WEBSOCKET_MESSAGE':
      // Processar mensaje de WebSocket cuando esté habilitado
      return state;
    default:
      return state;
  }
};

// Context
interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppEvent>;
  isConnected: boolean;
  sendMessage: (data: any) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const { user } = useAuth();

  // WebSocket COMPLETAMENTE DESHABILITADO
  const isConnected = false;
  const sendMessage = () => {
    console.log('WebSocket disabled - message not sent');
  };

  // TODO: Habilitar WebSocket más tarde
  /*
  const { isConnected, sendMessage } = useWebSocket(
    process.env.REACT_APP_WS_URL || 'ws://localhost:5000',
    {
      onMessage: (data) => {
        dispatch({ type: 'WEBSOCKET_MESSAGE', payload: data });
      },
      onOpen: () => {
        console.log('WebSocket connected');
      },
      onClose: () => {
        console.log('WebSocket disconnected');
      },
      onError: (error) => {
        console.error('WebSocket error:', error);
      }
    }
  );
  */

  const value = {
    state,
    dispatch,
    isConnected,
    sendMessage,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};