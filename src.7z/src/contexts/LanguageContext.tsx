import React, { createContext, useContext, useState, ReactNode } from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface Translations {
  [key: string]: {
    [key: string]: string;
  };
}

const translations: Translations = {
  es: {
    // Errores
    'errors.pageNotFound': '404 - Página no encontrada',
    'errors.pageNotFoundDescription': 'La página que buscas no existe.',
    'errors.backToHome': 'Volver al inicio',
    'errors.searchPackages': 'Buscar paquetes',
    'errors.goBack': 'Volver atrás',
    'errors.needHelp': '¿Necesitas ayuda?',
    'errors.contactSupport': 'Contactar soporte',
    
    // Navegación
    'nav.dashboard': 'Dashboard',
    'nav.packages': 'Paquetes',
    'nav.clients': 'Clientes',
    'nav.tracking': 'Seguimiento',
    'nav.reports': 'Reportes',
    'nav.settings': 'Configuración',
    'nav.help': 'Ayuda',
    'nav.logout': 'Cerrar sesión',
    
    // Autenticación
    'auth.login': 'Iniciar Sesión',
    'auth.register': 'Registrarse',
    'auth.email': 'Email',
    'auth.password': 'Contraseña',
    'auth.confirmPassword': 'Confirmar Contraseña',
    'auth.rememberMe': 'Recordarme',
    'auth.forgotPassword': '¿Olvidaste tu contraseña?',
    'auth.noAccount': '¿No tienes cuenta?',
    'auth.hasAccount': '¿Ya tienes cuenta?',
    
    // Validación
    'validation.required': 'Este campo es requerido',
    'validation.invalidEmail': 'Email inválido',
    'validation.passwordTooShort': 'La contraseña debe tener al menos 6 caracteres',
    'validation.passwordsDoNotMatch': 'Las contraseñas no coinciden',
    
    // Dashboard
    'dashboard.welcome': 'Bienvenido',
    'dashboard.totalPackages': 'Total de Paquetes',
    'dashboard.pendingPackages': 'Paquetes Pendientes',
    'dashboard.deliveredPackages': 'Paquetes Entregados',
    'dashboard.activeClients': 'Clientes Activos',
    
    // Paquetes
    'packages.title': 'Gestión de Paquetes',
    'packages.create': 'Crear Paquete',
    'packages.edit': 'Editar Paquete',
    'packages.trackingNumber': 'Número de Seguimiento',
    'packages.status': 'Estado',
    'packages.client': 'Cliente',
    'packages.destination': 'Destino',
    'packages.weight': 'Peso',
    'packages.actions': 'Acciones',
    
    // Estados
    'status.pending': 'Pendiente',
    'status.inTransit': 'En Tránsito',
    'status.delivered': 'Entregado',
    'status.cancelled': 'Cancelado',
    
    // Botones
    'button.save': 'Guardar',
    'button.cancel': 'Cancelar',
    'button.edit': 'Editar',
    'button.delete': 'Eliminar',
    'button.view': 'Ver',
    'button.create': 'Crear',
    'button.search': 'Buscar',
    'button.submit': 'Enviar',
    
    // Mensajes
    'message.loading': 'Cargando...',
    'message.noData': 'No hay datos disponibles',
    'message.success': 'Operación exitosa',
    'message.error': 'Ha ocurrido un error',
    
    // Común
    'common.yes': 'Sí',
    'common.no': 'No',
    'common.ok': 'OK',
    'common.close': 'Cerrar',
    'common.name': 'Nombre',
    'common.description': 'Descripción',
    'common.date': 'Fecha',
    'common.time': 'Hora',
    'common.total': 'Total',
  },
  en: {
    // English translations (básicas por ahora)
    'errors.pageNotFound': '404 - Page not found',
    'errors.pageNotFoundDescription': 'The page you are looking for does not exist.',
    'errors.backToHome': 'Back to home',
    'nav.dashboard': 'Dashboard',
    'nav.packages': 'Packages',
    'nav.clients': 'Clients',
    'auth.login': 'Login',
    'auth.register': 'Register',
    // ... más traducciones en inglés según necesites
  }
};

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string, params?: Record<string, any>) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useLocalStorage('language', 'es');

  const t = (key: string, params?: Record<string, any>) => {
    const keys = key.split('.');
    let value: any = translations[language];
    
    for (const k of keys) {
      if (value && typeof value === 'object') {
        value = value[k];
      } else {
        // Si no encuentra la traducción, devolver la clave
        return key;
      }
    }
    
    if (typeof value === 'string') {
      // Reemplazar parámetros si los hay
      if (params) {
        return value.replace(/\{(\w+)\}/g, (match, paramKey) => {
          return params[paramKey] !== undefined ? String(params[paramKey]) : match;
        });
      }
      return value;
    }
    
    // Si no encuentra la traducción, devolver la clave
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};