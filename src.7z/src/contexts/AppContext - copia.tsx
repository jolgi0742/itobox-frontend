import React, { createContext, useContext, useReducer, useEffect, ReactNode } from 'react';
import { AppState, AppEvent } from '@/types';
import { useAuth } from './AuthContext';
import { useWebSocket } from '../hooks/useWebSocket';

// Initial state
const initialState: AppState = {
  auth: {
    user: null,
    token: null,
    refreshToken: null,
    isAuthenticated: false,
    isLoading: true,
    error: null
  },
  packages: {
    items: [],
    selectedPackage: null,
    filters: {},
    sort: { field: 'createdAt', direction: 'desc' },
    pagination: { page: 1, pageSize: 10, totalItems: 0, totalPages: 0 },
    isLoading: false,
    error: null
  },
  clients: {
    items: [],
    selectedClient: null,
    isLoading: false,
    error: null
  },
  notifications: {
    items: [],
    unreadCount: 0,
    isLoading: false,
    error: null
  },
  ui: {
    sidebarOpen: true,
    mobileMenuOpen: false,
    theme: 'light',
    language: 'es',
    isLoading: false
  }
};

// Action types
type AppAction = 
  | { type: 'SET_LOADING'; payload: { module: keyof AppState; loading: boolean } }
  | { type: 'SET_ERROR'; payload: { module: keyof AppState; error: string | null } }
  | { type: 'SET_SIDEBAR_OPEN'; payload: boolean }
  | { type: 'SET_MOBILE_MENU_OPEN'; payload: boolean }
  | { type: 'SET_THEME'; payload: 'light' | 'dark' }
  | { type: 'SET_LANGUAGE'; payload: string }
  | { type: 'WEBSOCKET_MESSAGE'; payload: any }
  | { type: 'RESET_STATE' };

// Reducer
const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'SET_LOADING':
      return {
        ...state,
        [action.payload.module]: {
          ...state[action.payload.module],
          isLoading: action.payload.loading
        }
      };

    case 'SET_ERROR':
      return {
        ...state,
        [action.payload.module]: {
          ...state[action.payload.module],
          error: action.payload.error
        }
      };

    case 'SET_SIDEBAR_OPEN':
      return {
        ...state,
        ui: { ...state.ui, sidebarOpen: action.payload }
      };

    case 'SET_MOBILE_MENU_OPEN':
      return {
        ...state,
        ui: { ...state.ui, mobileMenuOpen: action.payload }
      };

    case 'SET_THEME':
      return {
        ...state,
        ui: { ...state.ui, theme: action.payload }
      };

    case 'SET_LANGUAGE':
      return {
        ...state,
        ui: { ...state.ui, language: action.payload }
      };

    case 'WEBSOCKET_MESSAGE':
      // Handle real-time updates
      return handleWebSocketMessage(state, action.payload);

    case 'RESET_STATE':
      return initialState;

    default:
      return state;
  }
};

// WebSocket completamente deshabilitado durante desarrollo
const isConnected = false;
const sendMessage = () => console.log('WebSocket disabled');

// TODO: Habilitar WebSocket más tarde
/*
const { isConnected, sendMessage } = useWebSocket(
  process.env.REACT_APP_WS_URL || 'ws://localhost:5000',
  {
    onMessage: (data) => {
      dispatch({ type: 'WEBSOCKET_MESSAGE', payload: data });
    },
    onOpen: () => {
      console.log('WebSocket connected');
    },
    onClose: () => {
      console.log('WebSocket disconnected');
    },
    onError: (error) => {
      console.error('WebSocket error:', error);
    }
  }
);
*/

// WebSocket message handler
const handleWebSocketMessage = (state: AppState, message: any): AppState => {
  switch (message.type) {
    case 'PACKAGE_UPDATE':
      return {
        ...state,
        packages: {
          ...state.packages,
          items: state.packages.items.map(pkg =>
            pkg.id === message.data.id ? { ...pkg, ...message.data } : pkg
          )
        }
      };

    case 'NEW_NOTIFICATION':
      return {
        ...state,
        notifications: {
          ...state.notifications,
          items: [message.data, ...state.notifications.items],
          unreadCount: state.notifications.unreadCount + 1
        }
      };

    case 'TRACKING_UPDATE':
      return {
        ...state,
        packages: {
          ...state.packages,
          items: state.packages.items.map(pkg =>
            pkg.trackingNumber === message.data.trackingNumber
              ? { ...pkg, status: message.data.status, trackingEvents: [...pkg.trackingEvents, message.data.event] }
              : pkg
          )
        }
      };

    default:
      return state;
  }
};

interface AppContextType {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  setSidebarOpen: (open: boolean) => void;
  setMobileMenuOpen: (open: boolean) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  setLanguage: (language: string) => void;
  setLoading: (module: keyof AppState, loading: boolean) => void;
  setError: (module: keyof AppState, error: string | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const { isAuthenticated } = useAuth();

  // WebSocket connection for real-time updates
  const { sendMessage } = useWebSocket(
    process.env.REACT_APP_WS_URL || 'ws://localhost:5000',
    {
      onMessage: (data) => {
        dispatch({ type: 'WEBSOCKET_MESSAGE', payload: data });
      },
      onOpen: () => {
        console.log('WebSocket connected');
      },
      onClose: () => {
        console.log('WebSocket disconnected');
      },
      onError: (error) => {
        console.error('WebSocket error:', error);
      }
    }
  );

  // Helper functions
  const setSidebarOpen = (open: boolean) => {
    dispatch({ type: 'SET_SIDEBAR_OPEN', payload: open });
  };

  const setMobileMenuOpen = (open: boolean) => {
    dispatch({ type: 'SET_MOBILE_MENU_OPEN', payload: open });
  };

  const setTheme = (theme: 'light' | 'dark') => {
    dispatch({ type: 'SET_THEME', payload: theme });
  };

  const setLanguage = (language: string) => {
    dispatch({ type: 'SET_LANGUAGE', payload: language });
  };

  const setLoading = (module: keyof AppState, loading: boolean) => {
    dispatch({ type: 'SET_LOADING', payload: { module, loading } });
  };

  const setError = (module: keyof AppState, error: string | null) => {
    dispatch({ type: 'SET_ERROR', payload: { module, error } });
  };

  // Auto-close mobile menu on larger screens
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 768 && state.ui.mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [state.ui.mobileMenuOpen]);

  // Reset state on logout
  useEffect(() => {
    if (!isAuthenticated) {
      dispatch({ type: 'RESET_STATE' });
    }
  }, [isAuthenticated]);

  return (
    <AppContext.Provider value={{
      state,
      dispatch,
      setSidebarOpen,
      setMobileMenuOpen,
      setTheme,
      setLanguage,
      setLoading,
      setError
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};