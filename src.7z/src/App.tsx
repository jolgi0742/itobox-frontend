import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ErrorBoundary } from '@/components/layout/ErrorBoundary';
import { LoadingScreen } from '@/components/layout/LoadingScreen';
import { AppProviders } from '@/contexts';
import { useAuth } from '@/hooks/useAuth';

// Pages
import DashboardPage from '@/pages/DashboardPage';

// Auth Components
import { LoginForm } from '@/modules/auth/components/LoginForm';

console.log('📄 App.tsx cargando...');

// Componente para rutas protegidas
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  console.log('🛡️ ProtectedRoute renderizando...');
  
  const { user, isLoading } = useAuth();

  console.log('🛡️ ProtectedRoute - Usuario:', user);
  console.log('🛡️ ProtectedRoute - Loading:', isLoading);
  console.log('🛡️ ProtectedRoute - User exists:', !!user);

  if (isLoading) {
    console.log('⏳ ProtectedRoute - Mostrando loading...');
    return <LoadingScreen message="Verificando autenticación..." />;
  }

  if (!user) {
    console.log('❌ ProtectedRoute - No user, redirigiendo a login');
    return <Navigate to="/auth/login" replace />;
  }

  console.log('✅ ProtectedRoute - Usuario autenticado, mostrando contenido');
  return <>{children}</>;
};

// Componente para rutas públicas (cuando ya está autenticado, redirigir)
const PublicRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  console.log('🌐 PublicRoute renderizando...');
  
  const { user, isLoading } = useAuth();

  console.log('🌐 PublicRoute - Usuario:', user);
  console.log('🌐 PublicRoute - Loading:', isLoading);

  if (isLoading) {
    console.log('⏳ PublicRoute - Mostrando loading...');
    return <LoadingScreen message="Cargando..." />;
  }

  if (user) {
    console.log('✅ PublicRoute - Usuario ya autenticado, redirigiendo a dashboard');
    return <Navigate to="/dashboard" replace />;
  }

  console.log('🌐 PublicRoute - No hay usuario, mostrando contenido público');
  return <>{children}</>;
};

// Componente de Login Page
const LoginPage = () => {
  console.log('🔐 LoginPage renderizando...');
  
  return (
    <PublicRoute>
      <div style={{ 
        minHeight: '100vh', 
        background: '#f5f5f5', 
        padding: '20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <div>
          <div style={{ textAlign: 'center', marginBottom: '30px' }}>
            <h1 style={{ fontSize: '2rem', color: '#333', marginBottom: '10px' }}>
              🚀 ITOBOX Courier
            </h1>
            <p style={{ color: '#666' }}>
              Sistema de Gestión de Paquetes y Envíos
            </p>
          </div>
          <LoginForm />
        </div>
      </div>
    </PublicRoute>
  );
};

// Componente de Dashboard protegido
const ProtectedDashboard = () => {
  console.log('📊 ProtectedDashboard renderizando...');
  
  return (
    <ProtectedRoute>
      <DashboardPage />
    </ProtectedRoute>
  );
};

// Componente principal de rutas
const AppRoutes = () => {
  console.log('🛣️ AppRoutes renderizando...');
  
  return (
    <Routes>
      {/* Ruta raíz - redirigir según autenticación */}
      <Route 
        path="/" 
        element={<Navigate to="/dashboard" replace />} 
      />
      
      {/* Rutas de autenticación */}
      <Route 
        path="/auth/login" 
        element={<LoginPage />} 
      />
      
      {/* Dashboard protegido */}
      <Route 
        path="/dashboard" 
        element={<ProtectedDashboard />}
      />
      
      {/* Páginas adicionales protegidas */}
      <Route 
        path="/packages" 
        element={
          <ProtectedRoute>
            <div style={{ padding: '50px', textAlign: 'center' }}>
              <h1>📦 Gestión de Paquetes</h1>
              <p>Página en desarrollo...</p>
            </div>
          </ProtectedRoute>
        } 
      />
      
      <Route 
        path="/clients" 
        element={
          <ProtectedRoute>
            <div style={{ padding: '50px', textAlign: 'center' }}>
              <h1>👥 Gestión de Clientes</h1>
              <p>Página en desarrollo...</p>
            </div>
          </ProtectedRoute>
        } 
      />
      
      {/* Ruta 404 */}
      <Route 
        path="*" 
        element={
          <div style={{ 
            padding: '50px', 
            textAlign: 'center',
            minHeight: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'column'
          }}>
            <h1 style={{ fontSize: '4rem', color: '#666' }}>404</h1>
            <p style={{ fontSize: '1.2rem', color: '#888', marginBottom: '20px' }}>
              Página no encontrada
            </p>
            <button 
              onClick={() => window.location.href = '/dashboard'}
              style={{
                padding: '10px 20px',
                backgroundColor: '#007bff',
                color: 'white',
                border: 'none',
                borderRadius: '5px',
                cursor: 'pointer'
              }}
            >
              Ir al Dashboard
            </button>
          </div>
        } 
      />
    </Routes>
  );
};

// Componente wrapper con providers
const AppWithProviders = () => {
  console.log('🏗️ AppWithProviders renderizando...');
  
  return (
    <AppProviders>
      <Router>
        <AppRoutes />
      </Router>
    </AppProviders>
  );
};

// Componente principal de la aplicación
function App() {
  console.log('🚀 App component renderizando...');
  
  return (
    <ErrorBoundary>
      <AppWithProviders />
    </ErrorBoundary>
  );
}

export default App;