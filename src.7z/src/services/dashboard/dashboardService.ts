import { DashboardMetrics, ChartData } from '@/types';
import { apiClient } from '../api/apiClient';

class DashboardService {
  async getMetrics(timeRange: 'day' | 'week' | 'month' | 'year' = 'month'): Promise<DashboardMetrics> {
    return apiClient.get<DashboardMetrics>(`/dashboard/metrics?timeRange=${timeRange}`);
  }

  async getRevenueChart(timeRange: string): Promise<ChartData[]> {
    return apiClient.get<ChartData[]>(`/dashboard/revenue-chart?timeRange=${timeRange}`);
  }

  async getPackageStatusChart(): Promise<ChartData[]> {
    return apiClient.get<ChartData[]>('/dashboard/package-status-chart');
  }

  async getCourierPerformanceChart(): Promise<ChartData[]> {
    return apiClient.get<ChartData[]>('/dashboard/courier-performance-chart');
  }

  async getRecentActivities(limit: number = 10): Promise<any[]> {
    return apiClient.get<any[]>(`/dashboard/recent-activities?limit=${limit}`);
  }

  async getAlerts(): Promise<any[]> {
    return apiClient.get<any[]>('/dashboard/alerts');
  }

  async getSystemHealth(): Promise<any> {
    return apiClient.get('/dashboard/system-health');
  }

  async exportMetrics(format: 'csv' | 'pdf' | 'excel', timeRange: string): Promise<Blob> {
    const response = await apiClient.instance.get(`/dashboard/export?format=${format}&timeRange=${timeRange}`, {
      responseType: 'blob'
    });
    return response.data;
  }
}

export const dashboardService = new DashboardService();