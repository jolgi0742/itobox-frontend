// services/ClientService.js
import PackageService from './PackageService';

class ClientService {
  constructor() {
    this.STORAGE_KEY = 'itobox_clients';
    this.COUNTER_KEY = 'itobox_client_counter';
  }

  // Generar código de cliente único
  generateClientCode() {
    const counter = this.getNextCounter();
    return `CLI-${counter.toString().padStart(6, '0')}`;
  }

  // Obtener siguiente número de contador
  getNextCounter() {
    const current = parseInt(localStorage.getItem(this.COUNTER_KEY) || '0');
    const next = current + 1;
    localStorage.setItem(this.COUNTER_KEY, next.toString());
    return next;
  }

  // Obtener todos los clientes
  getAllClients() {
    try {
      const clients = localStorage.getItem(this.STORAGE_KEY);
      return clients ? JSON.parse(clients) : [];
    } catch (error) {
      console.error('Error loading clients:', error);
      return [];
    }
  }

  // Obtener cliente por ID
  getClientById(id) {
    const clients = this.getAllClients();
    return clients.find(client => client.id === id);
  }

  // Obtener cliente por código
  getClientByCode(clientCode) {
    const clients = this.getAllClients();
    return clients.find(client => client.clientCode === clientCode);
  }

  // Obtener cliente por email
  getClientByEmail(email) {
    const clients = this.getAllClients();
    return clients.find(client => client.personalInfo.email.toLowerCase() === email.toLowerCase());
  }

  // Buscar clientes por término
  searchClients(searchTerm) {
    const clients = this.getAllClients();
    const term = searchTerm.toLowerCase();
    
    return clients.filter(client => 
      client.personalInfo.fullName.toLowerCase().includes(term) ||
      client.personalInfo.email.toLowerCase().includes(term) ||
      client.personalInfo.phone.includes(term) ||
      client.clientCode.toLowerCase().includes(term) ||
      (client.businessInfo.companyName && client.businessInfo.companyName.toLowerCase().includes(term))
    );
  }

  // Crear nuevo cliente
  createClient(clientData) {
    try {
      const clients = this.getAllClients();
      
      // Verificar email duplicado
      if (this.getClientByEmail(clientData.personalInfo.email)) {
        throw new Error('Ya existe un cliente con este email');
      }

      const newClient = {
        id: this.generateId(),
        clientCode: this.generateClientCode(),
        personalInfo: {
          ...clientData.personalInfo,
          fullName: `${clientData.personalInfo.firstName} ${clientData.personalInfo.lastName}`.trim()
        },
        contactInfo: {
          primaryAddress: clientData.contactInfo.primaryAddress,
          alternativeAddresses: clientData.contactInfo.alternativeAddresses || [],
          emergencyContact: clientData.contactInfo.emergencyContact || {}
        },
        businessInfo: {
          isCompany: clientData.businessInfo?.isCompany || false,
          companyName: clientData.businessInfo?.companyName || '',
          taxId: clientData.businessInfo?.taxId || '',
          industry: clientData.businessInfo?.industry || '',
          employeeCount: clientData.businessInfo?.employeeCount || 0,
          website: clientData.businessInfo?.website || ''
        },
        accountInfo: {
          status: 'active',
          customerType: clientData.accountInfo?.customerType || 'individual',
          creditLimit: clientData.accountInfo?.creditLimit || 0,
          paymentTerms: clientData.accountInfo?.paymentTerms || 'immediate',
          preferredPaymentMethod: clientData.accountInfo?.preferredPaymentMethod || 'cash',
          discountRate: this.calculateInitialDiscount(clientData.accountInfo?.customerType || 'individual'),
          loyaltyPoints: 0
        },
        preferences: {
          communicationMethod: clientData.preferences?.communicationMethod || 'email',
          newsletterSubscribed: clientData.preferences?.newsletterSubscribed || false,
          language: clientData.preferences?.language || 'es',
          timezone: clientData.preferences?.timezone || 'America/Costa_Rica',
          specialInstructions: clientData.preferences?.specialInstructions || ''
        },
        statistics: {
          totalPackages: 0,
          totalSpent: 0,
          averagePackageValue: 0,
          lastOrderDate: null,
          favoriteServices: [],
          satisfactionRating: 0
        },
        dates: {
          created: new Date().toISOString(),
          lastModified: new Date().toISOString(),
          lastActivity: null
        },
        notes: clientData.notes || '',
        tags: clientData.tags || []
      };

      clients.push(newClient);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(clients));
      return newClient;
    } catch (error) {
      console.error('Error creating client:', error);
      throw error;
    }
  }

  // Actualizar cliente
  updateClient(id, updateData) {
    try {
      const clients = this.getAllClients();
      const index = clients.findIndex(client => client.id === id);
      
      if (index === -1) {
        throw new Error('Cliente no encontrado');
      }

      // Verificar email duplicado (excluyendo el cliente actual)
      if (updateData.personalInfo?.email) {
        const existingClient = this.getClientByEmail(updateData.personalInfo.email);
        if (existingClient && existingClient.id !== id) {
          throw new Error('Ya existe un cliente con este email');
        }
      }

      // Actualizar fullName si se proporcionan firstName o lastName
      if (updateData.personalInfo?.firstName || updateData.personalInfo?.lastName) {
        const currentPersonalInfo = clients[index].personalInfo;
        const firstName = updateData.personalInfo?.firstName || currentPersonalInfo.firstName;
        const lastName = updateData.personalInfo?.lastName || currentPersonalInfo.lastName;
        updateData.personalInfo = {
          ...updateData.personalInfo,
          fullName: `${firstName} ${lastName}`.trim()
        };
      }

      clients[index] = {
        ...clients[index],
        ...updateData,
        dates: {
          ...clients[index].dates,
          lastModified: new Date().toISOString()
        }
      };

      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(clients));
      return clients[index];
    } catch (error) {
      console.error('Error updating client:', error);
      throw error;
    }
  }

  // Eliminar cliente
  deleteClient(id) {
    try {
      const clients = this.getAllClients();
      
      // Verificar si el cliente tiene paquetes asociados
      const packages = PackageService.getAllPackages();
      const hasPackages = packages.some(pkg => pkg.clientId === id);
      
      if (hasPackages) {
        throw new Error('No se puede eliminar un cliente que tiene paquetes asociados');
      }

      const filteredClients = clients.filter(client => client.id !== id);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredClients));
      return true;
    } catch (error) {
      console.error('Error deleting client:', error);
      throw error;
    }
  }

  // Cambiar estado del cliente
  updateClientStatus(id, newStatus) {
    try {
      return this.updateClient(id, {
        accountInfo: {
          ...this.getClientById(id).accountInfo,
          status: newStatus
        }
      });
    } catch (error) {
      console.error('Error updating client status:', error);
      throw error;
    }
  }

  // Obtener historial de paquetes del cliente
  getClientPackages(clientId) {
    const packages = PackageService.getAllPackages();
    return packages.filter(pkg => pkg.clientId === clientId)
                  .sort((a, b) => new Date(b.dates.created) - new Date(a.dates.created));
  }

  // Actualizar estadísticas del cliente
  updateClientStatistics(clientId) {
    try {
      const client = this.getClientById(clientId);
      if (!client) return;

      const packages = this.getClientPackages(clientId);
      const totalSpent = packages.reduce((sum, pkg) => sum + (pkg.cost || 0), 0);
      const deliveredPackages = packages.filter(pkg => pkg.status === 'delivered');
      
      // Calcular servicios favoritos
      const serviceCount = packages.reduce((acc, pkg) => {
        const priority = pkg.packageDetails.priority;
        acc[priority] = (acc[priority] || 0) + 1;
        return acc;
      }, {});
      
      const favoriteServices = Object.entries(serviceCount)
        .sort(([,a], [,b]) => b - a)
        .map(([service]) => service);

      const statistics = {
        totalPackages: packages.length,
        totalSpent,
        averagePackageValue: packages.length > 0 ? totalSpent / packages.length : 0,
        lastOrderDate: packages.length > 0 ? packages[0].dates.created : null,
        favoriteServices,
        satisfactionRating: client.statistics.satisfactionRating // Mantener rating actual
      };

      // Actualizar puntos de fidelidad (1 punto por cada $1 gastado)
      const loyaltyPoints = Math.floor(totalSpent);

      // Determinar tipo de cliente basado en estadísticas
      const newCustomerType = this.calculateCustomerType(statistics);

      return this.updateClient(clientId, {
        statistics,
        accountInfo: {
          ...client.accountInfo,
          loyaltyPoints,
          customerType: newCustomerType,
          discountRate: this.calculateDiscount(newCustomerType, statistics)
        },
        dates: {
          ...client.dates,
          lastActivity: new Date().toISOString()
        }
      });
    } catch (error) {
      console.error('Error updating client statistics:', error);
      throw error;
    }
  }

  // Filtrar clientes
  filterClients(filters = {}) {
    let clients = this.getAllClients();

    if (filters.status) {
      clients = clients.filter(client => client.accountInfo.status === filters.status);
    }

    if (filters.customerType) {
      clients = clients.filter(client => client.accountInfo.customerType === filters.customerType);
    }

    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      clients = clients.filter(client => 
        client.personalInfo.fullName.toLowerCase().includes(searchTerm) ||
        client.personalInfo.email.toLowerCase().includes(searchTerm) ||
        client.clientCode.toLowerCase().includes(searchTerm) ||
        (client.businessInfo.companyName && client.businessInfo.companyName.toLowerCase().includes(searchTerm))
      );
    }

    if (filters.dateFrom) {
      clients = clients.filter(client => 
        new Date(client.dates.created) >= new Date(filters.dateFrom)
      );
    }

    if (filters.dateTo) {
      clients = clients.filter(client => 
        new Date(client.dates.created) <= new Date(filters.dateTo)
      );
    }

    if (filters.hasActivity) {
      clients = clients.filter(client => client.statistics.totalPackages > 0);
    }

    return clients;
  }

  // Obtener estadísticas generales de clientes
  getClientStats() {
    const clients = this.getAllClients();
    const today = new Date().toDateString();
    const thisMonth = new Date().getMonth();
    const thisYear = new Date().getFullYear();

    const stats = {
      total: clients.length,
      active: 0,
      inactive: 0,
      suspended: 0,
      newToday: 0,
      newThisMonth: 0,
      byType: {},
      topSpenders: [],
      totalRevenue: 0,
      averageSpent: 0
    };

    let totalSpent = 0;

    clients.forEach(client => {
      // Contar por estado
      stats[client.accountInfo.status]++;

      // Contar por tipo
      stats.byType[client.accountInfo.customerType] = 
        (stats.byType[client.accountInfo.customerType] || 0) + 1;

      // Clientes nuevos
      const createdDate = new Date(client.dates.created);
      if (createdDate.toDateString() === today) {
        stats.newToday++;
      }
      if (createdDate.getMonth() === thisMonth && createdDate.getFullYear() === thisYear) {
        stats.newThisMonth++;
      }

      totalSpent += client.statistics.totalSpent;
    });

    stats.totalRevenue = totalSpent;
    stats.averageSpent = clients.length > 0 ? totalSpent / clients.length : 0;

    // Top 5 clientes que más gastan
    stats.topSpenders = clients
      .filter(client => client.statistics.totalSpent > 0)
      .sort((a, b) => b.statistics.totalSpent - a.statistics.totalSpent)
      .slice(0, 5)
      .map(client => ({
        id: client.id,
        name: client.personalInfo.fullName,
        spent: client.statistics.totalSpent,
        packages: client.statistics.totalPackages
      }));

    return stats;
  }

  // Utilidades privadas
  generateId() {
    return 'client_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  calculateInitialDiscount(customerType) {
    const discounts = {
      individual: 0,
      business: 5,
      premium: 10,
      vip: 15
    };
    return discounts[customerType] || 0;
  }

  calculateCustomerType(statistics) {
    if (statistics.totalSpent >= 1000 || statistics.totalPackages >= 50) {
      return 'vip';
    } else if (statistics.totalSpent >= 500 || statistics.totalPackages >= 20) {
      return 'premium';
    } else if (statistics.totalSpent >= 100 || statistics.totalPackages >= 5) {
      return 'business';
    }
    return 'individual';
  }

  calculateDiscount(customerType, statistics) {
    let baseDiscount = this.calculateInitialDiscount(customerType);
    
    // Bonificación por fidelidad
    if (statistics.totalPackages >= 100) {
      baseDiscount += 5;
    } else if (statistics.totalPackages >= 50) {
      baseDiscount += 3;
    } else if (statistics.totalPackages >= 20) {
      baseDiscount += 2;
    }

    return Math.min(baseDiscount, 25); // Máximo 25% descuento
  }

  // Métodos de utilidad para UI
  getStatusLabel(status) {
    const labels = {
      active: 'Activo',
      inactive: 'Inactivo',
      suspended: 'Suspendido'
    };
    return labels[status] || status;
  }

  getStatusColor(status) {
    const colors = {
      active: 'bg-green-100 text-green-800',
      inactive: 'bg-yellow-100 text-yellow-800',
      suspended: 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  }

  getCustomerTypeLabel(type) {
    const labels = {
      individual: 'Individual',
      business: 'Empresa',
      premium: 'Premium',
      vip: 'VIP'
    };
    return labels[type] || type;
  }

  getCustomerTypeColor(type) {
    const colors = {
      individual: 'bg-gray-100 text-gray-800',
      business: 'bg-blue-100 text-blue-800',
      premium: 'bg-purple-100 text-purple-800',
      vip: 'bg-yellow-100 text-yellow-800'
    };
    return colors[type] || 'bg-gray-100 text-gray-800';
  }

  // Integración con PackageService
  linkPackageToClient(packageId, clientId) {
    try {
      // Actualizar el paquete con el ID del cliente
      PackageService.updatePackage(packageId, { clientId });
      
      // Actualizar estadísticas del cliente
      this.updateClientStatistics(clientId);
      
      return true;
    } catch (error) {
      console.error('Error linking package to client:', error);
      throw error;
    }
  }

  // Obtener clientes para dropdown/select
  getClientsForSelect() {
    return this.getAllClients()
      .filter(client => client.accountInfo.status === 'active')
      .map(client => ({
        value: client.id,
        label: `${client.personalInfo.fullName} (${client.clientCode})`,
        email: client.personalInfo.email,
        discount: client.accountInfo.discountRate
      }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }
}

// Exportar instancia singleton
const clientServiceInstance = new ClientService();
export default clientServiceInstance;