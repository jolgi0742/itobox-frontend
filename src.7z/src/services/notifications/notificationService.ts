import { Notification } from '@/types';
import { apiClient } from '../api/apiClient';

class NotificationService {
  async getNotifications(params: {
    unreadOnly?: boolean;
    page?: number;
    pageSize?: number;
  } = {}): Promise<Notification[]> {
    const queryParams = new URLSearchParams();
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        queryParams.append(key, value.toString());
      }
    });

    return apiClient.get<Notification[]>(`/notifications?${queryParams.toString()}`);
  }

  async markAsRead(id: number): Promise<void> {
    await apiClient.patch(`/notifications/${id}/read`);
  }

  async markAllAsRead(): Promise<void> {
    await apiClient.patch('/notifications/read-all');
  }

  async deleteNotification(id: number): Promise<void> {
    await apiClient.delete(`/notifications/${id}`);
  }

  async getUnreadCount(): Promise<{ count: number }> {
    return apiClient.get<{ count: number }>('/notifications/unread-count');
  }

  async updatePreferences(preferences: any): Promise<void> {
    await apiClient.patch('/notifications/preferences', preferences);
  }

  async testNotification(type: string): Promise<void> {
    await apiClient.post('/notifications/test', { type });
  }
}

export const notificationService = new NotificationService();