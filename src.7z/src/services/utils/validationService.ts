import * as yup from 'yup';

class ValidationService {
  // Common schemas
  emailSchema = yup.string().email('Email inválido').required('Email es requerido');
  passwordSchema = yup.string().min(6, 'La contraseña debe tener al menos 6 caracteres').required('Contraseña es requerida');
  phoneSchema = yup.string().matches(/^[\+]?[1-9][\d]{0,15}$/, 'Número de teléfono inválido');

  // Login validation
  loginSchema = yup.object({
    email: this.emailSchema,
    password: this.passwordSchema,
    rememberMe: yup.boolean()
  });

  // Registration validation
  registerSchema = yup.object({
    email: this.emailSchema,
    password: this.passwordSchema,
    confirmPassword: yup.string()
      .oneOf([yup.ref('password')], 'Las contraseñas deben coincidir')
      .required('Confirmar contraseña es requerido'),
    firstName: yup.string().required('Nombre es requerido'),
    lastName: yup.string().required('Apellido es requerido'),
    phone: this.phoneSchema.required('Teléfono es requerido'),
    company: yup.string(),
    terms: yup.boolean().oneOf([true], 'Debes aceptar los términos y condiciones')
  });

  // Package validation
  packageSchema = yup.object({
    trackingNumber: yup.string().required('Número de tracking es requerido'),
    courier: yup.string().oneOf(['UPS', 'FedEx', 'DHL', 'USPS', 'Other']).required('Courier es requerido'),
    description: yup.string().required('Descripción es requerida'),
    weight: yup.number().positive('El peso debe ser positivo').required('Peso es requerido'),
    dimensions: yup.object({
      length: yup.number().positive().required(),
      width: yup.number().positive().required(),
      height: yup.number().positive().required()
    }),
    value: yup.number().positive('El valor debe ser positivo').required('Valor es requerido'),
    recipientName: yup.string().required('Nombre del destinatario es requerido'),
    recipientAddress: yup.object({
      street: yup.string().required('Dirección es requerida'),
      city: yup.string().required('Ciudad es requerida'),
      state: yup.string().required('Estado es requerido'),
      zipCode: yup.string().required('Código postal es requerido'),
      country: yup.string().required('País es requerido')
    })
  });

  // Client validation
  clientSchema = yup.object({
    customerCode: yup.string().required('Código de cliente es requerido'),
    contactPerson: yup.string().required('Persona de contacto es requerida'),
    phone: this.phoneSchema.required('Teléfono es requerido'),
    companyName: yup.string(),
    address: yup.object({
      street: yup.string().required('Dirección es requerida'),
      city: yup.string().required('Ciudad es requerida'),
      state: yup.string().required('Estado es requerido'),
      zipCode: yup.string().required('Código postal es requerido'),
      country: yup.string().required('País es requerido')
    })
  });

  async validate<T>(schema: yup.Schema<T>, data: any): Promise<{ valid: boolean; errors: Record<string, string> }> {
    try {
      await schema.validate(data, { abortEarly: false });
      return { valid: true, errors: {} };
    } catch (error) {
      if (error instanceof yup.ValidationError) {
        const errors: Record<string, string> = {};
        error.inner.forEach((err) => {
          if (err.path) {
            errors[err.path] = err.message;
          }
        });
        return { valid: false, errors };
      }
      throw error;
    }
  }
}

export const validationService = new ValidationService();