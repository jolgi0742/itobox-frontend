import { Client } from '@/types';
import { apiClient } from './apiClient';

class ClientService {
  async getClients(params: {
    search?: string;
    status?: string;
    page?: number;
    pageSize?: number;
  } = {}): Promise<{ data: Client[]; pagination: any }> {
    const queryParams = new URLSearchParams();
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined) {
        queryParams.append(key, value.toString());
      }
    });

    return apiClient.get<{ data: Client[]; pagination: any }>(`/clients?${queryParams.toString()}`);
  }

  async getClient(id: number): Promise<Client> {
    return apiClient.get<Client>(`/clients/${id}`);
  }

  async createClient(clientData: Partial<Client>): Promise<Client> {
    return apiClient.post<Client>('/clients', clientData);
  }

  async updateClient(id: number, updates: Partial<Client>): Promise<Client> {
    return apiClient.patch<Client>(`/clients/${id}`, updates);
  }

  async deleteClient(id: number): Promise<void> {
    await apiClient.delete(`/clients/${id}`);
  }

  async getClientMetrics(id: number): Promise<any> {
    return apiClient.get(`/clients/${id}/metrics`);
  }

  async searchClients(query: string): Promise<Client[]> {
    return apiClient.get<Client[]>(`/clients/search?q=${encodeURIComponent(query)}`);
  }

  async generateCustomerCode(): Promise<{ customerCode: string }> {
    return apiClient.post<{ customerCode: string }>('/clients/generate-code');
  }
}

export const clientService = new ClientService();