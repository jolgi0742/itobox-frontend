import { Package, PackageFilters, SortOption, PaginationInfo, ApiResponse } from '@/types';
import { apiClient } from './apiClient';

interface GetPackagesParams extends PackageFilters {
  sort?: SortOption;
  page?: number;
  pageSize?: number;
}

interface GetPackagesResponse {
  data: Package[];
  pagination: PaginationInfo;
}

class PackageService {
  async getPackages(params: GetPackagesParams = {}): Promise<GetPackagesResponse> {
    const queryParams = new URLSearchParams();

    if (params.search) queryParams.append('search', params.search);
    if (params.status?.length) queryParams.append('status', params.status.join(','));
    if (params.courier?.length) queryParams.append('courier', params.courier.join(','));
    if (params.clientId?.length) queryParams.append('clientId', params.clientId.join(','));
    if (params.agentId?.length) queryParams.append('agentId', params.agentId.join(','));
    if (params.priority?.length) queryParams.append('priority', params.priority.join(','));
    if (params.category?.length) queryParams.append('category', params.category.join(','));
    
    if (params.dateRange) {
      queryParams.append('startDate', params.dateRange.startDate.toISOString());
      queryParams.append('endDate', params.dateRange.endDate.toISOString());
    }

    if (params.sort) {
      queryParams.append('sortField', params.sort.field);
      queryParams.append('sortDirection', params.sort.direction);
    }

    if (params.page) queryParams.append('page', params.page.toString());
    if (params.pageSize) queryParams.append('pageSize', params.pageSize.toString());

    return apiClient.get<GetPackagesResponse>(`/packages?${queryParams.toString()}`);
  }

  async getPackage(id: number): Promise<Package> {
    return apiClient.get<Package>(`/packages/${id}`);
  }

  async createPackage(packageData: Partial<Package>): Promise<Package> {
    return apiClient.post<Package>('/packages', packageData);
  }

  async updatePackage(id: number, updates: Partial<Package>): Promise<Package> {
    return apiClient.patch<Package>(`/packages/${id}`, updates);
  }

  async deletePackage(id: number): Promise<void> {
    await apiClient.delete(`/packages/${id}`);
  }

  async uploadPackagePhoto(packageId: number, file: File, onProgress?: (progress: number) => void): Promise<{ url: string }> {
    return apiClient.upload<{ url: string }>(`/packages/${packageId}/photos`, file, onProgress);
  }

  async deletePackagePhoto(packageId: number, photoId: string): Promise<void> {
    await apiClient.delete(`/packages/${packageId}/photos/${photoId}`);
  }

  async getTrackingHistory(id: number): Promise<any[]> {
    return apiClient.get<any[]>(`/packages/${id}/tracking`);
  }

  async updateTrackingStatus(id: number, status: string, notes?: string): Promise<Package> {
    return apiClient.patch<Package>(`/packages/${id}/tracking`, { status, notes });
  }

  async searchPackages(query: string): Promise<Package[]> {
    return apiClient.get<Package[]>(`/packages/search?q=${encodeURIComponent(query)}`);
  }

  async getPackagesByClient(clientId: number): Promise<Package[]> {
    return apiClient.get<Package[]>(`/packages/client/${clientId}`);
  }

  async bulkUpdateStatus(packageIds: number[], status: string): Promise<void> {
    await apiClient.patch('/packages/bulk-update', { packageIds, status });
  }
}

export const packageService = new PackageService();