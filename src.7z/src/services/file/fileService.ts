import { apiClient } from '../api/apiClient';

interface UploadResponse {
  url: string;
  filename: string;
  size: number;
  type: string;
}

class FileService {
  async uploadFile(file: File, type: 'avatar' | 'package' | 'document', onProgress?: (progress: number) => void): Promise<UploadResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);

    return apiClient.upload<UploadResponse>('/files/upload', file, onProgress);
  }

  async deleteFile(url: string): Promise<void> {
    await apiClient.delete('/files/delete', { data: { url } });
  }

  async getFileInfo(url: string): Promise<any> {
    return apiClient.get(`/files/info?url=${encodeURIComponent(url)}`);
  }

  validateFile(file: File, options: {
    maxSize?: number;
    allowedTypes?: string[];
  } = {}): { valid: boolean; error?: string } {
    const { maxSize = 10 * 1024 * 1024, allowedTypes = [] } = options; // 10MB default

    if (file.size > maxSize) {
      return {
        valid: false,
        error: `El archivo es demasiado grande. Tamaño máximo: ${maxSize / 1024 / 1024}MB`
      };
    }

    if (allowedTypes.length > 0 && !allowedTypes.includes(file.type)) {
      return {
        valid: false,
        error: `Tipo de archivo no permitido. Tipos permitidos: ${allowedTypes.join(', ')}`
      };
    }

    return { valid: true };
  }
}

export const fileService = new FileService();