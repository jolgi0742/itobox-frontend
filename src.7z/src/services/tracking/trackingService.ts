import { TrackingEvent, TrackingUpdate, CourierType } from '@/types';
import { apiClient } from '../api/apiClient';

class TrackingService {
  async getTrackingInfo(trackingNumber: string, courier: CourierType): Promise<TrackingUpdate> {
    return apiClient.get<TrackingUpdate>(`/tracking/${courier}/${trackingNumber}`);
  }

  async refreshTrackingInfo(trackingNumber: string, courier: CourierType): Promise<TrackingUpdate> {
    return apiClient.post<TrackingUpdate>(`/tracking/${courier}/${trackingNumber}/refresh`);
  }

  async getTrackingHistory(packageId: number): Promise<TrackingEvent[]> {
    return apiClient.get<TrackingEvent[]>(`/tracking/history/${packageId}`);
  }

  async addManualTrackingEvent(packageId: number, event: Partial<TrackingEvent>): Promise<TrackingEvent> {
    return apiClient.post<TrackingEvent>(`/tracking/manual/${packageId}`, event);
  }

  async bulkRefreshTracking(packageIds: number[]): Promise<void> {
    await apiClient.post('/tracking/bulk-refresh', { packageIds });
  }

  async getTrackingMetrics(): Promise<any> {
    return apiClient.get('/tracking/metrics');
  }

  async subscribeToUpdates(trackingNumber: string, courier: CourierType): Promise<void> {
    await apiClient.post('/tracking/subscribe', { trackingNumber, courier });
  }

  async unsubscribeFromUpdates(trackingNumber: string, courier: CourierType): Promise<void> {
    await apiClient.post('/tracking/unsubscribe', { trackingNumber, courier });
  }
}

export const trackingService = new TrackingService();