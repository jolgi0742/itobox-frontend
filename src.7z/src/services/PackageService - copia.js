// services/PackageService.js
class PackageService {
  constructor() {
    this.STORAGE_KEY = 'itobox_packages';
    this.COUNTER_KEY = 'itobox_package_counter';
  }

  // Generar código de tracking único
  generateTrackingCode() {
    const now = new Date();
    const year = now.getFullYear();
    const counter = this.getNextCounter();
    return `ITO-${year}-${counter.toString().padStart(6, '0')}`;
  }

  // Obtener siguiente número de contador
  getNextCounter() {
    const current = parseInt(localStorage.getItem(this.COUNTER_KEY) || '0');
    const next = current + 1;
    localStorage.setItem(this.COUNTER_KEY, next.toString());
    return next;
  }

  // Obtener todos los paquetes
  getAllPackages() {
    try {
      const packages = localStorage.getItem(this.STORAGE_KEY);
      return packages ? JSON.parse(packages) : [];
    } catch (error) {
      console.error('Error loading packages:', error);
      return [];
    }
  }

  // Obtener paquete por ID
  getPackageById(id) {
    const packages = this.getAllPackages();
    return packages.find(pkg => pkg.id === id);
  }

  // Obtener paquete por código de tracking
  getPackageByTrackingCode(trackingCode) {
    const packages = this.getAllPackages();
    return packages.find(pkg => pkg.trackingCode === trackingCode);
  }

  // Crear nuevo paquete
  createPackage(packageData) {
    try {
      const packages = this.getAllPackages();
      const newPackage = {
        id: this.generateId(),
        trackingCode: this.generateTrackingCode(),
        ...packageData,
        status: 'created',
        dates: {
          created: new Date().toISOString(),
          collected: null,
          estimated_delivery: packageData.estimated_delivery || this.calculateEstimatedDelivery(packageData.priority),
          delivered: null
        },
        location: {
          current: 'Centro de Distribución Principal',
          history: [
            {
              location: 'Centro de Distribución Principal',
              timestamp: new Date().toISOString(),
              note: 'Paquete creado y registrado en el sistema'
            }
          ]
        },
        paymentStatus: 'pending'
      };

      packages.push(newPackage);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(packages));
      return newPackage;
    } catch (error) {
      console.error('Error creating package:', error);
      throw new Error('No se pudo crear el paquete');
    }
  }

  // Actualizar paquete
  updatePackage(id, updateData) {
    try {
      const packages = this.getAllPackages();
      const index = packages.findIndex(pkg => pkg.id === id);
      
      if (index === -1) {
        throw new Error('Paquete no encontrado');
      }

      packages[index] = { ...packages[index], ...updateData };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(packages));
      return packages[index];
    } catch (error) {
      console.error('Error updating package:', error);
      throw error;
    }
  }

  // Actualizar estado del paquete
  updatePackageStatus(id, newStatus, location = null, note = null) {
    try {
      const pkg = this.getPackageById(id);
      if (!pkg) {
        throw new Error('Paquete no encontrado');
      }

      const updates = {
        status: newStatus,
        dates: { ...pkg.dates }
      };

      // Actualizar fechas según el estado
      switch (newStatus) {
        case 'collected':
          updates.dates.collected = new Date().toISOString();
          break;
        case 'delivered':
          updates.dates.delivered = new Date().toISOString();
          break;
      }

      // Actualizar ubicación si se proporciona
      if (location) {
        updates.location = {
          current: location,
          history: [
            ...pkg.location.history,
            {
              location,
              timestamp: new Date().toISOString(),
              note: note || `Estado cambiado a: ${this.getStatusLabel(newStatus)}`
            }
          ]
        };
      }

      return this.updatePackage(id, updates);
    } catch (error) {
      console.error('Error updating package status:', error);
      throw error;
    }
  }

  // Eliminar paquete
  deletePackage(id) {
    try {
      const packages = this.getAllPackages();
      const filteredPackages = packages.filter(pkg => pkg.id !== id);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredPackages));
      return true;
    } catch (error) {
      console.error('Error deleting package:', error);
      throw new Error('No se pudo eliminar el paquete');
    }
  }

  // Filtrar paquetes
  filterPackages(filters = {}) {
    let packages = this.getAllPackages();

    if (filters.status) {
      packages = packages.filter(pkg => pkg.status === filters.status);
    }

    if (filters.priority) {
      packages = packages.filter(pkg => pkg.packageDetails.priority === filters.priority);
    }

    if (filters.dateFrom) {
      packages = packages.filter(pkg => 
        new Date(pkg.dates.created) >= new Date(filters.dateFrom)
      );
    }

    if (filters.dateTo) {
      packages = packages.filter(pkg => 
        new Date(pkg.dates.created) <= new Date(filters.dateTo)
      );
    }

    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      packages = packages.filter(pkg => 
        pkg.trackingCode.toLowerCase().includes(searchTerm) ||
        pkg.sender.name.toLowerCase().includes(searchTerm) ||
        pkg.recipient.name.toLowerCase().includes(searchTerm) ||
        pkg.packageDetails.description.toLowerCase().includes(searchTerm)
      );
    }

    return packages;
  }

  // Obtener estadísticas básicas
  getPackageStats() {
    const packages = this.getAllPackages();
    const stats = {
      total: packages.length,
      byStatus: {},
      todayCreated: 0,
      pendingDeliveries: 0,
      avgDeliveryTime: 0
    };

    const today = new Date().toDateString();
    let deliveredPackages = [];

    packages.forEach(pkg => {
      // Contar por estado
      stats.byStatus[pkg.status] = (stats.byStatus[pkg.status] || 0) + 1;

      // Paquetes creados hoy
      if (new Date(pkg.dates.created).toDateString() === today) {
        stats.todayCreated++;
      }

      // Entregas pendientes
      if (['collected', 'in_transit', 'out_for_delivery'].includes(pkg.status)) {
        stats.pendingDeliveries++;
      }

      // Paquetes entregados para calcular tiempo promedio
      if (pkg.status === 'delivered' && pkg.dates.delivered) {
        deliveredPackages.push(pkg);
      }
    });

    // Calcular tiempo promedio de entrega
    if (deliveredPackages.length > 0) {
      const totalTime = deliveredPackages.reduce((sum, pkg) => {
        const created = new Date(pkg.dates.created);
        const delivered = new Date(pkg.dates.delivered);
        return sum + (delivered - created);
      }, 0);
      
      stats.avgDeliveryTime = Math.round(totalTime / deliveredPackages.length / (1000 * 60 * 60 * 24)); // días
    }

    return stats;
  }

  // Utilidades
  generateId() {
    return 'pkg_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  }

  calculateEstimatedDelivery(priority = 'normal') {
    const now = new Date();
    const days = {
      express: 1,
      urgent: 2,
      normal: 3
    };
    
    now.setDate(now.getDate() + (days[priority] || 3));
    return now.toISOString();
  }

  getStatusLabel(status) {
    const labels = {
      created: 'Creado',
      collected: 'Recolectado',
      in_transit: 'En Tránsito',
      out_for_delivery: 'En Reparto',
      delivered: 'Entregado',
      returned: 'Devuelto'
    };
    return labels[status] || status;
  }

  getStatusColor(status) {
    const colors = {
      created: 'bg-blue-100 text-blue-800',
      collected: 'bg-yellow-100 text-yellow-800',
      in_transit: 'bg-orange-100 text-orange-800',
      out_for_delivery: 'bg-purple-100 text-purple-800',
      delivered: 'bg-green-100 text-green-800',
      returned: 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  }

  getPriorityLabel(priority) {
    const labels = {
      normal: 'Normal',
      urgent: 'Urgente',
      express: 'Express'
    };
    return labels[priority] || priority;
  }

  getPriorityColor(priority) {
    const colors = {
      normal: 'bg-gray-100 text-gray-800',
      urgent: 'bg-yellow-100 text-yellow-800',
      express: 'bg-red-100 text-red-800'
    };
    return colors[priority] || 'bg-gray-100 text-gray-800';
  }
}

// Exportar instancia singleton
export default new PackageService();