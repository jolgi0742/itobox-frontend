import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, ArrowLeft, Send } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Alert } from '@/components/ui/Alert';
import { useLanguage } from '@/contexts/LanguageContext';
import { useForm } from '@/hooks/useForm';
import { authService } from '@/services/auth/authService';
import { validationService } from '@/services/utils/validationService';
import { useState } from 'react';

export const ForgotPasswordForm: React.FC = () => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { t } = useLanguage();

  const {
    values,
    errors,
    touched,
    isValid,
    handleChange,
    handleBlur,
    handleSubmit
  } = useForm<{ email: string }>({
    initialValues: {
      email: ''
    },
    validate: async (values) => {
      if (!values.email) {
        return { email: t('validation.required') };
      }
      if (!/\S+@\S+\.\S+/.test(values.email)) {
        return { email: t('validation.invalidEmail') };
      }
      return {};
    },
    onSubmit: async (values) => {
      setIsLoading(true);
      setError(null);
      
      try {
        await authService.forgotPassword(values.email);
        setIsSubmitted(true);
      } catch (err: any) {
        setError(err.message || t('auth.forgotPasswordError'));
      } finally {
        setIsLoading(false);
      }
    }
  });

  if (isSubmitted) {
    return (
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-gray-800 shadow-2xl rounded-lg p-8 text-center">
          <div className="mb-6">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Send className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
              {t('auth.emailSent')}
            </h2>
            <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
              {t('auth.emailSentDescription', { email: values.email })}
            </p>
          </div>

          <div className="space-y-4">
            <Link to="/auth/login">
              <Button variant="primary" className="w-full">
                <ArrowLeft className="h-4 w-4 mr-2" />
                {t('auth.backToLogin')}
              </Button>
            </Link>
            
            <Button
              variant="outline"
              onClick={() => setIsSubmitted(false)}
              className="w-full"
            >
              {t('auth.resendEmail')}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-md">
      <div className="bg-white dark:bg-gray-800 shadow-2xl rounded-lg p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-4">
            <img
              src="/logo.png"
              alt="ITOBOX"
              className="h-12 w-auto mx-auto"
            />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t('auth.forgotPassword')}
          </h2>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            {t('auth.forgotPasswordDescription')}
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="error" className="mb-6" onClose={() => setError(null)}>
            {error}
          </Alert>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            label={t('auth.email')}
            type="email"
            value={values.email}
            onChange={handleChange('email')}
            onBlur={handleBlur('email')}
            error={touched.email ? errors.email : undefined}
            leftIcon={<Mail className="h-4 w-4 text-gray-400" />}
            placeholder="correo@ejemplo.com"
            autoComplete="email"
            autoFocus
          />

          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full"
            isLoading={isLoading}
            disabled={!isValid}
          >
            <Send className="h-4 w-4 mr-2" />
            {t('auth.sendResetEmail')}
          </Button>
        </form>

        {/* Back to Login */}
        <div className="mt-6 text-center">
          <Link
            to="/auth/login"
            className="inline-flex items-center text-sm text-itobox-primary hover:text-itobox-accent transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            {t('auth.backToLogin')}
          </Link>
        </div>
      </div>
    </div>
  );
};