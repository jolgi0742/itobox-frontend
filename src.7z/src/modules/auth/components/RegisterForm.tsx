import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, User, Phone, Building } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Alert } from '@/components/ui/Alert';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useForm } from '@/hooks/useForm';
import { validationService } from '@/services/utils/validationService';
import { RegisterFormData } from '@/types';

interface RegisterFormProps {
  onSuccess?: () => void;
}

export const RegisterForm: React.FC<RegisterFormProps> = ({ onSuccess }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const { register, isLoading, error, clearError } = useAuth();
  const { t } = useLanguage();

  const {
    values,
    errors,
    touched,
    isValid,
    handleChange,
    handleBlur,
    handleSubmit
  } = useForm<RegisterFormData>({
    initialValues: {
      email: '',
      password: '',
      confirmPassword: '',
      firstName: '',
      lastName: '',
      phone: '',
      company: '',
      terms: false
    },
    validate: async (values) => {
      const result = await validationService.validate(validationService.registerSchema, values);
      return result.errors;
    },
    onSubmit: async (values) => {
      clearError();
      try {
        await register(values);
        onSuccess?.();
      } catch (err) {
        // Error is handled by the auth context
      }
    }
  });

  return (
    <div className="w-full max-w-md">
      <div className="bg-white dark:bg-gray-800 shadow-2xl rounded-lg p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="mb-4">
            <img
              src="/logo.png"
              alt="ITOBOX"
              className="h-12 w-auto mx-auto"
            />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            {t('auth.register')}
          </h2>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            {t('auth.registerDescription')}
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <Alert variant="error" className="mb-6" onClose={clearError}>
            {error}
          </Alert>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name Fields */}
          <div className="grid grid-cols-2 gap-4">
            <Input
              label={t('auth.firstName')}
              value={values.firstName}
              onChange={handleChange('firstName')}
              onBlur={handleBlur('firstName')}
              error={touched.firstName ? errors.firstName : undefined}
              leftIcon={<User className="h-4 w-4 text-gray-400" />}
              placeholder="Juan"
              autoComplete="given-name"
            />

            <Input
              label={t('auth.lastName')}
              value={values.lastName}
              onChange={handleChange('lastName')}
              onBlur={handleBlur('lastName')}
              error={touched.lastName ? errors.lastName : undefined}
              leftIcon={<User className="h-4 w-4 text-gray-400" />}
              placeholder="Pérez"
              autoComplete="family-name"
            />
          </div>

          {/* Email */}
          <Input
            label={t('auth.email')}
            type="email"
            value={values.email}
            onChange={handleChange('email')}
            onBlur={handleBlur('email')}
            error={touched.email ? errors.email : undefined}
            leftIcon={<Mail className="h-4 w-4 text-gray-400" />}
            placeholder="correo@ejemplo.com"
            autoComplete="email"
          />

          {/* Phone */}
          <Input
            label={t('auth.phone')}
            type="tel"
            value={values.phone}
            onChange={handleChange('phone')}
            onBlur={handleBlur('phone')}
            error={touched.phone ? errors.phone : undefined}
            leftIcon={<Phone className="h-4 w-4 text-gray-400" />}
            placeholder="+506 1234 5678"
            autoComplete="tel"
          />

          {/* Company (Optional) */}
          <Input
            label={`${t('auth.company')} (${t('common.optional')})`}
            value={values.company}
            onChange={handleChange('company')}
            onBlur={handleBlur('company')}
            error={touched.company ? errors.company : undefined}
            leftIcon={<Building className="h-4 w-4 text-gray-400" />}
            placeholder="Mi Empresa S.A."
            autoComplete="organization"
          />

          {/* Password */}
          <Input
            label={t('auth.password')}
            type={showPassword ? 'text' : 'password'}
            value={values.password}
            onChange={handleChange('password')}
            onBlur={handleBlur('password')}
            error={touched.password ? errors.password : undefined}
            leftIcon={<Lock className="h-4 w-4 text-gray-400" />}
            rightIcon={
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-gray-400 hover:text-gray-600"
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            }
            placeholder="••••••••"
            autoComplete="new-password"
          />

          {/* Confirm Password */}
          <Input
            label={t('auth.confirmPassword')}
            type={showConfirmPassword ? 'text' : 'password'}
            value={values.confirmPassword}
            onChange={handleChange('confirmPassword')}
            onBlur={handleBlur('confirmPassword')}
            error={touched.confirmPassword ? errors.confirmPassword : undefined}
            leftIcon={<Lock className="h-4 w-4 text-gray-400" />}
            rightIcon={
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="text-gray-400 hover:text-gray-600"
              >
                {showConfirmPassword ? (
                  <EyeOff className="h-4 w-4" />
                ) : (
                  <Eye className="h-4 w-4" />
                )}
              </button>
            }
            placeholder="••••••••"
            autoComplete="new-password"
          />

          {/* Terms and Conditions */}
          <div className="flex items-start">
            <input
              type="checkbox"
              checked={values.terms}
              onChange={handleChange('terms')}
              className="h-4 w-4 text-itobox-primary border-gray-300 rounded focus:ring-itobox-primary mt-1"
            />
            <label className="ml-2 text-sm text-gray-600 dark:text-gray-400">
              {t('auth.terms')}{' '}
              <Link
                to="/terms"
                className="text-itobox-primary hover:text-itobox-accent"
                target="_blank"
              >
                términos y condiciones
              </Link>
            </label>
          </div>
          {touched.terms && errors.terms && (
            <p className="text-sm text-red-600">{errors.terms}</p>
          )}

          {/* Submit Button */}
          <Button
            type="submit"
            variant="primary"
            size="lg"
            className="w-full"
            isLoading={isLoading}
            disabled={!isValid}
          >
            {t('auth.register')}
          </Button>
        </form>

        {/* Login Link */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            {t('auth.hasAccount')}{' '}
            <Link
              to="/auth/login"
              className="text-itobox-primary hover:text-itobox-accent font-medium transition-colors"
            >
              {t('auth.login')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};