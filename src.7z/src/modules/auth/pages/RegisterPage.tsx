import React from 'react';
import { AuthLayout } from '../components/AuthLayout';
import { RegisterForm } from '../components/RegisterForm';
import { PublicRoute } from '../components/PublicRoute';

export const RegisterPage: React.FC = () => {
  return (
    <PublicRoute>
      <AuthLayout
        title="Crear Cuenta"
        subtitle="Completa tus datos para registrarte"
      >
        <RegisterForm />
      </AuthLayout>
    </PublicRoute>
  );
};