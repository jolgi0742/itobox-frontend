import React from 'react';
import { AuthLayout } from '../components/AuthLayout';
import { ForgotPasswordForm } from '../components/ForgotPasswordForm';
import { PublicRoute } from '../components/PublicRoute';

export const ForgotPasswordPage: React.FC = () => {
  return (
    <PublicRoute>
      <AuthLayout
        title="Recuperar Contraseña"
        subtitle="Ingresa tu email para recuperar tu contraseña"
      >
        <ForgotPasswordForm />
      </AuthLayout>
    </PublicRoute>
  );
};