import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Alert';
import { TrackingSearch } from '../components/TrackingSearch';
import { TrackingTimeline } from '../components/TrackingTimeline';
import { TrackingMap } from '../components/TrackingMap';
import { useTracking } from '../hooks/useTracking';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { 
  RefreshCw,
  MapPin,
  Clock
} from 'lucide-react';

// Mock data for vehicles (in real app, this would come from API)
const mockVehicles = [
  {
    id: 'VH001',
    name: 'Vehículo 001',
    position: { lat: 9.9281, lng: -84.0907 },
    status: 'active' as const,
    packages: 12,
    driver: 'Juan Pérez',
    lastUpdate: new Date()
  },
  {
    id: 'VH002',
    name: 'Vehículo 002',
    position: { lat: 9.9355, lng: -84.0830 },
    status: 'delivering' as const,
    packages: 8,
    driver: 'María González',
    lastUpdate: new Date()
  },
  {
    id: 'VH003',
    name: 'Vehículo 003',
    position: { lat: 9.9200, lng: -84.1000 },
    status: 'inactive' as const,
    packages: 0,
    driver: 'Carlos Rodríguez',
    lastUpdate: new Date()
  }
];

export const TrackingPage: React.FC = () => {
  const [selectedVehicle, setSelectedVehicle] = useState<string>('');
  const [vehicles, setVehicles] = useState(mockVehicles);
  const { user } = useAuth();
  const { t } = useLanguage();
  
  const {
    trackingData,
    trackingEvents,
    isLoading,
    error,
    trackPackage,
    refreshTracking,
    clearError
  } = useTracking();

  // Auto-refresh vehicles every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setVehicles(prev => prev.map(vehicle => ({
        ...vehicle,
        lastUpdate: new Date(),
        // Simulate position changes
        position: {
          lat: vehicle.position.lat + (Math.random() - 0.5) * 0.001,
          lng: vehicle.position.lng + (Math.random() - 0.5) * 0.001
        }
      })));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const handleTrackingResult = (result: any) => {
    // Additional handling when tracking result is received
    console.log('Tracking result received:', result);
  };

  const handleRefreshVehicles = () => {
    // In real app, this would refresh from API
    setVehicles(prev => prev.map(vehicle => ({
      ...vehicle,
      lastUpdate: new Date()
    })));
  };

  const canViewFleetTracking = user?.role === 'admin' || user?.role === 'agent';

  return (
    <MainLayout>
      <div className="space-y-6">
        <PageHeader
          title="tracking.title"
          description="tracking.description"
          breadcrumbs={[
            { name: 'tracking.title', current: true }
          ]}
          actions={
            <Button
              variant="outline"
              onClick={refreshTracking}
              disabled={isLoading || !trackingData}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              {t('common.refresh')}
            </Button>
          }
        />

        {error && (
          <Alert variant="error" onClose={clearError}>
            {error}
          </Alert>
        )}

        {/* Tracking Search */}
        <TrackingSearch onTrackingResult={handleTrackingResult} />

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Tracking Timeline */}
          <div className="space-y-6">
            <TrackingTimeline 
              events={trackingEvents} 
              isLoading={isLoading}
            />
          </div>

          {/* Fleet Tracking (Admin/Agent only) */}
          {canViewFleetTracking && (
            <div className="space-y-6">
              <TrackingMap
                vehicles={vehicles}
                selectedVehicle={selectedVehicle}
                onVehicleSelect={setSelectedVehicle}
                onRefresh={handleRefreshVehicles}
              />
            </div>
          )}
        </div>

        {/* Additional tracking information for clients */}
        {user?.role === 'client' && trackingData && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-2">
                <MapPin className="h-5 w-5 text-blue-500" />
                <h3 className="font-medium text-blue-800 dark:text-blue-400">
                  {t('tracking.currentStatus')}
                </h3>
              </div>
              <p className="text-2xl font-bold text-blue-600">
                {trackingData.status}
              </p>
            </div>

            <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6">
              <div className="flex items-center space-x-2 mb-2">
                <Clock className="h-5 w-5 text-green-500" />
                <h3 className="font-medium text-green-800 dark:text-green-400">
                  {t('tracking.lastUpdate')}
                </h3>
              </div>
              <p className="text-sm font-medium text-green-600">
                {trackingData.lastUpdated.toLocaleString()}
              </p>
            </div>

            {trackingData.estimatedDelivery && (
              <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-lg p-6">
                <div className="flex items-center space-x-2 mb-2">
                  <Clock className="h-5 w-5 text-yellow-500" />
                  <h3 className="font-medium text-yellow-800 dark:text-yellow-400">
                    {t('tracking.estimatedDelivery')}
                  </h3>
                </div>
                <p className="text-sm font-medium text-yellow-600">
                  {trackingData.estimatedDelivery.toLocaleDateString()}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </MainLayout>
  );
};