import { useState, useEffect, useCallback } from 'react';
import { TrackingEvent, TrackingUpdate, CourierType } from '@/types';
import { trackingService } from '@/services/tracking/trackingService';

interface UseTrackingReturn {
  trackingData: TrackingUpdate | null;
  trackingEvents: TrackingEvent[];
  isLoading: boolean;
  error: string | null;
  trackPackage: (trackingNumber: string, courier: CourierType) => Promise<void>;
  refreshTracking: () => Promise<void>;
  getPackageHistory: (packageId: number) => Promise<void>;
  clearError: () => void;
}

export const useTracking = (): UseTrackingReturn => {
  const [trackingData, setTrackingData] = useState<TrackingUpdate | null>(null);
  const [trackingEvents, setTrackingEvents] = useState<TrackingEvent[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [currentTracking, setCurrentTracking] = useState<{
    trackingNumber: string;
    courier: CourierType;
  } | null>(null);

  const trackPackage = useCallback(async (trackingNumber: string, courier: CourierType) => {
    setIsLoading(true);
    setError(null);
    setCurrentTracking({ trackingNumber, courier });

    try {
      const data = await trackingService.getTrackingInfo(trackingNumber, courier);
      setTrackingData(data);
      setTrackingEvents(data.events || []);
    } catch (err: any) {
      setError(err.message || 'Error al obtener información de tracking');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const refreshTracking = useCallback(async () => {
    if (!currentTracking) return;

    setIsLoading(true);
    setError(null);

    try {
      const data = await trackingService.refreshTrackingInfo(
        currentTracking.trackingNumber,
        currentTracking.courier
      );
      setTrackingData(data);
      setTrackingEvents(data.events || []);
    } catch (err: any) {
      setError(err.message || 'Error al actualizar tracking');
    } finally {
      setIsLoading(false);
    }
  }, [currentTracking]);

  const getPackageHistory = useCallback(async (packageId: number) => {
    setIsLoading(true);
    setError(null);

    try {
      const events = await trackingService.getTrackingHistory(packageId);
      setTrackingEvents(events);
    } catch (err: any) {
      setError(err.message || 'Error al obtener historial');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    trackingData,
    trackingEvents,
    isLoading,
    error,
    trackPackage,
    refreshTracking,
    getPackageHistory,
    clearError
  };
};