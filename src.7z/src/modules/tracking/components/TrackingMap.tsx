import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Badge } from '@/components/ui/Badge';
import { 
  Map as MapIcon, 
  List, 
  MapPin, 
  Truck,
  Navigation,
  RefreshCw
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface VehicleLocation {
  id: string;
  name: string;
  position: {
    lat: number;
    lng: number;
  };
  status: 'active' | 'inactive' | 'delivering';
  packages: number;
  driver: string;
  lastUpdate: Date;
}

interface TrackingMapProps {
  vehicles: VehicleLocation[];
  selectedVehicle?: string;
  onVehicleSelect?: (vehicleId: string) => void;
  isLoading?: boolean;
  onRefresh?: () => void;
}

export const TrackingMap: React.FC<TrackingMapProps> = ({
  vehicles,
  selectedVehicle,
  onVehicleSelect,
  isLoading = false,
  onRefresh
}) => {
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const { t } = useLanguage();

  // Simulated map component (in real implementation, use Google Maps or similar)
  const MapView = () => (
    <div className="h-96 bg-gray-100 dark:bg-gray-700 rounded-lg relative overflow-hidden">
      {/* Simulated map background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-green-50">
        <div className="absolute inset-0 opacity-20">
          <svg className="w-full h-full" viewBox="0 0 400 300">
            {/* Grid pattern */}
            <defs>
              <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#ccc" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
      </div>

      {/* Vehicle markers */}
      {vehicles.map((vehicle) => (
        <div
          key={vehicle.id}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
          style={{
            left: `${(vehicle.position.lng + 84) * 5}%`,
            top: `${(10 - vehicle.position.lat) * 5}%`
          }}
          onClick={() => onVehicleSelect?.(vehicle.id)}
        >
          <div className={`relative ${selectedVehicle === vehicle.id ? 'z-10' : 'z-0'}`}>
            <div 
              className={`w-8 h-8 rounded-full border-2 flex items-center justify-center shadow-lg transition-all ${
                vehicle.status === 'active' ? 'bg-green-500 border-green-600' :
                vehicle.status === 'delivering' ? 'bg-blue-500 border-blue-600' :
                'bg-gray-500 border-gray-600'
              } ${selectedVehicle === vehicle.id ? 'scale-125 ring-4 ring-white' : ''}`}
            >
              <Truck className="h-4 w-4 text-white" />
            </div>
            
            {selectedVehicle === vehicle.id && (
              <div className="absolute top-10 left-1/2 transform -translate-x-1/2 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-3 min-w-48">
                <div className="text-sm">
                  <p className="font-medium">{vehicle.name}</p>
                  <p className="text-gray-500">{vehicle.driver}</p>
                  <p className="text-xs text-gray-400">
                    {vehicle.packages} {t('packages.count')}
                  </p>
                  <Badge
                    variant={
                      vehicle.status === 'active' ? 'success' :
                      vehicle.status === 'delivering' ? 'primary' : 'secondary'
                    }
                    size="sm"
                    className="mt-1"
                  >
                    {t(`vehicle.status.${vehicle.status}`)}
                  </Badge>
                </div>
              </div>
            )}
          </div>
        </div>
      ))}

      {/* Map controls */}
      <div className="absolute top-4 right-4 space-y-2">
        <Button
          variant="outline"
          size="sm"
          onClick={onRefresh}
          disabled={isLoading}
          className="bg-white/90 backdrop-blur-sm"
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
        </Button>
      </div>

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3">
        <h4 className="text-sm font-medium mb-2">{t('tracking.legend')}</h4>
        <div className="space-y-1 text-xs">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span>{t('vehicle.status.active')}</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span>{t('vehicle.status.delivering')}</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
            <span>{t('vehicle.status.inactive')}</span>
          </div>
        </div>
      </div>
    </div>
  );

  const ListView = () => (
    <div className="space-y-3">
      {vehicles.map((vehicle) => (
        <div
          key={vehicle.id}
          className={`p-4 border rounded-lg cursor-pointer transition-colors ${
            selectedVehicle === vehicle.id
              ? 'border-itobox-primary bg-itobox-primary/5'
              : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700'
          }`}
          onClick={() => onVehicleSelect?.(vehicle.id)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-10 h-10 rounded-full border-2 flex items-center justify-center ${
                vehicle.status === 'active' ? 'bg-green-500 border-green-600' :
                vehicle.status === 'delivering' ? 'bg-blue-500 border-blue-600' :
                'bg-gray-500 border-gray-600'
              }`}>
                <Truck className="h-5 w-5 text-white" />
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 dark:text-white">
                  {vehicle.name}
                </h4>
                <p className="text-sm text-gray-500">{vehicle.driver}</p>
              </div>
            </div>

            <div className="text-right">
              <Badge
                variant={
                  vehicle.status === 'active' ? 'success' :
                  vehicle.status === 'delivering' ? 'primary' : 'secondary'
                }
                size="sm"
              >
                {t(`vehicle.status.${vehicle.status}`)}
              </Badge>
              <p className="text-sm text-gray-500 mt-1">
                {vehicle.packages} {t('packages.count')}
              </p>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between text-xs text-gray-400">
            <div className="flex items-center space-x-1">
              <MapPin className="h-3 w-3" />
              <span>
                {vehicle.position.lat.toFixed(4)}, {vehicle.position.lng.toFixed(4)}
              </span>
            </div>
            <span>
              {t('tracking.lastUpdate')}: {vehicle.lastUpdate.toLocaleTimeString()}
            </span>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            {t('tracking.liveTracking')}
          </h3>
          
          <div className="flex items-center space-x-2">
            <div className="flex rounded-lg border border-gray-300 dark:border-gray-600">
              <Button
                variant={viewMode === 'map' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('map')}
                className="rounded-r-none"
              >
                <MapIcon className="h-4 w-4 mr-1" />
                {t('tracking.mapView')}
              </Button>
              <Button
                variant={viewMode === 'list' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-l-none border-l-0"
              >
                <List className="h-4 w-4 mr-1" />
                {t('tracking.listView')}
              </Button>
            </div>
          </div>
        </div>

        {viewMode === 'map' ? <MapView /> : <ListView />}

        {/* Fleet Statistics */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="text-sm font-medium text-green-800 dark:text-green-400">
                {t('vehicle.status.active')}
              </span>
            </div>
            <p className="text-2xl font-bold text-green-600 mt-2">
              {vehicles.filter(v => v.status === 'active').length}
            </p>
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm font-medium text-blue-800 dark:text-blue-400">
                {t('vehicle.status.delivering')}
              </span>
            </div>
            <p className="text-2xl font-bold text-blue-600 mt-2">
              {vehicles.filter(v => v.status === 'delivering').length}
            </p>
          </div>

          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-800 dark:text-gray-400">
                {t('tracking.totalPackages')}
              </span>
            </div>
            <p className="text-2xl font-bold text-gray-600 mt-2">
              {vehicles.reduce((sum, v) => sum + v.packages, 0)}
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
};