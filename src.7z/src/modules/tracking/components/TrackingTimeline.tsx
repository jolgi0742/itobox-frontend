import React from 'react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { 
  MapPin, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  Truck,
  Package,
  Home
} from 'lucide-react';
import { TrackingEvent } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface TrackingTimelineProps {
  events: TrackingEvent[];
  isLoading?: boolean;
}

export const TrackingTimeline: React.FC<TrackingTimelineProps> = ({
  events,
  isLoading = false
}) => {
  const { t, language } = useLanguage();

  const getEventIcon = (eventType: string, status: string) => {
    const iconClass = "h-5 w-5";
    
    if (status.toLowerCase().includes('delivered')) {
      return <Home className={`${iconClass} text-green-500`} />;
    }
    
    if (status.toLowerCase().includes('transit') || status.toLowerCase().includes('transport')) {
      return <Truck className={`${iconClass} text-blue-500`} />;
    }
    
    if (status.toLowerCase().includes('exception') || status.toLowerCase().includes('delay')) {
      return <AlertCircle className={`${iconClass} text-red-500`} />;
    }
    
    if (status.toLowerCase().includes('processed') || status.toLowerCase().includes('received')) {
      return <Package className={`${iconClass} text-purple-500`} />;
    }

    return <MapPin className={`${iconClass} text-gray-500`} />;
  };

  const getStatusColor = (status: string) => {
    if (status.toLowerCase().includes('delivered')) return 'text-green-600';
    if (status.toLowerCase().includes('transit')) return 'text-blue-600';
    if (status.toLowerCase().includes('exception')) return 'text-red-600';
    if (status.toLowerCase().includes('processed')) return 'text-purple-600';
    return 'text-gray-600';
  };

  const formatEventDate = (date: Date | string) => {
    return format(new Date(date), 'PPp', {
      locale: language === 'es' ? es : undefined
    });
  };

  if (isLoading) {
    return (
      <Card>
        <div className="p-6">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            {t('tracking.timeline')}
          </h3>
          <div className="space-y-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="animate-pulse flex space-x-4">
                <div className="w-10 h-10 bg-gray-200 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    );
  }

  if (events.length === 0) {
    return (
      <Card>
        <div className="p-6">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            {t('tracking.timeline')}
          </h3>
          <div className="text-center py-8 text-gray-500">
            <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>{t('tracking.noEvents')}</p>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-6">
          {t('tracking.timeline')}
        </h3>
        
        <div className="flow-root">
          <ul className="-mb-8">
            {events.map((event, eventIdx) => (
              <li key={event.id}>
                <div className="relative pb-8">
                  {eventIdx !== events.length - 1 ? (
                    <span
                      className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200"
                      aria-hidden="true"
                    />
                  ) : null}
                  
                  <div className="relative flex space-x-3">
                    <div>
                      <span className="h-8 w-8 rounded-full bg-white border-2 border-gray-300 flex items-center justify-center">
                        {getEventIcon(event.eventType, event.status)}
                      </span>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <p className={`text-sm font-medium ${getStatusColor(event.status)}`}>
                            {event.status}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                            {event.description}
                          </p>
                        </div>
                        
                        <div className="text-right">
                          <Badge
                            variant={event.source === 'api' ? 'primary' : event.source === 'manual' ? 'warning' : 'secondary'}
                            size="sm"
                          >
                            {t(`tracking.source.${event.source}`)}
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="mt-2 flex items-center justify-between text-xs text-gray-400">
                        <div className="flex items-center space-x-4">
                          {event.location && (
                            <div className="flex items-center space-x-1">
                              <MapPin className="h-3 w-3" />
                              <span>
                                {event.location.city}
                                {event.location.state && `, ${event.location.state}`}
                                {event.location.country && `, ${event.location.country}`}
                              </span>
                            </div>
                          )}
                          
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span>{formatEventDate(event.eventDateTime)}</span>
                          </div>
                        </div>
                      </div>

                      {event.metadata && Object.keys(event.metadata).length > 0 && (
                        <details className="mt-2">
                          <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-700">
                            {t('tracking.viewDetails')}
                          </summary>
                          <div className="mt-1 text-xs text-gray-400">
                            <pre className="whitespace-pre-wrap">
                              {JSON.stringify(event.metadata, null, 2)}
                            </pre>
                          </div>
                        </details>
                      )}
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Card>
  );
};
