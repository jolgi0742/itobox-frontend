import React, { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Alert } from '@/components/ui/Alert';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { 
  Search, 
  Package,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import { CourierType, TrackingUpdate } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { trackingService } from '@/services/tracking/trackingService';

interface TrackingSearchProps {
  onTrackingResult?: (result: TrackingUpdate) => void;
}

export const TrackingSearch: React.FC<TrackingSearchProps> = ({
  onTrackingResult
}) => {
  const [trackingNumber, setTrackingNumber] = useState('');
  const [courier, setCourier] = useState<CourierType>('UPS');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastResult, setLastResult] = useState<TrackingUpdate | null>(null);
  const { t } = useLanguage();

  const courierOptions = [
    { value: 'UPS', label: 'UPS' },
    { value: 'FedEx', label: 'FedEx' },
    { value: 'DHL', label: 'DHL' },
    { value: 'USPS', label: 'USPS' }
  ];

  const handleSearch = async () => {
    if (!trackingNumber.trim()) {
      setError(t('tracking.enterTrackingNumber'));
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await trackingService.getTrackingInfo(trackingNumber.trim(), courier);
      setLastResult(result);
      onTrackingResult?.(result);
    } catch (err: any) {
      setError(err.message || t('tracking.searchError'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleRefresh = async () => {
    if (!trackingNumber.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const result = await trackingService.refreshTrackingInfo(trackingNumber.trim(), courier);
      setLastResult(result);
      onTrackingResult?.(result);
    } catch (err: any) {
      setError(err.message || t('tracking.refreshError'));
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const openExternalTracking = () => {
    const urls = {
      UPS: `https://www.ups.com/track?tracknum=${trackingNumber}`,
      FedEx: `https://www.fedex.com/fedextrack/?tracknumbers=${trackingNumber}`,
      DHL: `https://www.dhl.com/en/express/tracking.html?AWB=${trackingNumber}`,
      USPS: `https://tools.usps.com/go/TrackConfirmAction?qtc_tLabels1=${trackingNumber}`
    };

    window.open(urls[courier], '_blank');
  };

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Package className="h-6 w-6 text-itobox-primary" />
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {t('tracking.searchTitle')}
          </h2>
        </div>

        <div className="space-y-4">
          {/* Search Form */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            <div className="md:col-span-6">
              <Input
                label={t('packages.trackingNumber')}
                value={trackingNumber}
                onChange={(e) => setTrackingNumber(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="1Z999AA1234567890"
                leftIcon={<Search className="h-4 w-4 text-gray-400" />}
              />
            </div>

            <div className="md:col-span-3">
              <Select
                label={t('packages.courier')}
                value={courier}
                onChange={(e) => setCourier(e.target.value as CourierType)}
                options={courierOptions}
              />
            </div>

            <div className="md:col-span-3 flex items-end space-x-2">
              <Button
                onClick={handleSearch}
                disabled={isLoading || !trackingNumber.trim()}
                className="flex-1"
              >
                {isLoading ? (
                  <LoadingSpinner size="sm" className="mr-2" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                {t('tracking.search')}
              </Button>

              {lastResult && (
                <Button
                  variant="outline"
                  onClick={handleRefresh}
                  disabled={isLoading}
                  title={t('tracking.refresh')}
                >
                  <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
                </Button>
              )}
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <Alert variant="error" onClose={() => setError(null)}>
              {error}
            </Alert>
          )}

          {/* Quick Results */}
          {lastResult && (
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-medium text-gray-900 dark:text-white">
                  {t('tracking.quickResult')}
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={openExternalTracking}
                >
                  <ExternalLink className="h-4 w-4 mr-1" />
                  {t('tracking.viewExternal')}
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-500">{t('tracking.status')}:</span>
                  <p className="font-medium">{lastResult.status}</p>
                </div>

                <div>
                  <span className="text-gray-500">{t('tracking.lastUpdate')}:</span>
                  <p className="font-medium">
                    {lastResult.lastUpdated.toLocaleString()}
                  </p>
                </div>

                {lastResult.estimatedDelivery && (
                  <div>
                    <span className="text-gray-500">{t('tracking.estimatedDelivery')}:</span>
                    <p className="font-medium">
                      {lastResult.estimatedDelivery.toLocaleDateString()}
                    </p>
                  </div>
                )}
              </div>

              {lastResult.events.length > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    <strong>{t('tracking.latestEvent')}:</strong>{' '}
                    {lastResult.events[0].description}
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </Card>
  );
};
