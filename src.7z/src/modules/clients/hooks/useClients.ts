import { useState, useEffect, useCallback } from 'react';
import { Client, SortOption, PaginationInfo } from '@/types';
import { clientService } from '@/services/api/clientService';
import { useDebounce } from '@/hooks/useDebounce';

interface ClientFilters {
  search?: string;
  status?: string;
}

interface UseClientsReturn {
  clients: Client[];
  selectedClient: Client | null;
  filters: ClientFilters;
  sort: SortOption;
  pagination: PaginationInfo;
  isLoading: boolean;
  error: string | null;
  setFilters: (filters: Partial<ClientFilters>) => void;
  setSort: (sort: SortOption) => void;
  setPage: (page: number) => void;
  setSelectedClient: (clientId: number | null) => void;
  refreshClients: () => Promise<void>;
  createClient: (clientData: Partial<Client>) => Promise<Client>;
  updateClient: (id: number, updates: Partial<Client>) => Promise<Client>;
  deleteClient: (id: number) => Promise<void>;
  clearError: () => void;
}

export const useClients = (): UseClientsReturn => {
  const [clients, setClients] = useState<Client[]>([]);
  const [selectedClient, setSelectedClientState] = useState<Client | null>(null);
  const [filters, setFiltersState] = useState<ClientFilters>({});
  const [sort, setSortState] = useState<SortOption>({ field: 'createdAt', direction: 'desc' });
  const [pagination, setPagination] = useState<PaginationInfo>({
    page: 1,
    pageSize: 10,
    totalItems: 0,
    totalPages: 0
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const debouncedSearch = useDebounce(filters.search, 300);

  const fetchClients = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await clientService.getClients({
        search: debouncedSearch,
        status: filters.status,
        page: pagination.page,
        pageSize: pagination.pageSize
      });

      setClients(response.data);
      setPagination(response.pagination || pagination);
    } catch (err: any) {
      setError(err.message || 'Error al cargar clientes');
    } finally {
      setIsLoading(false);
    }
  }, [filters, debouncedSearch, pagination.page, pagination.pageSize]);

  useEffect(() => {
    fetchClients();
  }, [fetchClients]);

  const setFilters = useCallback((newFilters: Partial<ClientFilters>) => {
    setFiltersState(prev => ({ ...prev, ...newFilters }));
    setPagination(prev => ({ ...prev, page: 1 })); // Reset to first page
  }, []);

  const setSort = useCallback((newSort: SortOption) => {
    setSortState(newSort);
    setPagination(prev => ({ ...prev, page: 1 })); // Reset to first page
  }, []);

  const setPage = useCallback((page: number) => {
    setPagination(prev => ({ ...prev, page }));
  }, []);

  const setSelectedClient = useCallback(async (clientId: number | null) => {
    if (clientId === null) {
      setSelectedClientState(null);
      return;
    }

    const existingClient = clients.find(client => client.id === clientId);
    if (existingClient) {
      setSelectedClientState(existingClient);
    } else {
      try {
        const clientData = await clientService.getClient(clientId);
        setSelectedClientState(clientData);
      } catch (err: any) {
        setError(err.message || 'Error al cargar cliente');
      }
    }
  }, [clients]);

  const refreshClients = useCallback(async () => {
    await fetchClients();
  }, [fetchClients]);

  const createClient = useCallback(async (clientData: Partial<Client>) => {
    try {
      const newClient = await clientService.createClient(clientData);
      setClients(prev => [newClient, ...prev]);
      return newClient;
    } catch (err: any) {
      setError(err.message || 'Error al crear cliente');
      throw err;
    }
  }, []);

  const updateClient = useCallback(async (id: number, updates: Partial<Client>) => {
    try {
      const updatedClient = await clientService.updateClient(id, updates);
      setClients(prev => prev.map(client => client.id === id ? updatedClient : client));
      
      if (selectedClient?.id === id) {
        setSelectedClientState(updatedClient);
      }
      
      return updatedClient;
    } catch (err: any) {
      setError(err.message || 'Error al actualizar cliente');
      throw err;
    }
  }, [selectedClient]);

  const deleteClient = useCallback(async (id: number) => {
    try {
      await clientService.deleteClient(id);
      setClients(prev => prev.filter(client => client.id !== id));
      
      if (selectedClient?.id === id) {
        setSelectedClientState(null);
      }
    } catch (err: any) {
      setError(err.message || 'Error al eliminar cliente');
      throw err;
    }
  }, [selectedClient]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    clients,
    selectedClient,
    filters,
    sort,
    pagination,
    isLoading,
    error,
    setFilters,
    setSort,
    setPage,
    setSelectedClient,
    refreshClients,
    createClient,
    updateClient,
    deleteClient,
    clearError
  };
};