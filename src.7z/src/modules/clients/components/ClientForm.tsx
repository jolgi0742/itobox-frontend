import React, { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Alert } from '@/components/ui/Alert';
import { 
  User, 
  Save, 
  X,
  Building,
  MapPin,
  CreditCard,
  Shuffle
} from 'lucide-react';
import { Client } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { useForm } from '@/hooks/useForm';
import { validationService } from '@/services/utils/validationService';
import { clientService } from '@/services/api/clientService';

interface ClientFormData {
  customerCode: string;
  contactPerson: string;
  phone: string;
  companyName?: string;
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
  };
  creditLimit: number;
  status: 'active' | 'inactive' | 'suspended';
}

interface ClientFormProps {
  client?: Client;
  onSubmit: (data: ClientFormData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export const ClientForm: React.FC<ClientFormProps> = ({
  client,
  onSubmit,
  onCancel,
  isLoading = false
}) => {
  const { t } = useLanguage();
  const [generatingCode, setGeneratingCode] = useState(false);

  const isEditing = !!client;

  const {
    values,
    errors,
    touched,
    isValid,
    handleChange,
    handleBlur,
    handleSubmit,
    setValue
  } = useForm<ClientFormData>({
    initialValues: {
      customerCode: client?.customerCode || '',
      contactPerson: client?.contactPerson || '',
      phone: client?.phone || '',
      companyName: client?.companyName || '',
      address: {
        street: client?.address?.street || '',
        city: client?.address?.city || '',
        state: client?.address?.state || '',
        zipCode: client?.address?.zipCode || '',
        country: client?.address?.country || 'Costa Rica'
      },
      creditLimit: client?.creditLimit || 0,
      status: client?.status || 'active'
    },
    validate: async (values) => {
      const result = await validationService.validate(validationService.clientSchema, values);
      return result.errors;
    },
    onSubmit: async (values) => {
      await onSubmit(values);
    }
  });

  const statusOptions = [
    { value: 'active', label: t('status.active') },
    { value: 'inactive', label: t('status.inactive') },
    { value: 'suspended', label: t('status.suspended') }
  ];

  const countryOptions = [
    { value: 'Costa Rica', label: 'Costa Rica' },
    { value: 'Panama', label: 'Panamá' },
    { value: 'Nicaragua', label: 'Nicaragua' },
    { value: 'Guatemala', label: 'Guatemala' },
    { value: 'Honduras', label: 'Honduras' },
    { value: 'El Salvador', label: 'El Salvador' }
  ];

  const generateCustomerCode = async () => {
    if (isEditing) return;

    setGeneratingCode(true);
    try {
      const response = await clientService.generateCustomerCode();
      setValue('customerCode', response.customerCode);
    } catch (error) {
      console.error('Error generating customer code:', error);
    } finally {
      setGeneratingCode(false);
    }
  };

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <User className="h-6 w-6 text-itobox-primary" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              {isEditing ? t('clients.editClient') : t('clients.newClient')}
            </h2>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={onCancel}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              {t('clients.basicInfo')}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="relative">
                <Input
                  label={t('clients.customerCode')}
                  value={values.customerCode}
                  onChange={handleChange('customerCode')}
                  onBlur={handleBlur('customerCode')}
                  error={touched.customerCode ? errors.customerCode : undefined}
                  placeholder="CLI-001"
                  disabled={isEditing}
                  required
                />
                {!isEditing && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={generateCustomerCode}
                    disabled={generatingCode}
                    className="absolute right-2 top-8"
                  >
                    <Shuffle className="h-3 w-3" />
                  </Button>
                )}
              </div>

              <Select
                label={t('clients.status')}
                value={values.status}
                onChange={handleChange('status')}
                onBlur={handleBlur('status')}
                error={touched.status ? errors.status : undefined}
                options={statusOptions}
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label={t('clients.contactPerson')}
                value={values.contactPerson}
                onChange={handleChange('contactPerson')}
                onBlur={handleBlur('contactPerson')}
                error={touched.contactPerson ? errors.contactPerson : undefined}
                placeholder="Juan Pérez"
                required
              />

              <Input
                label={t('clients.phone')}
                type="tel"
                value={values.phone}
                onChange={handleChange('phone')}
                onBlur={handleBlur('phone')}
                error={touched.phone ? errors.phone : undefined}
                placeholder="+506 1234 5678"
                required
              />
            </div>

            <Input
              label={`${t('clients.companyName')} (${t('common.optional')})`}
              value={values.companyName}
              onChange={handleChange('companyName')}
              onBlur={handleBlur('companyName')}
              error={touched.companyName ? errors.companyName : undefined}
              placeholder="Mi Empresa S.A."
              leftIcon={<Building className="h-4 w-4 text-gray-400" />}
            />
          </div>

          {/* Address Information */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <MapPin className="h-5 w-5 text-gray-500" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {t('clients.addressInfo')}
              </h3>
            </div>
            
            <Input
              label={t('address.street')}
              value={values.address.street}
              onChange={(e) => setValue('address', {
                ...values.address,
                street: e.target.value
              })}
              placeholder="Avenida Central 123"
              required
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label={t('address.city')}
                value={values.address.city}
                onChange={(e) => setValue('address', {
                  ...values.address,
                  city: e.target.value
                })}
                placeholder="San José"
                required
              />

              <Input
                label={t('address.state')}
                value={values.address.state}
                onChange={(e) => setValue('address', {
                  ...values.address,
                  state: e.target.value
                })}
                placeholder="San José"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label={t('address.zipCode')}
                value={values.address.zipCode}
                onChange={(e) => setValue('address', {
                  ...values.address,
                  zipCode: e.target.value
                })}
                placeholder="10101"
                required
              />

              <Select
                label={t('address.country')}
                value={values.address.country}
                onChange={(e) => setValue('address', {
                  ...values.address,
                  country: e.target.value
                })}
                options={countryOptions}
                required
              />
            </div>
          </div>

          {/* Financial Information */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <CreditCard className="h-5 w-5 text-gray-500" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">
                {t('clients.financialInfo')}
              </h3>
            </div>
            
            <Input
              label={`${t('clients.creditLimit')} (USD)`}
              type="number"
              step="0.01"
              min="0"
              value={values.creditLimit}
              onChange={handleChange('creditLimit')}
              onBlur={handleBlur('creditLimit')}
              error={touched.creditLimit ? errors.creditLimit : undefined}
              placeholder="1000.00"
            />
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200 dark:border-gray-700">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={isLoading}
            >
              {t('common.cancel')}
            </Button>
            
            <Button
              type="submit"
              variant="primary"
              isLoading={isLoading}
              disabled={!isValid}
            >
              <Save className="h-4 w-4 mr-2" />
              {isEditing ? t('common.update') : t('common.create')}
            </Button>
          </div>
        </form>
      </div>
    </Card>
  );
};