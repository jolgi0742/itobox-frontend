import React from 'react';
import { Table } from '@/components/ui/Table';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { 
  Eye, 
  Edit, 
  Trash2, 
  Mail,
  Phone,
  Building,
  MapPin
} from 'lucide-react';
import { Client, SortOption } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

interface ClientTableProps {
  clients: Client[];
  isLoading?: boolean;
  sortKey?: string;
  sortDirection?: 'asc' | 'desc';
  onSort?: (key: string) => void;
  onView?: (clientId: number) => void;
  onEdit?: (clientId: number) => void;
  onDelete?: (clientId: number) => void;
}

export const ClientTable: React.FC<ClientTableProps> = ({
  clients,
  isLoading = false,
  sortKey,
  sortDirection,
  onSort,
  onView,
  onEdit,
  onDelete
}) => {
  const { t, language } = useLanguage();
  const { user } = useAuth();

  const getStatusBadge = (status: Client['status']) => {
    const variants = {
      active: 'success' as const,
      inactive: 'secondary' as const,
      suspended: 'danger' as const
    };

    return (
      <Badge variant={variants[status]} size="sm">
        {t(`status.${status}`)}
      </Badge>
    );
  };

  const columns = [
    {
      key: 'customerCode',
      header: t('clients.customerCode'),
      sortable: true,
      render: (value: string, client: Client) => (
        <div className="flex items-center space-x-2">
          <Building className="h-4 w-4 text-gray-400" />
          <span className="font-medium">{value}</span>
        </div>
      )
    },
    {
      key: 'contactPerson',
      header: t('clients.contactPerson'),
      sortable: true,
      render: (value: string, client: Client) => (
        <div>
          <div className="font-medium">{value}</div>
          {client.companyName && (
            <div className="text-sm text-gray-500">{client.companyName}</div>
          )}
        </div>
      )
    },
    {
      key: 'contact',
      header: t('clients.contact'),
      render: (value: any, client: Client) => (
        <div className="space-y-1">
          <div className="flex items-center space-x-1 text-sm">
            <Mail className="h-3 w-3 text-gray-400" />
            <span>{client.userId ? 'Registrado' : 'Sin registro'}</span>
          </div>
          <div className="flex items-center space-x-1 text-sm">
            <Phone className="h-3 w-3 text-gray-400" />
            <span>{client.phone}</span>
          </div>
        </div>
      )
    },
    {
      key: 'address',
      header: t('clients.address'),
      render: (value: Client['address'], client: Client) => (
        <div className="flex items-start space-x-1">
          <MapPin className="h-3 w-3 text-gray-400 mt-1" />
          <div className="text-sm">
            <div>{value.city}, {value.state}</div>
            <div className="text-gray-500">{value.country}</div>
          </div>
        </div>
      )
    },
    {
      key: 'status',
      header: t('clients.status'),
      sortable: true,
      render: (value: Client['status']) => getStatusBadge(value)
    },
    {
      key: 'balance',
      header: t('clients.balance'),
      sortable: true,
      render: (value: any, client: Client) => (
        <div className="text-right">
          <div className="font-medium">
            ${client.currentBalance.toLocaleString()}
          </div>
          <div className="text-xs text-gray-500">
            Límite: ${client.creditLimit.toLocaleString()}
          </div>
        </div>
      )
    },
    {
      key: 'createdAt',
      header: t('clients.createdAt'),
      sortable: true,
      render: (value: Date) => (
        <div className="text-sm">
          {formatDistanceToNow(new Date(value), { 
            addSuffix: true,
            locale: language === 'es' ? es : undefined
          })}
        </div>
      )
    },
    {
      key: 'actions',
      header: t('clients.actions'),
      render: (value: any, client: Client) => (
        <div className="flex items-center space-x-2">
          {onView && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onView(client.id)}
              title={t('common.view')}
            >
              <Eye className="h-4 w-4" />
            </Button>
          )}
          
          {onEdit && (user?.role === 'admin' || user?.role === 'agent') && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEdit(client.id)}
              title={t('common.edit')}
            >
              <Edit className="h-4 w-4" />
            </Button>
          )}
          
          {onDelete && user?.role === 'admin' && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(client.id)}
              title={t('common.delete')}
              className="text-red-600 hover:text-red-700"
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          )}
        </div>
      )
    }
  ];

  return (
    <Table
      data={clients}
      columns={columns}
      loading={isLoading}
      sortKey={sortKey}
      sortDirection={sortDirection}
      onSort={onSort}
      emptyMessage={t('clients.noClients')}
    />
  );
};