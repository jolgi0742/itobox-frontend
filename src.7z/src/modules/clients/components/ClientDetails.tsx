import React from 'react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { 
  User,
  Building,
  MapPin,
  Phone,
  Mail,
  CreditCard,
  Calendar,
  Package,
  TrendingUp,
  Edit
} from 'lucide-react';
import { Client } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface ClientDetailsProps {
  client: Client;
  onEdit?: () => void;
  onClose?: () => void;
}

export const ClientDetails: React.FC<ClientDetailsProps> = ({
  client,
  onEdit,
  onClose
}) => {
  const { t, language } = useLanguage();
  const { user } = useAuth();

  const getStatusBadge = (status: Client['status']) => {
    const variants = {
      active: 'success' as const,
      inactive: 'secondary' as const,
      suspended: 'danger' as const
    };

    return (
      <Badge variant={variants[status]} size="md">
        {t(`status.${status}`)}
      </Badge>
    );
  };

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'N/A';
    return format(new Date(date), 'PPp', {
      locale: language === 'es' ? es : undefined
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-itobox-primary/10 rounded-lg">
                <User className="h-6 w-6 text-itobox-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {client.contactPerson}
                </h1>
                <p className="text-gray-500 dark:text-gray-400">
                  {client.customerCode}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {getStatusBadge(client.status)}
              
              {onEdit && (user?.role === 'admin' || user?.role === 'agent') && (
                <Button variant="outline" size="sm" onClick={onEdit}>
                  <Edit className="h-4 w-4 mr-2" />
                  {t('common.edit')}
                </Button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center space-x-3">
              <Phone className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">{t('clients.phone')}</p>
                <p className="font-medium">{client.phone}</p>
              </div>
            </div>

            {client.companyName && (
              <div className="flex items-center space-x-3">
                <Building className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">{t('clients.company')}</p>
                  <p className="font-medium">{client.companyName}</p>
                </div>
              </div>
            )}

            <div className="flex items-center space-x-3">
              <Calendar className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">{t('clients.memberSince')}</p>
                <p className="font-medium">{formatDate(client.createdAt)}</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Address Information */}
      <Card>
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {t('clients.addressInfo')}
          </h2>
          
          <div className="flex items-start space-x-3">
            <MapPin className="h-5 w-5 text-gray-400 mt-1" />
            <div>
              <div className="text-sm text-gray-500 mt-1">
                <p>{client.address.street}</p>
                <p>
                  {client.address.city}, {client.address.state}{' '}
                  {client.address.zipCode}
                </p>
                <p>{client.address.country}</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Miami Address */}
      {client.miamiAddress && (
        <Card>
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {t('clients.miamiAddress')}
            </h2>
            
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-blue-500 mt-1" />
                <div>
                  <p className="font-medium text-blue-800 dark:text-blue-400">
                    ITOBOX - {client.customerCode}
                  </p>
                  <div className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                    <p>{client.miamiAddress.line1}</p>
                    {client.miamiAddress.line2 && <p>{client.miamiAddress.line2}</p>}
                    {client.miamiAddress.suite && <p>Suite {client.miamiAddress.suite}</p>}
                    <p>
                      {client.miamiAddress.city}, {client.miamiAddress.state}{' '}
                      {client.miamiAddress.zipCode}
                    </p>
                    <p>Estados Unidos</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Financial Information */}
      <Card>
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {t('clients.financialInfo')}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center space-x-3">
              <CreditCard className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">{t('clients.creditLimit')}</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  ${client.creditLimit.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <TrendingUp className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">{t('clients.currentBalance')}</p>
                <p className={`text-2xl font-bold ${
                  client.currentBalance < 0 ? 'text-red-600' : 'text-green-600'
                }`}>
                  ${client.currentBalance.toLocaleString()}
                </p>
              </div>
            </div>
          </div>

          {/* Balance Bar */}
          <div className="mt-4">
            <div className="flex justify-between text-sm text-gray-500 mb-1">
              <span>{t('clients.balanceUsage')}</span>
              <span>
                {((Math.abs(client.currentBalance) / client.creditLimit) * 100).toFixed(1)}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`h-2 rounded-full ${
                  client.currentBalance < 0 ? 'bg-red-500' : 'bg-green-500'
                }`}
                style={{
                  width: `${Math.min((Math.abs(client.currentBalance) / client.creditLimit) * 100, 100)}%`
                }}
              />
            </div>
          </div>
        </div>
      </Card>

      {/* Billing Information */}
      {client.billingInfo && (
        <Card>
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {t('clients.billingInfo')}
            </h2>
            
            <div className="space-y-3">
              {client.billingInfo.taxId && (
                <div>
                  <span className="text-sm text-gray-500">{t('clients.taxId')}:</span>
                  <span className="ml-2 font-medium">{client.billingInfo.taxId}</span>
                </div>
              )}
              
              <div>
                <span className="text-sm text-gray-500">{t('clients.paymentMethod')}:</span>
                <span className="ml-2 font-medium">
                  {t(`payment.${client.billingInfo.paymentMethod.type}`)}
                </span>
              </div>
              
              <div>
                <span className="text-sm text-gray-500">{t('clients.creditTerms')}:</span>
                <span className="ml-2 font-medium">
                  {client.billingInfo.creditTerms} {t('common.days')}
                </span>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Preferences */}
      {client.preferences && (
        <Card>
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {t('clients.preferences')}
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <span className="text-sm text-gray-500">{t('clients.shippingMethod')}:</span>
                <span className="ml-2 font-medium">
                  {t(`shipping.${client.preferences.shippingMethod}`)}
                </span>
              </div>
              
              <div>
                <span className="text-sm text-gray-500">{t('clients.consolidation')}:</span>
                <span className="ml-2">
                  <Badge 
                    variant={client.preferences.consolidation ? 'success' : 'secondary'} 
                    size="sm"
                  >
                    {client.preferences.consolidation ? t('common.yes') : t('common.no')}
                  </Badge>
                </span>
              </div>
              
              <div>
                <span className="text-sm text-gray-500">{t('clients.insurance')}:</span>
                <span className="ml-2">
                  <Badge 
                    variant={client.preferences.insuranceOptIn ? 'success' : 'secondary'} 
                    size="sm"
                  >
                    {client.preferences.insuranceOptIn ? t('common.yes') : t('common.no')}
                  </Badge>
                </span>
              </div>
              
              <div>
                <span className="text-sm text-gray-500">{t('clients.customsDeclaration')}:</span>
                <span className="ml-2 font-medium">
                  {t(`customs.${client.preferences.customsDeclaration}`)}
                </span>
              </div>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};