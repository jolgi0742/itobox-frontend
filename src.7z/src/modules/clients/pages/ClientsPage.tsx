import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Pagination } from '@/components/ui/Pagination';
import { Modal } from '@/components/ui/Modal';
import { Alert } from '@/components/ui/Alert';
import { ClientTable } from '../components/ClientTable';
import { ClientForm } from '../components/ClientForm';
import { ClientDetails } from '../components/ClientDetails';
import { useClients } from '../hooks/useClients';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNotifications } from '@/contexts/NotificationContext';
import { 
  Plus, 
  Download, 
  Upload,
  RefreshCw,
  Search,
  Filter
} from 'lucide-react';

export const ClientsPage: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [editingClient, setEditingClient] = useState<number | null>(null);
  const { user } = useAuth();
  const { t } = useLanguage();
  const { showToast } = useNotifications();

  const {
    clients,
    selectedClient,
    filters,
    sort,
    pagination,
    isLoading,
    error,
    setFilters,
    setSort,
    setPage,
    setSelectedClient,
    refreshClients,
    createClient,
    updateClient,
    deleteClient,
    clearError
  } = useClients();

  const handleAddNew = () => {
    setEditingClient(null);
    setShowForm(true);
  };

  const handleEdit = (clientId: number) => {
    setEditingClient(clientId);
    setSelectedClient(clientId).then(() => {
      setShowForm(true);
    });
  };

  const handleView = (clientId: number) => {
    setSelectedClient(clientId).then(() => {
      setShowDetails(true);
    });
  };

  const handleDelete = async (clientId: number) => {
    if (window.confirm(t('clients.confirmDelete'))) {
      try {
        await deleteClient(clientId);
        showToast(t('clients.deleteSuccess'), 'success');
      } catch (err) {
        showToast(t('clients.deleteError'), 'error');
      }
    }
  };

  const handleFormSubmit = async (formData: any) => {
    try {
      if (editingClient) {
        await updateClient(editingClient, formData);
        showToast(t('clients.updateSuccess'), 'success');
      } else {
        await createClient(formData);
        showToast(t('clients.createSuccess'), 'success');
      }
      setShowForm(false);
      setEditingClient(null);
    } catch (err) {
      showToast(
        editingClient ? t('clients.updateError') : t('clients.createError'),
        'error'
      );
    }
  };

  const handleSort = (key: string) => {
    const direction = sort.field === key && sort.direction === 'asc' ? 'desc' : 'asc';
    setSort({ field: key, direction });
  };

  const statusOptions = [
    { value: '', label: t('common.all') },
    { value: 'active', label: t('status.active') },
    { value: 'inactive', label: t('status.inactive') },
    { value: 'suspended', label: t('status.suspended') }
  ];

  const canCreateClients = user?.role === 'admin' || user?.role === 'agent';

  return (
    <MainLayout>
      <div className="space-y-6">
        <PageHeader
          title="clients.title"
          description="clients.description"
          breadcrumbs={[
            { name: 'clients.title', current: true }
          ]}
          actions={
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={refreshClients}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                {t('common.refresh')}
              </Button>
              
              {user?.role === 'admin' && (
                <>
                  <Button variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    {t('clients.import')}
                  </Button>
                  
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    {t('clients.export')}
                  </Button>
                </>
              )}
              
              {canCreateClients && (
                <Button variant="primary" onClick={handleAddNew}>
                  <Plus className="h-4 w-4 mr-2" />
                  {t('clients.addNew')}
                </Button>
              )}
            </div>
          }
        />

        {error && (
          <Alert variant="error" onClose={clearError}>
            {error}
          </Alert>
        )}

        {/* Filters */}
        <Card className="p-4">
          <div className="flex items-center space-x-2 mb-4">
            <Filter className="h-5 w-5 text-gray-500" />
            <h3 className="font-medium text-gray-900 dark:text-white">
              {t('common.filters')}
            </h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              placeholder={t('clients.searchPlaceholder')}
              value={filters.search || ''}
              onChange={(e) => setFilters({ search: e.target.value || undefined })}
              leftIcon={<Search className="h-4 w-4 text-gray-400" />}
            />

            <Select
              value={filters.status || ''}
              onChange={(e) => setFilters({ status: e.target.value || undefined })}
              options={statusOptions}
            />

            <Button
              variant="outline"
              onClick={() => setFilters({})}
              disabled={!filters.search && !filters.status}
            >
              {t('filters.clear')}
            </Button>
          </div>
        </Card>

        {/* Results Summary */}
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {t('clients.resultsCount', {
                total: pagination.totalItems,
                start: ((pagination.page - 1) * pagination.pageSize) + 1,
                end: Math.min(pagination.page * pagination.pageSize, pagination.totalItems)
              })}
            </p>
            
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-500">{t('common.itemsPerPage')}:</span>
              <select
                value={pagination.pageSize}
                onChange={(e) => setFilters({ pageSize: parseInt(e.target.value) } as any)}
                className="border border-gray-300 rounded px-2 py-1 text-sm"
              >
                <option value={10}>10</option>
                <option value={25}>25</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
          </div>
        </Card>

        {/* Client Table */}
        <Card>
          <ClientTable
            clients={clients}
            isLoading={isLoading}
            sortKey={sort.field}
            sortDirection={sort.direction}
            onSort={handleSort}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        </Card>

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex justify-center">
            <Pagination
              currentPage={pagination.page}
              totalPages={pagination.totalPages}
              onPageChange={setPage}
            />
          </div>
        )}

        {/* Client Form Modal */}
        <Modal
          isOpen={showForm}
          onClose={() => {
            setShowForm(false);
            setEditingClient(null);
          }}
          size="xl"
          showCloseButton={false}
        >
          <ClientForm
            client={editingClient ? selectedClient : undefined}
            onSubmit={handleFormSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingClient(null);
            }}
            isLoading={isLoading}
          />
        </Modal>

        {/* Client Details Modal */}
        <Modal
          isOpen={showDetails}
          onClose={() => setShowDetails(false)}
          size="xl"
          title={t('clients.clientDetails')}
        >
          {selectedClient && (
            <ClientDetails
              client={selectedClient}
              onEdit={() => {
                setShowDetails(false);
                handleEdit(selectedClient.id);
              }}
            />
          )}
        </Modal>
      </div>
    </MainLayout>
  );
};
