export { ClientTable } from './components/ClientTable';
export { ClientForm } from './components/ClientForm';
export { ClientDetails } from './components/ClientDetails';

export { useClients } from './hooks/useClients';

export { ClientsPage } from './pages/ClientsPage';