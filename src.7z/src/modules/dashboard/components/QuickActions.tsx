import React from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { 
  Plus, 
  Upload, 
  Download, 
  Search,
  Users,
  Package,
  FileText,
  Settings
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'react-router-dom';

interface QuickAction {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  href: string;
  roles: string[];
  color: 'primary' | 'secondary' | 'success' | 'warning';
}

const quickActions: QuickAction[] = [
  {
    id: 'add-package',
    title: 'packages.addNew',
    description: 'packages.addDescription',
    icon: <Plus className="h-5 w-5" />,
    href: '/packages/new',
    roles: ['admin', 'agent'],
    color: 'primary'
  },
  {
    id: 'add-client',
    title: 'clients.addNew',
    description: 'clients.addDescription',
    icon: <Users className="h-5 w-5" />,
    href: '/clients/new',
    roles: ['admin', 'agent'],
    color: 'secondary'
  },
  {
    id: 'search-packages',
    title: 'packages.search',
    description: 'packages.searchDescription',
    icon: <Search className="h-5 w-5" />,
    href: '/packages',
    roles: ['admin', 'agent', 'client'],
    color: 'success'
  },
  {
    id: 'reports',
    title: 'reports.generate',
    description: 'reports.generateDescription',
    icon: <FileText className="h-5 w-5" />,
    href: '/reports',
    roles: ['admin'],
    color: 'warning'
  },
  {
    id: 'import-data',
    title: 'data.import',
    description: 'data.importDescription',
    icon: <Upload className="h-5 w-5" />,
    href: '/import',
    roles: ['admin'],
    color: 'primary'
  },
  {
    id: 'export-data',
    title: 'data.export',
    description: 'data.exportDescription',
    icon: <Download className="h-5 w-5" />,
    href: '/export',
    roles: ['admin', 'agent'],
    color: 'secondary'
  }
];

export const QuickActions: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();

  const filteredActions = quickActions.filter(action =>
    action.roles.includes(user?.role || '')
  );

  return (
    <Card>
      <div className="p-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
          {t('dashboard.quickActions')}
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredActions.map((action) => (
            <Link key={action.id} to={action.href}>
              <Button
                variant="outline"
                className="w-full h-auto p-4 flex flex-col items-start text-left hover:bg-gray-50 dark:hover:bg-gray-700"
              >
                <div className="flex items-center space-x-3 mb-2">
                  <div className={`p-2 rounded-lg bg-${action.color === 'primary' ? 'itobox-primary' : action.color === 'secondary' ? 'blue-500' : action.color === 'success' ? 'green-500' : 'yellow-500'}/10`}>
                    {action.icon}
                  </div>
                  <span className="font-medium">{t(action.title)}</span>
                </div>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {t(action.description)}
                </span>
              </Button>
            </Link>
          ))}
        </div>
      </div>
    </Card>
  );
};