import React from 'react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { 
  Package, 
  User, 
  MapPin, 
  Clock,
  ExternalLink,
  MoreHorizontal 
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

interface ActivityItem {
  id: string;
  type: 'package' | 'user' | 'tracking' | 'system';
  title: string;
  description: string;
  timestamp: Date;
  metadata?: Record<string, any>;
  status?: 'success' | 'warning' | 'error' | 'info';
}

interface RecentActivityProps {
  activities: ActivityItem[];
  isLoading?: boolean;
  onViewAll?: () => void;
}

export const RecentActivity: React.FC<RecentActivityProps> = ({
  activities,
  isLoading = false,
  onViewAll
}) => {
  const { t, language } = useLanguage();

  const getActivityIcon = (type: ActivityItem['type']) => {
    const iconClass = "h-4 w-4";
    
    switch (type) {
      case 'package':
        return <Package className={iconClass} />;
      case 'user':
        return <User className={iconClass} />;
      case 'tracking':
        return <MapPin className={iconClass} />;
      case 'system':
        return <Clock className={iconClass} />;
      default:
        return <MoreHorizontal className={iconClass} />;
    }
  };

  const getStatusBadge = (status?: ActivityItem['status']) => {
    if (!status) return null;

    const variants = {
      success: 'success' as const,
      warning: 'warning' as const,
      error: 'danger' as const,
      info: 'info' as const
    };

    return (
      <Badge variant={variants[status]} size="sm">
        {t(`status.${status}`)}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <div className="p-6">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
            {t('dashboard.recentActivity')}
          </h3>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="animate-pulse flex space-x-3">
                <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            {t('dashboard.recentActivity')}
          </h3>
          {onViewAll && (
            <Button variant="ghost" size="sm" onClick={onViewAll}>
              <ExternalLink className="h-4 w-4 mr-1" />
              {t('common.viewAll')}
            </Button>
          )}
        </div>

        <div className="space-y-4">
          {activities.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p>{t('dashboard.noRecentActivity')}</p>
            </div>
          ) : (
            activities.map((activity) => (
              <div key={activity.id} className="flex space-x-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-gray-100 dark:bg-gray-600 rounded-full flex items-center justify-center">
                    {getActivityIcon(activity.type)}
                  </div>
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                      {activity.title}
                    </p>
                    {getStatusBadge(activity.status)}
                  </div>
                  
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    {activity.description}
                  </p>
                  
                  <p className="text-xs text-gray-400 mt-1">
                    {formatDistanceToNow(activity.timestamp, { 
                      addSuffix: true,
                      locale: language === 'es' ? es : undefined
                    })}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </Card>
  );
};
