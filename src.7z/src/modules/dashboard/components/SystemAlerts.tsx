import React from 'react';
import { Card } from '@/components/ui/Card';
import { Alert } from '@/components/ui/Alert';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { 
  AlertTriangle, 
  Info, 
  CheckCircle, 
  XCircle,
  X 
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface SystemAlert {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  message: string;
  timestamp: Date;
  dismissible: boolean;
  actionText?: string;
  onAction?: () => void;
}

interface SystemAlertsProps {
  alerts: SystemAlert[];
  onDismiss: (id: string) => void;
}

export const SystemAlerts: React.FC<SystemAlertsProps> = ({
  alerts,
  onDismiss
}) => {
  const { t } = useLanguage();

  if (alerts.length === 0) {
    return null;
  }

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            {t('dashboard.systemAlerts')}
          </h3>
          <Badge variant="secondary" size="sm">
            {alerts.length}
          </Badge>
        </div>

        <div className="space-y-3">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border-l-4 ${
                alert.type === 'error' ? 'border-red-500 bg-red-50' :
                alert.type === 'warning' ? 'border-yellow-500 bg-yellow-50' :
                alert.type === 'success' ? 'border-green-500 bg-green-50' :
                'border-blue-500 bg-blue-50'
              }`}
            >
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  {alert.type === 'error' && <XCircle className="h-5 w-5 text-red-500" />}
                  {alert.type === 'warning' && <AlertTriangle className="h-5 w-5 text-yellow-500" />}
                  {alert.type === 'success' && <CheckCircle className="h-5 w-5 text-green-500" />}
                  {alert.type === 'info' && <Info className="h-5 w-5 text-blue-500" />}
                </div>
                
                <div className="ml-3 flex-1">
                  <h4 className={`text-sm font-medium ${
                    alert.type === 'error' ? 'text-red-800' :
                    alert.type === 'warning' ? 'text-yellow-800' :
                    alert.type === 'success' ? 'text-green-800' :
                    'text-blue-800'
                  }`}>
                    {alert.title}
                  </h4>
                  <p className={`mt-1 text-sm ${
                    alert.type === 'error' ? 'text-red-700' :
                    alert.type === 'warning' ? 'text-yellow-700' :
                    alert.type === 'success' ? 'text-green-700' :
                    'text-blue-700'
                  }`}>
                    {alert.message}
                  </p>
                  
                  {alert.actionText && alert.onAction && (
                    <div className="mt-3">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={alert.onAction}
                      >
                        {alert.actionText}
                      </Button>
                    </div>
                  )}
                </div>

                {alert.dismissible && (
                  <button
                    onClick={() => onDismiss(alert.id)}
                    className={`ml-2 inline-flex ${
                      alert.type === 'error' ? 'text-red-400 hover:text-red-600' :
                      alert.type === 'warning' ? 'text-yellow-400 hover:text-yellow-600' :
                      alert.type === 'success' ? 'text-green-400 hover:text-green-600' :
                      'text-blue-400 hover:text-blue-600'
                    }`}
                  >
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};
