import { useState, useEffect } from 'react';
import { DashboardMetrics, ChartData } from '@/types';
import { dashboardService } from '@/services/dashboard/dashboardService';
import { useAuth } from '@/contexts/AuthContext';

interface UseDashboardDataReturn {
  metrics: DashboardMetrics | null;
  revenueChartData: ChartData[];
  packageStatusData: ChartData[];
  recentActivities: any[];
  systemAlerts: any[];
  isLoading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

export const useDashboardData = (timeRange: 'day' | 'week' | 'month' | 'year' = 'month'): UseDashboardDataReturn => {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [revenueChartData, setRevenueChartData] = useState<ChartData[]>([]);
  const [packageStatusData, setPackageStatusData] = useState<ChartData[]>([]);
  const [recentActivities, setRecentActivities] = useState<any[]>([]);
  const [systemAlerts, setSystemAlerts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const [
        metricsData,
        revenueData,
        statusData,
        activitiesData,
        alertsData
      ] = await Promise.all([
        dashboardService.getMetrics(timeRange),
        dashboardService.getRevenueChart(timeRange),
        dashboardService.getPackageStatusChart(),
        dashboardService.getRecentActivities(10),
        dashboardService.getAlerts()
      ]);

      setMetrics(metricsData);
      setRevenueChartData(revenueData);
      setPackageStatusData(statusData);
      setRecentActivities(activitiesData);
      setSystemAlerts(alertsData);
    } catch (err: any) {
      setError(err.message || 'Error al cargar datos del dashboard');
      console.error('Dashboard data fetch error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchData();
    }
  }, [user, timeRange]);

  const refreshData = async () => {
    await fetchData();
  };

  return {
    metrics,
    revenueChartData,
    packageStatusData,
    recentActivities,
    systemAlerts,
    isLoading,
    error,
    refreshData
  };
};