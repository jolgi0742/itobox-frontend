import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Button } from '@/components/ui/Button';
import { Alert } from '@/components/ui/Alert';
import { MetricCard } from '../components/MetricCard';
import { RecentActivity } from '../components/RecentActivity';
import { PackageStatusChart } from '../components/PackageStatusChart';
import { RevenueChart } from '../components/RevenueChart';
import { QuickActions } from '../components/QuickActions';
import { SystemAlerts } from '../components/SystemAlerts';
import { useDashboardData } from '../hooks/useDashboardData';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { 
  Package, 
  Users, 
  TrendingUp, 
  Clock,
  RefreshCw
} from 'lucide-react';

export const DashboardPage: React.FC = () => {
  const [timeRange, setTimeRange] = useState<'month' | 'quarter' | 'year'>('month');
  const { user } = useAuth();
  const { t } = useLanguage();
  
  const {
    metrics,
    revenueChartData,
    packageStatusData,
    recentActivities,
    systemAlerts,
    isLoading,
    error,
    refreshData
  } = useDashboardData(timeRange);

  const handleDismissAlert = (alertId: string) => {
    // Implementation for dismissing alerts
    console.log('Dismiss alert:', alertId);
  };

  const getMetricCards = () => {
    if (!metrics) return [];

    const cards = [];

    // Cards for all roles
    cards.push({
      title: t('dashboard.totalPackages'),
      value: metrics.packages.totalPackages,
      change: {
        value: metrics.packages.monthlyGrowth,
        period: t('dashboard.thisMonth'),
        trend: metrics.packages.monthlyGrowth > 0 ? 'up' as const : 'down' as const
      },
      icon: <Package className="h-5 w-5" />,
      color: 'blue' as const
    });

    if (user?.role !== 'client') {
      cards.push({
        title: t('dashboard.totalClients'),
        value: metrics.clients.totalClients,
        change: {
          value: metrics.clients.clientRetentionRate,
          period: t('dashboard.retention'),
          trend: 'up' as const
        },
        icon: <Users className="h-5 w-5" />,
        color: 'green' as const
      });
    }

    if (user?.role === 'admin') {
      cards.push(
        {
          title: t('dashboard.totalRevenue'),
          value: `$${metrics.financial.totalRevenue.toLocaleString()}`,
          change: {
            value: metrics.financial.revenueGrowth,
            period: t('dashboard.thisMonth'),
            trend: metrics.financial.revenueGrowth > 0 ? 'up' as const : 'down' as const
          },
          icon: <TrendingUp className="h-5 w-5" />,
          color: 'purple' as const
        },
        {
          title: t('dashboard.avgProcessingTime'),
          value: `${metrics.operational.averageProcessingTime}h`,
          change: {
            value: -12,
            period: t('dashboard.thisWeek'),
            trend: 'up' as const
          },
          icon: <Clock className="h-5 w-5" />,
          color: 'yellow' as const
        }
      );
    }

    return cards;
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <PageHeader
          title="dashboard.title"
          description="dashboard.welcome"
          actions={
            <Button
              variant="outline"
              onClick={refreshData}
              disabled={isLoading}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
              {t('common.refresh')}
            </Button>
          }
        />

        {error && (
          <Alert variant="error" onClose={() => window.location.reload()}>
            {error}
          </Alert>
        )}

        {/* System Alerts */}
        {systemAlerts.length > 0 && (
          <SystemAlerts
            alerts={systemAlerts}
            onDismiss={handleDismissAlert}
          />
        )}

        {/* Metric Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {getMetricCards().map((card, index) => (
            <MetricCard
              key={index}
              title={card.title}
              value={card.value}
              change={card.change}
              icon={card.icon}
              color={card.color}
              isLoading={isLoading}
            />
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {user?.role === 'admin' && (
            <RevenueChart
              data={revenueChartData}
              isLoading={isLoading}
              timeRange={timeRange}
              onTimeRangeChange={setTimeRange}
            />
          )}
          
          <PackageStatusChart
            data={packageStatusData}
            isLoading={isLoading}
          />
        </div>

        {/* Activity and Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <RecentActivity
            activities={recentActivities}
            isLoading={isLoading}
            onViewAll={() => console.log('View all activities')}
          />
          
          <QuickActions />
        </div>
      </div>
    </MainLayout>
  );
};
