import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Pagination } from '@/components/ui/Pagination';
import { Modal } from '@/components/ui/Modal';
import { Alert } from '@/components/ui/Alert';
import { PackageFilters } from '../components/PackageFilters';
import { PackageTable } from '../components/PackageTable';
import { PackageForm } from '../components/PackageForm';
import { PackageDetails } from '../components/PackageDetails';
import { usePackages } from '@/hooks/usePackages';
import { useAuth } from '@/contexts/AuthContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNotifications } from '@/contexts/NotificationContext';
import { 
  Plus, 
  Download, 
  Upload,
  RefreshCw
} from 'lucide-react';

export const PackagesPage: React.FC = () => {
  const [showForm, setShowForm] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [editingPackage, setEditingPackage] = useState<number | null>(null);
  const { user } = useAuth();
  const { t } = useLanguage();
  const { showToast } = useNotifications();

  const {
    packages,
    selectedPackage,
    filters,
    sort,
    pagination,
    isLoading,
    error,
    setFilters,
    setSort,
    setPage,
    setSelectedPackage,
    refreshPackages,
    createPackage,
    updatePackage,
    deletePackage,
    clearError
  } = usePackages();

  const handleAddNew = () => {
    setEditingPackage(null);
    setShowForm(true);
  };

  const handleEdit = (packageId: number) => {
    setEditingPackage(packageId);
    setSelectedPackage(packageId).then(() => {
      setShowForm(true);
    });
  };

  const handleView = (packageId: number) => {
    setSelectedPackage(packageId).then(() => {
      setShowDetails(true);
    });
  };

  const handleDelete = async (packageId: number) => {
    if (window.confirm(t('packages.confirmDelete'))) {
      try {
        await deletePackage(packageId);
        showToast(t('packages.deleteSuccess'), 'success');
      } catch (err) {
        showToast(t('packages.deleteError'), 'error');
      }
    }
  };

  const handleFormSubmit = async (formData: any) => {
    try {
      if (editingPackage) {
        await updatePackage(editingPackage, formData);
        showToast(t('packages.updateSuccess'), 'success');
      } else {
        await createPackage(formData);
        showToast(t('packages.createSuccess'), 'success');
      }
      setShowForm(false);
      setEditingPackage(null);
    } catch (err) {
      showToast(
        editingPackage ? t('packages.updateError') : t('packages.createError'),
        'error'
      );
    }
  };

  const handleSort = (key: string) => {
    const direction = sort.field === key && sort.direction === 'asc' ? 'desc' : 'asc';
    setSort({ field: key, direction });
  };

  const handleTrack = (trackingNumber: string, courier: string) => {
    window.open(`https://www.${courier.toLowerCase()}.com/tracking/${trackingNumber}`, '_blank');
  };

  const canCreatePackages = user?.role === 'admin' || user?.role === 'agent';

  return (
    <MainLayout>
      <div className="space-y-6">
        <PageHeader
          title="packages.title"
          description="packages.description"
          breadcrumbs={[
            { name: 'packages.title', current: true }
          ]}
          actions={
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={refreshPackages}
                disabled={isLoading}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                {t('common.refresh')}
              </Button>
              
              {user?.role === 'admin' && (
                <>
                  <Button variant="outline">
                    <Upload className="h-4 w-4 mr-2" />
                    {t('packages.import')}
                  </Button>
                  
                  <Button variant="outline">
                    <Download className="h-4 w-4 mr-2" />
                    {t('packages.export')}
                  </Button>
                </>
              )}
              
              {canCreatePackages && (
                <Button variant="primary" onClick={handleAddNew}>
                  <Plus className="h-4 w-4 mr-2" />
                  {t('packages.addNew')}
                </Button>
              )}
            </div>
          }
        />

        {error && (
          <Alert variant="error" onClose={clearError}>
            {error}
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <PackageFilters
              filters={filters}
              onFiltersChange={setFilters}
              onClearFilters={() => setFilters({})}
              isLoading={isLoading}
            />
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* Results Summary */}
            <Card className="p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {t('packages.resultsCount', {
                    total: pagination.totalItems,
                    start: ((pagination.page - 1) * pagination.pageSize) + 1,
                    end: Math.min(pagination.page * pagination.pageSize, pagination.totalItems)
                  })}
                </p>
                
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-500">{t('common.itemsPerPage')}:</span>
                  <select
                    value={pagination.pageSize}
                    onChange={(e) => setFilters({ ...filters, pageSize: parseInt(e.target.value) })}
                    className="border border-gray-300 rounded px-2 py-1 text-sm"
                  >
                    <option value={10}>10</option>
                    <option value={25}>25</option>
                    <option value={50}>50</option>
                    <option value={100}>100</option>
                  </select>
                </div>
              </div>
            </Card>

            {/* Package Table */}
            <Card>
              <PackageTable
                packages={packages}
                isLoading={isLoading}
                sortKey={sort.field}
                sortDirection={sort.direction}
                onSort={handleSort}
                onView={handleView}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onTrack={handleTrack}
              />
            </Card>

            {/* Pagination */}
            {pagination.totalPages > 1 && (
              <div className="flex justify-center">
                <Pagination
                  currentPage={pagination.page}
                  totalPages={pagination.totalPages}
                  onPageChange={setPage}
                />
              </div>
            )}
          </div>
        </div>

        {/* Package Form Modal */}
        <Modal
          isOpen={showForm}
          onClose={() => {
            setShowForm(false);
            setEditingPackage(null);
          }}
          size="xl"
          showCloseButton={false}
        >
          <PackageForm
            package_={editingPackage ? selectedPackage : undefined}
            onSubmit={handleFormSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingPackage(null);
            }}
            isLoading={isLoading}
          />
        </Modal>

        {/* Package Details Modal */}
        <Modal
          isOpen={showDetails}
          onClose={() => setShowDetails(false)}
          size="xl"
          title={t('packages.packageDetails')}
        >
          {selectedPackage && (
            <PackageDetails
              package_={selectedPackage}
              onEdit={() => {
                setShowDetails(false);
                handleEdit(selectedPackage.id);
              }}
              onTrack={() => handleTrack(selectedPackage.trackingNumber, selectedPackage.courier)}
            />
          )}
        </Modal>
      </div>
    </MainLayout>
  );
};