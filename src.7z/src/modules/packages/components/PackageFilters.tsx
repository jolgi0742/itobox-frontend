import React from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Badge } from '@/components/ui/Badge';
import { 
  Search, 
  Filter, 
  X, 
  Calendar,
  Package,
  Truck
} from 'lucide-react';
import { PackageFilters as PackageFiltersType, PackageStatus, CourierType, PackagePriority } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';

interface PackageFiltersProps {
  filters: PackageFiltersType;
  onFiltersChange: (filters: Partial<PackageFiltersType>) => void;
  onClearFilters: () => void;
  isLoading?: boolean;
}

export const PackageFilters: React.FC<PackageFiltersProps> = ({
  filters,
  onFiltersChange,
  onClearFilters,
  isLoading = false
}) => {
  const { t } = useLanguage();

  const statusOptions = [
    { value: 'pending', label: t('status.pending') },
    { value: 'received', label: t('status.received') },
    { value: 'processing', label: t('status.processing') },
    { value: 'in_transit', label: t('status.in_transit') },
    { value: 'delivered', label: t('status.delivered') },
    { value: 'exception', label: t('status.exception') },
    { value: 'returned', label: t('status.returned') }
  ];

  const courierOptions = [
    { value: 'UPS', label: 'UPS' },
    { value: 'FedEx', label: 'FedEx' },
    { value: 'DHL', label: 'DHL' },
    { value: 'USPS', label: 'USPS' },
    { value: 'Other', label: t('courier.other') }
  ];

  const priorityOptions = [
    { value: 'standard', label: t('priority.standard') },
    { value: 'express', label: t('priority.express') },
    { value: 'urgent', label: t('priority.urgent') }
  ];

  const hasActiveFilters = !!(
    filters.search ||
    (filters.status && filters.status.length > 0) ||
    (filters.courier && filters.courier.length > 0) ||
    (filters.priority && filters.priority.length > 0) ||
    filters.dateRange
  );

  const handleMultiSelectChange = (key: keyof PackageFiltersType, value: string) => {
    const currentValues = filters[key] as string[] || [];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    
    onFiltersChange({ [key]: newValues.length > 0 ? newValues : undefined });
  };

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-500" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              {t('common.filters')}
            </h3>
            {hasActiveFilters && (
              <Badge variant="primary" size="sm">
                {t('filters.active')}
              </Badge>
            )}
          </div>
          
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearFilters}
              disabled={isLoading}
            >
              <X className="h-4 w-4 mr-1" />
              {t('filters.clear')}
            </Button>
          )}
        </div>

        <div className="space-y-4">
          {/* Search */}
          <div>
            <Input
              label={t('common.search')}
              placeholder={t('packages.searchPlaceholder')}
              value={filters.search || ''}
              onChange={(e) => onFiltersChange({ search: e.target.value || undefined })}
              leftIcon={<Search className="h-4 w-4 text-gray-400" />}
            />
          </div>

          {/* Status Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('packages.status')}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {statusOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleMultiSelectChange('status', option.value)}
                  disabled={isLoading}
                  className={`px-3 py-2 text-sm rounded-md border transition-colors ${
                    filters.status?.includes(option.value as PackageStatus)
                      ? 'bg-itobox-primary text-white border-itobox-primary'
                      : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* Courier Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('packages.courier')}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {courierOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleMultiSelectChange('courier', option.value)}
                  disabled={isLoading}
                  className={`px-3 py-2 text-sm rounded-md border transition-colors flex items-center justify-center ${
                    filters.courier?.includes(option.value as CourierType)
                      ? 'bg-itobox-secondary text-white border-itobox-secondary'
                      : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600'
                  }`}
                >
                  <Truck className="h-4 w-4 mr-1" />
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* Priority Filter */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('packages.priority')}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {priorityOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleMultiSelectChange('priority', option.value)}
                  disabled={isLoading}
                  className={`px-3 py-2 text-sm rounded-md border transition-colors ${
                    filters.priority?.includes(option.value as PackagePriority)
                      ? 'bg-yellow-500 text-white border-yellow-500'
                      : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>

          {/* Date Range */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('filters.dateFrom')}
              </label>
              <Input
                type="date"
                value={filters.dateRange?.startDate.toISOString().split('T')[0] || ''}
                onChange={(e) => {
                  if (e.target.value) {
                    onFiltersChange({
                      dateRange: {
                        startDate: new Date(e.target.value),
                        endDate: filters.dateRange?.endDate || new Date()
                      }
                    });
                  }
                }}
                leftIcon={<Calendar className="h-4 w-4 text-gray-400" />}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                {t('filters.dateTo')}
              </label>
              <Input
                type="date"
                value={filters.dateRange?.endDate.toISOString().split('T')[0] || ''}
                onChange={(e) => {
                  if (e.target.value) {
                    onFiltersChange({
                      dateRange: {
                        startDate: filters.dateRange?.startDate || new Date(),
                        endDate: new Date(e.target.value)
                      }
                    });
                  }
                }}
                leftIcon={<Calendar className="h-4 w-4 text-gray-400" />}
              />
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};