import React, { useState } from 'react';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Alert } from '@/components/ui/Alert';
import { 
  Package as PackageIcon, 
  Save, 
  X,
  Upload
} from 'lucide-react';
import { Package, PackageFormData, CourierType, PackagePriority } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { useForm } from '@/hooks/useForm';
import { validationService } from '@/services/utils/validationService';

interface PackageFormProps {
  package_?: Package;
  onSubmit: (data: PackageFormData) => Promise<void>;
  onCancel: () => void;
  isLoading?: boolean;
}

export const PackageForm: React.FC<PackageFormProps> = ({
  package_,
  onSubmit,
  onCancel,
  isLoading = false
}) => {
  const { t } = useLanguage();
  const [photos, setPhotos] = useState<File[]>([]);

  const isEditing = !!package_;

  const {
    values,
    errors,
    touched,
    isValid,
    handleChange,
    handleBlur,
    handleSubmit,
    setValue
  } = useForm<PackageFormData>({
    initialValues: {
      trackingNumber: package_?.trackingNumber || '',
      courier: package_?.courier || 'UPS',
      description: package_?.packageDetails?.description || '',
      weight: package_?.packageDetails?.weight || 0,
      dimensions: {
        length: package_?.packageDetails?.dimensions?.length || 0,
        width: package_?.packageDetails?.dimensions?.width || 0,
        height: package_?.packageDetails?.dimensions?.height || 0
      },
      value: package_?.packageDetails?.value || 0,
      recipientName: package_?.destinationInfo?.recipientName || '',
      recipientAddress: {
        street: package_?.destinationInfo?.address?.street || '',
        city: package_?.destinationInfo?.address?.city || '',
        state: package_?.destinationInfo?.address?.state || '',
        zipCode: package_?.destinationInfo?.address?.zipCode || '',
        country: package_?.destinationInfo?.address?.country || 'Costa Rica'
      },
      specialInstructions: package_?.specialInstructions || ''
    },
    validate: async (values) => {
      const result = await validationService.validate(validationService.packageSchema, values);
      return result.errors;
    },
    onSubmit: async (values) => {
      await onSubmit(values);
    }
  });

  const courierOptions = [
    { value: 'UPS', label: 'UPS' },
    { value: 'FedEx', label: 'FedEx' },
    { value: 'DHL', label: 'DHL' },
    { value: 'USPS', label: 'USPS' },
    { value: 'Other', label: t('courier.other') }
  ];

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setPhotos(prev => [...prev, ...files]);
  };

  const removePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <Card>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <PackageIcon className="h-6 w-6 text-itobox-primary" />
            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
              {isEditing ? t('packages.editPackage') : t('packages.newPackage')}
            </h2>
          </div>
          
          <Button
            variant="ghost"
            size="sm"
            onClick={onCancel}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label={t('packages.trackingNumber')}
              value={values.trackingNumber}
              onChange={handleChange('trackingNumber')}
              onBlur={handleBlur('trackingNumber')}
              error={touched.trackingNumber ? errors.trackingNumber : undefined}
              placeholder="1Z999AA1234567890"
              required
            />

            <Select
              label={t('packages.courier')}
              value={values.courier}
              onChange={handleChange('courier')}
              onBlur={handleBlur('courier')}
              error={touched.courier ? errors.courier : undefined}
              options={courierOptions}
              required
            />
          </div>

          {/* Package Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              {t('packages.packageDetails')}
            </h3>
            
            <Input
              label={t('packages.description')}
              value={values.description}
              onChange={handleChange('description')}
              onBlur={handleBlur('description')}
              error={touched.description ? errors.description : undefined}
              placeholder={t('packages.descriptionPlaceholder')}
              required
            />

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Input
                label={`${t('packages.weight')} (kg)`}
                type="number"
                step="0.1"
                min="0"
                value={values.weight}
                onChange={handleChange('weight')}
                onBlur={handleBlur('weight')}
                error={touched.weight ? errors.weight : undefined}
                required
              />

              <Input
                label={`${t('packages.length')} (cm)`}
                type="number"
                step="0.1"
                min="0"
                value={values.dimensions.length}
                onChange={(e) => setValue('dimensions', {
                  ...values.dimensions,
                  length: parseFloat(e.target.value) || 0
                })}
                required
              />

              <Input
                label={`${t('packages.width')} (cm)`}
                type="number"
                step="0.1"
                min="0"
                value={values.dimensions.width}
                onChange={(e) => setValue('dimensions', {
                  ...values.dimensions,
                  width: parseFloat(e.target.value) || 0
                })}
                required
              />

              <Input
                label={`${t('packages.height')} (cm)`}
                type="number"
                step="0.1"
                min="0"
                value={values.dimensions.height}
                onChange={(e) => setValue('dimensions', {
                  ...values.dimensions,
                  height: parseFloat(e.target.value) || 0
                })}
                required
              />
            </div>

            <Input
              label={`${t('packages.value')} (USD)`}
              type="number"
              step="0.01"
              min="0"
              value={values.value}
              onChange={handleChange('value')}
              onBlur={handleBlur('value')}
              error={touched.value ? errors.value : undefined}
              required
            />
          </div>

          {/* Recipient Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              {t('packages.recipientInfo')}
            </h3>
            
            <Input
              label={t('packages.recipientName')}
              value={values.recipientName}
              onChange={handleChange('recipientName')}
              onBlur={handleBlur('recipientName')}
              error={touched.recipientName ? errors.recipientName : undefined}
              required
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label={t('address.street')}
                value={values.recipientAddress.street}
                onChange={(e) => setValue('recipientAddress', {
                  ...values.recipientAddress,
                  street: e.target.value
                })}
                required
              />

              <Input
                label={t('address.city')}
                value={values.recipientAddress.city}
                onChange={(e) => setValue('recipientAddress', {
                  ...values.recipientAddress,
                  city: e.target.value
                })}
                required
              />

              <Input
                label={t('address.state')}
                value={values.recipientAddress.state}
                onChange={(e) => setValue('recipientAddress', {
                  ...values.recipientAddress,
                  state: e.target.value
                })}
                required
              />

              <Input
                label={t('address.zipCode')}
                value={values.recipientAddress.zipCode}
                onChange={(e) => setValue('recipientAddress', {
                  ...values.recipientAddress,
                  zipCode: e.target.value
                })}
                required
              />
            </div>

            <Input
              label={t('address.country')}
              value={values.recipientAddress.country}
              onChange={(e) => setValue('recipientAddress', {
                ...values.recipientAddress,
                country: e.target.value
              })}
              required
            />
          </div>

          {/* Special Instructions */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('packages.specialInstructions')}
            </label>
            <textarea
              value={values.specialInstructions}
              onChange={(e) => setValue('specialInstructions', e.target.value)}
              className="w-full rounded-lg border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:border-itobox-primary focus:outline-none focus:ring-1 focus:ring-itobox-primary"
              rows={3}
              placeholder={t('packages.specialInstructionsPlaceholder')}
            />
          </div>

          {/* Photo Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('packages.photos')}
            </label>
            
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm text-gray-600 mb-2">
                {t('packages.photoUploadText')}
              </p>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
                id="photo-upload"
              />
              <label
                htmlFor="photo-upload"
                className="cursor-pointer text-itobox-primary hover:text-itobox-accent"
              >
                {t('packages.selectPhotos')}
              </label>
            </div>

            {photos.length > 0 && (
              <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
                {photos.map((photo, index) => (
                  <div key={index} className="relative">
                    <img
                      src={URL.createObjectURL(photo)}
                      alt={`Photo ${index + 1}`}
                      className="w-full h-24 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => removePhoto(index)}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 text-xs"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200 dark:border-gray-700">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={isLoading}
            >
              {t('common.cancel')}
            </Button>
            
            <Button
              type="submit"
              variant="primary"
              isLoading={isLoading}
              disabled={!isValid}
            >
              <Save className="h-4 w-4 mr-2" />
              {isEditing ? t('common.update') : t('common.create')}
            </Button>
          </div>
        </form>
      </div>
    </Card>
  );
};