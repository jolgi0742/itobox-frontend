import React from 'react';
import { Card } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { 
  Package as PackageIcon,
  MapPin,
  User,
  Truck,
  Clock,
  DollarSign,
  Ruler,
  Weight,
  ExternalLink,
  Edit
} from 'lucide-react';
import { Package } from '@/types';
import { useLanguage } from '@/contexts/LanguageContext';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

interface PackageDetailsProps {
  package_: Package;
  onEdit?: () => void;
  onTrack?: () => void;
  onClose?: () => void;
}

export const PackageDetails: React.FC<PackageDetailsProps> = ({
  package_,
  onEdit,
  onTrack,
  onClose
}) => {
  const { t, language } = useLanguage();
  const { user } = useAuth();

  const getStatusBadge = (status: Package['status']) => {
    const variants = {
      pending: 'warning' as const,
      received: 'info' as const,
      processing: 'primary' as const,
      in_transit: 'secondary' as const,
      delivered: 'success' as const,
      exception: 'danger' as const,
      returned: 'danger' as const
    };

    return (
      <Badge variant={variants[status]} size="md">
        {t(`status.${status}`)}
      </Badge>
    );
  };

  const formatDate = (date: Date | string | undefined) => {
    if (!date) return 'N/A';
    return format(new Date(date), 'PPp', {
      locale: language === 'es' ? es : undefined
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-itobox-primary/10 rounded-lg">
                <PackageIcon className="h-6 w-6 text-itobox-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {package_.packageCode}
                </h1>
                <p className="text-gray-500 dark:text-gray-400">
                  {t('packages.packageDetails')}
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {getStatusBadge(package_.status)}
              
              {onEdit && (user?.role === 'admin' || user?.role === 'agent') && (
                <Button variant="outline" size="sm" onClick={onEdit}>
                  <Edit className="h-4 w-4 mr-2" />
                  {t('common.edit')}
                </Button>
              )}
              
              {onTrack && (
                <Button variant="primary" size="sm" onClick={onTrack}>
                  <MapPin className="h-4 w-4 mr-2" />
                  {t('packages.track')}
                </Button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center space-x-3">
              <Truck className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">{t('packages.courier')}</p>
                <p className="font-medium">{package_.courier}</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <Clock className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">{t('packages.createdAt')}</p>
                <p className="font-medium">{formatDate(package_.createdAt)}</p>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <DollarSign className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">{t('packages.value')}</p>
                <p className="font-medium">${package_.packageDetails.value.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Tracking Information */}
      <Card>
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {t('packages.trackingInfo')}
          </h2>
          
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {t('packages.trackingNumber')}
                </p>
                <p className="font-mono text-lg font-medium">
                  {package_.trackingNumber}
                </p>
              </div>
              
              {onTrack && (
                <Button variant="outline" size="sm" onClick={onTrack}>
                  <ExternalLink className="h-4 w-4 mr-2" />
                  {t('packages.trackExternal')}
                </Button>
              )}
            </div>
          </div>
        </div>
      </Card>

      {/* Package Details */}
      <Card>
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {t('packages.packageInfo')}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                {t('packages.description')}
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                {package_.packageDetails.description}
              </p>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Weight className="h-4 w-4 text-gray-400" />
                <span className="text-sm">
                  {package_.packageDetails.weight} {package_.packageDetails.weightUnit}
                </span>
              </div>

              <div className="flex items-center space-x-3">
                <Ruler className="h-4 w-4 text-gray-400" />
                <span className="text-sm">
                  {package_.packageDetails.dimensions.length} x{' '}
                  {package_.packageDetails.dimensions.width} x{' '}
                  {package_.packageDetails.dimensions.height} {package_.packageDetails.dimensions.unit}
                </span>
              </div>

              <div className="flex items-center space-x-3">
                <DollarSign className="h-4 w-4 text-gray-400" />
                <span className="text-sm">
                  ${package_.packageDetails.value.toLocaleString()} {package_.packageDetails.currency}
                </span>
              </div>
            </div>
          </div>

          {package_.specialInstructions && (
            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
              <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                {t('packages.specialInstructions')}
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                {package_.specialInstructions}
              </p>
            </div>
          )}
        </div>
      </Card>

      {/* Client Information */}
      {package_.client && user?.role !== 'client' && (
        <Card>
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {t('packages.clientInfo')}
            </h2>
            
            <div className="flex items-start space-x-3">
              <User className="h-5 w-5 text-gray-400 mt-1" />
              <div>
                <p className="font-medium">{package_.client.contactPerson}</p>
                <p className="text-sm text-gray-500">{package_.client.customerCode}</p>
                {package_.client.companyName && (
                  <p className="text-sm text-gray-600">{package_.client.companyName}</p>
                )}
                <p className="text-sm text-gray-500">{package_.client.phone}</p>
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Destination Information */}
      <Card>
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            {t('packages.destinationInfo')}
          </h2>
          
          <div className="flex items-start space-x-3">
            <MapPin className="h-5 w-5 text-gray-400 mt-1" />
            <div>
              <p className="font-medium">{package_.destinationInfo.recipientName}</p>
              {package_.destinationInfo.recipientCompany && (
                <p className="text-sm text-gray-600">{package_.destinationInfo.recipientCompany}</p>
              )}
              <div className="text-sm text-gray-500 mt-1">
                <p>{package_.destinationInfo.address.street}</p>
                <p>
                  {package_.destinationInfo.address.city}, {package_.destinationInfo.address.state}{' '}
                  {package_.destinationInfo.address.zipCode}
                </p>
                <p>{package_.destinationInfo.address.country}</p>
              </div>
              <p className="text-sm text-gray-500 mt-1">{package_.destinationInfo.phone}</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Photos */}
      {package_.photos && package_.photos.length > 0 && (
        <Card>
          <div className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
              {t('packages.photos')}
            </h2>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {package_.photos.map((photo, index) => (
                <div key={photo.id} className="relative group">
                  <img
                    src={photo.url}
                    alt={photo.description || `Photo ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg cursor-pointer hover:opacity-75 transition-opacity"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 rounded-lg transition-all" />
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
};