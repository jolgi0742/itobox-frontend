import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { 
  Search, 
  ChevronDown, 
  ChevronRight,
  MessageCircle,
  Mail,
  Phone,
  FileText
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const HelpPage: React.FC = () => {
  const { t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);

  const faqCategories = [
    {
      id: 'general',
      name: t('help.general'),
      faqs: [
        {
          id: 'what-is-itobox',
          question: t('help.whatIsItobox'),
          answer: t('help.whatIsItoboxAnswer')
        },
        {
          id: 'how-to-register',
          question: t('help.howToRegister'),
          answer: t('help.howToRegisterAnswer')
        }
      ]
    },
    {
      id: 'packages',
      name: t('help.packages'),
      faqs: [
        {
          id: 'how-to-track',
          question: t('help.howToTrack'),
          answer: t('help.howToTrackAnswer')
        },
        {
          id: 'package-status',
          question: t('help.packageStatus'),
          answer: t('help.packageStatusAnswer')
        }
      ]
    },
    {
      id: 'billing',
      name: t('help.billing'),
      faqs: [
        {
          id: 'payment-methods',
          question: t('help.paymentMethods'),
          answer: t('help.paymentMethodsAnswer')
        },
        {
          id: 'billing-cycle',
          question: t('help.billingCycle'),
          answer: t('help.billingCycleAnswer')
        }
      ]
    }
  ];

  const contactMethods = [
    {
      icon: MessageCircle,
      title: t('help.liveChat'),
      description: t('help.liveChatDescription'),
      action: t('help.startChat'),
      available: true
    },
    {
      icon: Mail,
      title: t('help.email'),
      description: 'support@itobox.com',
      action: t('help.sendEmail'),
      available: true
    },
    {
      icon: Phone,
      title: t('help.phone'),
      description: '+506 2222-3333',
      action: t('help.callUs'),
      available: false
    }
  ];

  const handleFaqToggle = (faqId: string) => {
    setExpandedFaq(expandedFaq === faqId ? null : faqId);
  };

  const filteredFaqs = faqCategories.map(category => ({
    ...category,
    faqs: category.faqs.filter(faq =>
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.faqs.length > 0);

  return (
    <MainLayout>
      <div className="space-y-6">
        <PageHeader
          title="help.title"
          description="help.description"
          breadcrumbs={[
            { name: 'help.title', current: true }
          ]}
        />

        {/* Search */}
        <Card>
          <div className="p-6">
            <div className="max-w-2xl mx-auto">
              <Input
                placeholder={t('help.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                leftIcon={<Search className="h-5 w-5 text-gray-400" />}
                className="text-lg"
              />
            </div>
          </div>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* FAQ */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                  {t('help.frequentQuestions')}
                </h2>

                <div className="space-y-6">
                  {filteredFaqs.map((category) => (
                    <div key={category.id}>
                      <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
                        {category.name}
                      </h3>
                      <div className="space-y-2">
                        {category.faqs.map((faq) => (
                          <div key={faq.id} className="border border-gray-200 dark:border-gray-700 rounded-lg">
                            <button
                              onClick={() => handleFaqToggle(faq.id)}
                              className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                            >
                              <span className="font-medium">{faq.question}</span>
                              {expandedFaq === faq.id ? (
                                <ChevronDown className="h-5 w-5 text-gray-500" />
                              ) : (
                                <ChevronRight className="h-5 w-5 text-gray-500" />
                              )}
                            </button>
                            {expandedFaq === faq.id && (
                              <div className="px-4 pb-4">
                                <p className="text-gray-600 dark:text-gray-400">{faq.answer}</p>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {filteredFaqs.length === 0 && searchQuery && (
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">{t('help.noResults')}</p>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Contact */}
          <div className="lg:col-span-1">
            <Card>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                  {t('help.contactSupport')}
                </h2>

                <div className="space-y-4">
                  {contactMethods.map((method, index) => {
                    const Icon = method.icon;
                    return (
                      <div
                        key={index}
                        className={`p-4 border rounded-lg ${
                          method.available
                            ? 'border-gray-200 dark:border-gray-700'
                            : 'border-gray-100 dark:border-gray-800 opacity-50'
                        }`}
                      >
                        <div className="flex items-start space-x-3">
                          <Icon className="h-6 w-6 text-itobox-primary mt-1" />
                          <div className="flex-1">
                            <h3 className="font-medium text-gray-900 dark:text-white">
                              {method.title}
                            </h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                              {method.description}
                            </p>
                            <Button
                              variant="outline"
                              size="sm"
                              className="mt-3"
                              disabled={!method.available}
                            >
                              {method.action}
                            </Button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                  <h4 className="font-medium text-blue-800 dark:text-blue-400 mb-2">
                    {t('help.businessHours')}
                  </h4>
                  <p className="text-sm text-blue-700 dark:text-blue-300">
                    {t('help.businessHoursDetails')}
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default HelpPage;