import React from 'react';
import { useAuth } from '@/hooks/useAuth';

const DashboardPage: React.FC = () => {
  console.log('🏠 DashboardPage renderizando...');
  
  const { user, logout } = useAuth();
  
  console.log('👤 Usuario en dashboard:', user);
  
  const handleLogout = async () => {
    console.log('🚪 Iniciando logout...');
    try {
      await logout();
      console.log('✅ Logout exitoso');
      window.location.href = '/auth/login';
    } catch (error) {
      console.error('❌ Error en logout:', error);
    }
  };

  return (
    <div style={{ 
      padding: '50px', 
      backgroundColor: '#e3f2fd', 
      minHeight: '100vh',
      fontFamily: 'Arial, sans-serif'
    }}>
      <div style={{ 
        maxWidth: '800px', 
        margin: '0 auto',
        backgroundColor: 'white',
        padding: '30px',
        borderRadius: '10px',
        boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
      }}>
        <h1 style={{ color: '#1976d2', marginBottom: '20px' }}>
          🎉 ¡Dashboard Funcionando!
        </h1>
        
        <div style={{ 
          backgroundColor: '#f5f5f5', 
          padding: '20px', 
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          <h3>👤 Información del Usuario:</h3>
          {user ? (
            <div>
              <p><strong>Nombre:</strong> {user.firstName} {user.lastName}</p>
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Rol:</strong> {user.role}</p>
              <p><strong>Empresa:</strong> {user.company || 'No especificada'}</p>
            </div>
          ) : (
            <p style={{ color: 'red' }}>❌ No hay información de usuario</p>
          )}
        </div>
        
        <div style={{ marginBottom: '20px' }}>
          <h3>🚀 Acciones:</h3>
          <button 
            onClick={handleLogout}
            style={{
              backgroundColor: '#f44336',
              color: 'white',
              padding: '10px 20px',
              border: 'none',
              borderRadius: '5px',
              cursor: 'pointer',
              fontSize: '16px'
            }}
          >
            🚪 Cerrar Sesión
          </button>
        </div>
        
        <div style={{ 
          backgroundColor: '#e8f5e8', 
          padding: '15px', 
          borderRadius: '5px',
          border: '1px solid #4caf50'
        }}>
          <h4>✅ Estado del Sistema:</h4>
          <p>• Login: Funcionando</p>
          <p>• Dashboard: Cargado</p>
          <p>• Autenticación: Activa</p>
          <p>• Usuario: {user ? 'Identificado' : 'No identificado'}</p>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;