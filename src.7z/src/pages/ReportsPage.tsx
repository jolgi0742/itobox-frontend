import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { 
  FileText, 
  Download, 
  Calendar,
  BarChart3,
  Users,
  Package,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

const ReportsPage: React.FC = () => {
  const { t } = useLanguage();
  const [selectedReport, setSelectedReport] = useState('');
  const [dateRange, setDateRange] = useState({
    startDate: '',
    endDate: ''
  });

  const reportTypes = [
    {
      id: 'packages',
      name: t('reports.packages'),
      description: t('reports.packagesDescription'),
      icon: Package,
      color: 'text-blue-600'
    },
    {
      id: 'clients',
      name: t('reports.clients'),
      description: t('reports.clientsDescription'),
      icon: Users,
      color: 'text-green-600'
    },
    {
      id: 'financial',
      name: t('reports.financial'),
      description: t('reports.financialDescription'),
      icon: DollarSign,
      color: 'text-purple-600'
    },
    {
      id: 'performance',
      name: t('reports.performance'),
      description: t('reports.performanceDescription'),
      icon: TrendingUp,
      color: 'text-orange-600'
    }
  ];

  const formatOptions = [
    { value: 'pdf', label: 'PDF' },
    { value: 'excel', label: 'Excel' },
    { value: 'csv', label: 'CSV' }
  ];

  const handleGenerateReport = () => {
    // Aquí iría la lógica para generar el reporte
    console.log('Generating report:', selectedReport, dateRange);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <PageHeader
          title="reports.title"
          description="reports.description"
          breadcrumbs={[
            { name: 'reports.title', current: true }
          ]}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Report Types */}
          <div className="lg:col-span-2">
            <Card>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                  {t('reports.selectType')}
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {reportTypes.map((report) => {
                    const Icon = report.icon;
                    return (
                      <button
                        key={report.id}
                        onClick={() => setSelectedReport(report.id)}
                        className={`p-4 border-2 rounded-lg text-left transition-all ${
                          selectedReport === report.id
                            ? 'border-itobox-primary bg-itobox-primary/5'
                            : 'border-gray-200 dark:border-gray-700 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-start space-x-3">
                          <Icon className={`h-8 w-8 ${report.color}`} />
                          <div>
                            <h3 className="font-medium text-gray-900 dark:text-white">
                              {report.name}
                            </h3>
                            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                              {report.description}
                            </p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            </Card>
          </div>

          {/* Configuration */}
          <div>
            <Card>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                  {t('reports.configuration')}
                </h2>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      {t('reports.dateRange')}
                    </label>
                    <div className="space-y-2">
                      <Input
                        type="date"
                        value={dateRange.startDate}
                        onChange={(e) => setDateRange(prev => ({
                          ...prev,
                          startDate: e.target.value
                        }))}
                        leftIcon={<Calendar className="h-4 w-4 text-gray-400" />}
                      />
                      <Input
                        type="date"
                        value={dateRange.endDate}
                        onChange={(e) => setDateRange(prev => ({
                          ...prev,
                          endDate: e.target.value
                        }))}
                        leftIcon={<Calendar className="h-4 w-4 text-gray-400" />}
                      />
                    </div>
                  </div>

                  <Select
                    label={t('reports.format')}
                    options={formatOptions}
                    placeholder={t('reports.selectFormat')}
                  />

                  <Button
                    onClick={handleGenerateReport}
                    disabled={!selectedReport || !dateRange.startDate || !dateRange.endDate}
                    className="w-full"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    {t('reports.generate')}
                  </Button>
                </div>

                <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                    {t('reports.quickActions')}
                  </h4>
                  <div className="space-y-2">
                    <Button variant="outline" size="sm" className="w-full">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      {t('reports.lastMonth')}
                    </Button>
                    <Button variant="outline" size="sm" className="w-full">
                      <FileText className="h-4 w-4 mr-2" />
                      {t('reports.currentYear')}
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default ReportsPage;