import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/MainLayout';
import { PageHeader } from '@/components/layout/PageHeader';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { Alert } from '@/components/ui/Alert';
import { 
  User, 
  Bell, 
  Shield, 
  Palette,
  Globe,
  Save
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useTheme } from '@/contexts/ThemeContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { useNotifications } from '@/contexts/NotificationContext';
import { useForm } from '@/hooks/useForm';

const SettingsPage: React.FC = () => {
  const { user } = useAuth();
  const { theme, setTheme } = useTheme();
  const { language, setLanguage, availableLanguages, t } = useLanguage();
  const { showToast } = useNotifications();
  const [activeTab, setActiveTab] = useState('profile');

  const {
    values,
    handleChange,
    handleSubmit,
    isValid
  } = useForm({
    initialValues: {
      firstName: user?.profile?.firstName || '',
      lastName: user?.profile?.lastName || '',
      email: user?.email || '',
      phone: user?.profile?.phone || '',
      company: user?.profile?.company || ''
    },
    onSubmit: async (values) => {
      // Aquí iría la lógica para actualizar el perfil
      showToast(t('settings.profileUpdated'), 'success');
    }
  });

  const tabs = [
    { id: 'profile', name: t('settings.profile'), icon: User },
    { id: 'notifications', name: t('settings.notifications'), icon: Bell },
    { id: 'appearance', name: t('settings.appearance'), icon: Palette },
    { id: 'security', name: t('settings.security'), icon: Shield },
    { id: 'language', name: t('settings.language'), icon: Globe }
  ];

  const themeOptions = [
    { value: 'light', label: t('theme.light') },
    { value: 'dark', label: t('theme.dark') },
    { value: 'auto', label: t('theme.auto') }
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('auth.firstName')}
                value={values.firstName}
                onChange={handleChange('firstName')}
              />
              <Input
                label={t('auth.lastName')}
                value={values.lastName}
                onChange={handleChange('lastName')}
              />
            </div>

            <Input
              label={t('auth.email')}
              type="email"
              value={values.email}
              onChange={handleChange('email')}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Input
                label={t('auth.phone')}
                value={values.phone}
                onChange={handleChange('phone')}
              />
              <Input
                label={t('auth.company')}
                value={values.company}
                onChange={handleChange('company')}
              />
            </div>

            <div className="flex justify-end">
              <Button type="submit" disabled={!isValid}>
                <Save className="h-4 w-4 mr-2" />
                {t('common.save')}
              </Button>
            </div>
          </form>
        );

      case 'notifications':
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <h3 className="text-lg font-medium">{t('settings.emailNotifications')}</h3>
              <div className="space-y-3">
                <label className="flex items-center">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="ml-2">{t('notifications.packageUpdates')}</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="ml-2">{t('notifications.systemAlerts')}</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="rounded" />
                  <span className="ml-2">{t('notifications.marketing')}</span>
                </label>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-medium">{t('settings.pushNotifications')}</h3>
              <div className="space-y-3">
                <label className="flex items-center">
                  <input type="checkbox" className="rounded" defaultChecked />
                  <span className="ml-2">{t('notifications.deliveryUpdates')}</span>
                </label>
                <label className="flex items-center">
                  <input type="checkbox" className="rounded" />
                  <span className="ml-2">{t('notifications.promotions')}</span>
                </label>
              </div>
            </div>

            <div className="flex justify-end">
              <Button>
                <Save className="h-4 w-4 mr-2" />
                {t('common.save')}
              </Button>
            </div>
          </div>
        );

      case 'appearance':
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                {t('settings.theme')}
              </label>
              <Select
                value={theme}
                onChange={(e) => setTheme(e.target.value as any)}
                options={themeOptions}
              />
              <p className="text-sm text-gray-500 mt-2">
                {t('settings.themeDescription')}
              </p>
            </div>

            <div className="flex justify-end">
              <Button onClick={() => showToast(t('settings.appearanceUpdated'), 'success')}>
                <Save className="h-4 w-4 mr-2" />
                {t('common.save')}
              </Button>
            </div>
          </div>
        );

      case 'security':
        return (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-4">{t('settings.changePassword')}</h3>
              <div className="space-y-4">
                <Input
                  label={t('settings.currentPassword')}
                  type="password"
                />
                <Input
                  label={t('settings.newPassword')}
                  type="password"
                />
                <Input
                  label={t('settings.confirmNewPassword')}
                  type="password"
                />
              </div>
            </div>

            <div>
              <h3 className="text-lg font-medium mb-4">{t('settings.twoFactor')}</h3>
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div>
                  <p className="font-medium">{t('settings.twoFactorAuth')}</p>
                  <p className="text-sm text-gray-500">{t('settings.twoFactorDescription')}</p>
                </div>
                <Button variant="outline">
                  {user?.twoFactorEnabled ? t('settings.disable') : t('settings.enable')}
                </Button>
              </div>
            </div>

            <div className="flex justify-end">
              <Button>
                <Save className="h-4 w-4 mr-2" />
                {t('common.save')}
              </Button>
            </div>
          </div>
        );

      case 'language':
        return (
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">
                {t('settings.preferredLanguage')}
              </label>
              <Select
                value={language}
                onChange={(e) => {
                  setLanguage(e.target.value as any);
                  showToast(t('settings.languageUpdated'), 'success');
                }}
                options={availableLanguages.map(lang => ({
                  value: lang.code,
                  label: lang.name
                }))}
              />
              <p className="text-sm text-gray-500 mt-2">
                {t('settings.languageDescription')}
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <PageHeader
          title="settings.title"
          description="settings.description"
          breadcrumbs={[
            { name: 'settings.title', current: true }
          ]}
        />

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <div className="p-4">
                <nav className="space-y-1">
                  {tabs.map((tab) => {
                    const Icon = tab.icon;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-full flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                          activeTab === tab.id
                            ? 'bg-itobox-primary text-white'
                            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                        }`}
                      >
                        <Icon className="h-4 w-4 mr-3" />
                        {tab.name}
                      </button>
                    );
                  })}
                </nav>
              </div>
            </Card>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <Card>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-6">
                  {tabs.find(tab => tab.id === activeTab)?.name}
                </h2>
                {renderTabContent()}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default SettingsPage;