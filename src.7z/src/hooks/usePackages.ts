import { useState, useEffect, useCallback } from 'react';
import { Package, PackageFilters, PaginationInfo } from '@/types';

export function usePackages() {
  const [packages, setPackages] = useState<Package[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pagination, setPagination] = useState<PaginationInfo>({
    page: 1,
    pageSize: 10,
    totalItems: 0,
    totalPages: 0,
  });

  const fetchPackages = useCallback(async (filters?: PackageFilters) => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Simulated API call - replace with actual service
      await new Promise(resolve => setTimeout(resolve, 1000));
      setPackages([]);
      setPagination({
        page: 1,
        pageSize: 10,
        totalItems: 0,
        totalPages: 0,
      });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const createPackage = useCallback(async (packageData: any) => {
    setIsLoading(true);
    try {
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      await fetchPackages();
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [fetchPackages]);

  const updatePackage = useCallback(async (id: number, packageData: any) => {
    setIsLoading(true);
    try {
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      await fetchPackages();
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [fetchPackages]);

  const deletePackage = useCallback(async (id: number) => {
    setIsLoading(true);
    try {
      // Simulated API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      await fetchPackages();
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, [fetchPackages]);

  useEffect(() => {
    fetchPackages();
  }, [fetchPackages]);

  return {
    packages,
    isLoading,
    error,
    pagination,
    fetchPackages,
    createPackage,
    updatePackage,
    deletePackage,
  };
}