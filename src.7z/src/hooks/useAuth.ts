import { useState, useEffect, useCallback } from 'react';
import { User, LoginFormData, RegisterFormData } from '@/types';
import { authService } from '@/services/auth/authService';

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const login = useCallback(async (data: LoginFormData) => {
    try {
      setError(null);
      setIsLoading(true);
      
      const response = await authService.login(data);
      
      if (response.success && response.user) {
        setUser(response.user);
        return response;
      } else {
        throw new Error(response.message || 'Error en login');
      }
    } catch (err: any) {
      const errorMessage = err.message || 'Error de conexión';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const register = useCallback(async (data: RegisterFormData) => {
    try {
      setError(null);
      setIsLoading(true);
      
      const response = await authService.register(data);
      
      if (response.success && response.user) {
        setUser(response.user);
        return response;
      } else {
        throw new Error(response.message || 'Error en registro');
      }
    } catch (err: any) {
      const errorMessage = err.message || 'Error de conexión';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      setError(null);
      await authService.logout();
      setUser(null);
    } catch (err: any) {
      setError(err.message);
    }
  }, []);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const refreshUser = useCallback(async () => {
    try {
      const currentUser = await authService.getCurrentUser();
      setUser(currentUser);
      return currentUser;
    } catch (err: any) {
      setError(err.message);
      setUser(null);
      return null;
    }
  }, []);

  // Inicializar autenticación al montar el componente
  useEffect(() => {
    const initAuth = async () => {
      try {
        setIsLoading(true);
        
        // Verificar si hay token almacenado
        if (authService.isAuthenticated()) {
          const currentUser = await authService.getCurrentUser();
          setUser(currentUser);
        }
      } catch (err: any) {
        console.error('Error inicializando auth:', err);
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();
  }, []);

  return {
    user,
    isLoading,
    error,
    login,
    register,
    logout,
    clearError,
    refreshUser,
    isAuthenticated: authService.isAuthenticated(),
  };
}