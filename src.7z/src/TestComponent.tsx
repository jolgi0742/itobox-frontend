import React from 'react';

export const TestComponent: React.FC = () => {
  alert('🚨 TEST COMPONENT LOADED!');
  
  return (
    <div style={{ 
      padding: '50px', 
      background: 'red', 
      color: 'white', 
      fontSize: '24px',
      textAlign: 'center'
    }}>
      <h1>🔥 COMPONENTE DE PRUEBA</h1>
      <p>Si ves esto, React está funcionando</p>
      <button onClick={() => alert('¡Funciona!')}>
        Clickeame
      </button>
    </div>
  );
};