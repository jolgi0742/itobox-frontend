// src/types/index.ts - Tipos principales del sistema ITOBOX

// ================================
// TIPOS DE USUARIO Y AUTENTICACIÓN
// ================================

export interface User {
  id: number;
  email: string;
  role: UserRole;
  permissions: Permission[];
  profile: UserProfile;
  preferences: UserPreferences;
  lastLogin?: Date;
  emailVerified: boolean;
  twoFactorEnabled: boolean;
  status: UserStatus;
  createdAt: Date;
  updatedAt: Date;
}

export type UserRole = 'admin' | 'agent' | 'client';

export type UserStatus = 'active' | 'inactive' | 'suspended';

export interface Permission {
  id: string;
  name: string;
  resource: string;
  action: string;
}

export interface UserProfile {
  firstName: string;
  lastName: string;
  phone?: string;
  avatar?: string;
  company?: string;
  position?: string;
}

export interface UserPreferences {
  language: string;
  timezone: string;
  notifications: NotificationPreferences;
  theme: 'light' | 'dark' | 'auto';
  dashboard: DashboardPreferences;
}

export interface NotificationPreferences {
  email: boolean;
  push: boolean;
  sms: boolean;
  packageUpdates: boolean;
  systemAlerts: boolean;
  marketing: boolean;
}

export interface DashboardPreferences {
  defaultView: string;
  widgetsOrder: string[];
  autoRefresh: boolean;
  refreshInterval: number;
}

// ================================
// TIPOS DE CLIENTE
// ================================

export interface Client {
  id: number;
  userId?: number;
  customerCode: string;
  companyName?: string;
  contactPerson: string;
  phone: string;
  address: Address;
  billingInfo: BillingInfo;
  miamiAddress: MiamiAddress;
  preferences: ClientPreferences;
  creditLimit: number;
  currentBalance: number;
  status: ClientStatus;
  createdAt: Date;
  updatedAt: Date;
}

export type ClientStatus = 'active' | 'inactive' | 'suspended';

export interface Address {
  street: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export interface BillingInfo {
  taxId?: string;
  paymentMethod: PaymentMethod;
  billingAddress?: Address;
  creditTerms: number;
}

export interface PaymentMethod {
  type: 'credit_card' | 'bank_transfer' | 'paypal' | 'stripe';
  details: Record<string, any>;
  isDefault: boolean;
}

export interface MiamiAddress {
  line1: string;
  line2?: string;
  city: string;
  state: string;
  zipCode: string;
  suite?: string;
}

export interface ClientPreferences {
  shippingMethod: ShippingMethod;
  consolidation: boolean;
  insuranceOptIn: boolean;
  customsDeclaration: CustomsDeclaration;
}

// ================================
// TIPOS DE PAQUETE
// ================================

export interface Package {
  id: number;
  packageCode: string;
  clientId: number;
  client?: Client;
  prealertId?: number;
  prealert?: Prealert;
  trackingNumber: string;
  courier: CourierType;
  originInfo: OriginInfo;
  destinationInfo: DestinationInfo;
  packageDetails: PackageDetails;
  customsInfo: CustomsInfo;
  shippingCost: number;
  insuranceValue: number;
  status: PackageStatus;
  priority: PackagePriority;
  specialInstructions?: string;
  photos: PackagePhoto[];
  receivedAt?: Date;
  deliveredAt?: Date;
  estimatedDelivery?: Date;
  trackingEvents: TrackingEvent[];
  createdAt: Date;
  updatedAt: Date;
}

export type CourierType = 'UPS' | 'FedEx' | 'DHL' | 'USPS' | 'Other';

export type PackageStatus = 
  | 'pending' 
  | 'received' 
  | 'processing' 
  | 'in_transit' 
  | 'delivered' 
  | 'exception' 
  | 'returned';

export type PackagePriority = 'standard' | 'express' | 'urgent';

export type ShippingMethod = 'air' | 'sea' | 'ground' | 'express';

export interface OriginInfo {
  senderName: string;
  senderCompany?: string;
  address: Address;
  phone?: string;
  email?: string;
}

export interface DestinationInfo {
  recipientName: string;
  recipientCompany?: string;
  address: Address;
  phone: string;
  email?: string;
  deliveryInstructions?: string;
}

export interface PackageDetails {
  weight: number;
  weightUnit: 'kg' | 'lb';
  dimensions: {
    length: number;
    width: number;
    height: number;
    unit: 'cm' | 'in';
  };
  description: string;
  category: PackageCategory;
  fragile: boolean;
  value: number;
  currency: string;
}

export type PackageCategory = 
  | 'electronics' 
  | 'clothing' 
  | 'books' 
  | 'toys' 
  | 'cosmetics' 
  | 'documents' 
  | 'other';

export interface CustomsInfo {
  description: string;
  value: number;
  currency: string;
  hsCode?: string;
  countryOfOrigin: string;
  customsDeclaration: CustomsDeclaration;
}

export type CustomsDeclaration = 'gift' | 'commercial' | 'personal' | 'sample';

export interface PackagePhoto {
  id: string;
  url: string;
  type: 'received' | 'packaging' | 'damage' | 'other';
  description?: string;
  uploadedAt: Date;
}

// ================================
// TIPOS DE TRACKING
// ================================

export interface TrackingEvent {
  id: number;
  packageId: number;
  eventType: string;
  status: string;
  description: string;
  location?: TrackingLocation;
  eventDateTime: Date;
  source: TrackingSource;
  sourceDetails: Record<string, any>;
  metadata: Record<string, any>;
  createdAt: Date;
}

export type TrackingSource = 'api' | 'webhook' | 'manual' | 'system';

export interface TrackingLocation {
  city: string;
  state?: string;
  country: string;
  coordinates?: {
    lat: number;
    lng: number;
  };
  facilityName?: string;
}

export interface TrackingUpdate {
  trackingNumber: string;
  courier: CourierType;
  status: PackageStatus;
  events: TrackingEvent[];
  estimatedDelivery?: Date;
  lastUpdated: Date;
}

// ================================
// TIPOS DE PREALERTA
// ================================

export interface Prealert {
  id: number;
  clientId: number;
  client?: Client;
  trackingNumber: string;
  courier: CourierType;
  description: string;
  estimatedValue: number;
  currency: string;
  specialInstructions?: string;
  status: PrealertStatus;
  createdAt: Date;
  updatedAt: Date;
}

export type PrealertStatus = 'pending' | 'received' | 'processed' | 'cancelled';

// ================================
// TIPOS DE NOTIFICACIÓN
// ================================

export interface Notification {
  id: number;
  userId: number;
  type: NotificationType;
  title: string;
  message: string;
  data: Record<string, any>;
  channels: NotificationChannel[];
  priority: NotificationPriority;
  isRead: boolean;
  readAt?: Date;
  expiresAt?: Date;
  createdAt: Date;
}

export type NotificationType = 
  | 'package_received'
  | 'package_in_transit'
  | 'package_delivered'
  | 'package_exception'
  | 'payment_due'
  | 'system_maintenance'
  | 'security_alert';

export type NotificationChannel = 'email' | 'push' | 'sms' | 'in_app';

export type NotificationPriority = 'low' | 'medium' | 'high' | 'urgent';

// ================================
// TIPOS DE DASHBOARD Y MÉTRICAS
// ================================

export interface DashboardMetrics {
  packages: PackageMetrics;
  financial: FinancialMetrics;
  operational: OperationalMetrics;
  clients: ClientMetrics;
  performance: PerformanceMetrics;
}

export interface PackageMetrics {
  totalPackages: number;
  pendingPackages: number;
  inTransitPackages: number;
  deliveredPackages: number;
  exceptionPackages: number;
  packagesThisMonth: number;
  monthlyGrowth: number;
}

export interface FinancialMetrics {
  totalRevenue: number;
  monthlyRevenue: number;
  averageShippingCost: number;
  revenueGrowth: number;
  outstandingPayments: number;
}

export interface OperationalMetrics {
  averageProcessingTime: number;
  deliverySuccessRate: number;
  customerSatisfaction: number;
  agentProductivity: number;
}

export interface ClientMetrics {
  totalClients: number;
  activeClients: number;
  newClients: number;
  clientRetentionRate: number;
}

export interface PerformanceMetrics {
  systemUptime: number;
  averageResponseTime: number;
  errorRate: number;
  apiCallsPerMinute: number;
}

export interface ChartData {
  name: string;
  value: number;
  color?: string;
  [key: string]: any;
}

// ================================
// TIPOS DE FILTROS Y BÚSQUEDA
// ================================

export interface PackageFilters {
  search?: string;
  status?: PackageStatus[];
  courier?: CourierType[];
  clientId?: number[];
  agentId?: number[];
  dateRange?: DateRange;
  priority?: PackagePriority[];
  category?: PackageCategory[];
}

export interface DateRange {
  startDate: Date;
  endDate: Date;
}

export interface SortOption {
  field: string;
  direction: 'asc' | 'desc';
}

export interface PaginationInfo {
  page: number;
  pageSize: number;
  totalItems: number;
  totalPages: number;
}

export interface ApiResponse<T> {
  data: T;
  pagination?: PaginationInfo;
  message?: string;
  success: boolean;
}

export interface ApiError {
  message: string;
  code: string;
  details?: Record<string, any>;
}

// ================================
// TIPOS DE FORMULARIOS
// ================================

export interface LoginFormData {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export interface RegisterFormData {
  email: string;
  password: string;
  confirmPassword: string;
  firstName: string;
  lastName: string;
  company?: string;
  phone: string;
  terms: boolean;
}

export interface PackageFormData {
  trackingNumber: string;
  courier: CourierType;
  description: string;
  weight: number;
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  value: number;
  recipientName: string;
  recipientAddress: Address;
  specialInstructions?: string;
}

export interface PrealertFormData {
  trackingNumber: string;
  courier: CourierType;
  description: string;
  estimatedValue: number;
  specialInstructions?: string;
}

// ================================
// TIPOS DE ESTADO DE APLICACIÓN
// ================================

export interface AppState {
  auth: AuthState;
  packages: PackagesState;
  clients: ClientsState;
  notifications: NotificationsState;
  ui: UIState;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface PackagesState {
  items: Package[];
  selectedPackage: Package | null;
  filters: PackageFilters;
  sort: SortOption;
  pagination: PaginationInfo;
  isLoading: boolean;
  error: string | null;
}

export interface ClientsState {
  items: Client[];
  selectedClient: Client | null;
  isLoading: boolean;
  error: string | null;
}

export interface NotificationsState {
  items: Notification[];
  unreadCount: number;
  isLoading: boolean;
  error: string | null;
}

export interface UIState {
  sidebarOpen: boolean;
  mobileMenuOpen: boolean;
  theme: 'light' | 'dark';
  language: string;
  isLoading: boolean;
}

// ================================
// TIPOS DE CONFIGURACIÓN
// ================================

export interface AppConfig {
  api: {
    baseUrl: string;
    timeout: number;
    retries: number;
  };
  features: {
    enableAnalytics: boolean;
    enablePWA: boolean;
    enableRealTimeTracking: boolean;
  };
  limits: {
    maxFileSize: number;
    maxPhotosPerPackage: number;
    maxPackagesPerPage: number;
  };
}

// ================================
// TIPOS DE EVENTOS
// ================================

export interface AppEvent {
  type: string;
  payload: any;
  timestamp: Date;
  userId?: number;
}

export interface WebSocketMessage {
  type: string;
  data: any;
  timestamp: Date;
}

// ================================
// TIPOS UTILITARIOS
// ================================

export type Optional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;

export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type ApiMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

export interface RequestConfig {
  method: ApiMethod;
  url: string;
  data?: any;
  params?: Record<string, any>;
  headers?: Record<string, string>;
}

// ================================
// CONSTANTES DE TIPOS
// ================================

export const USER_ROLES: UserRole[] = ['admin', 'agent', 'client'];

export const PACKAGE_STATUSES: PackageStatus[] = [
  'pending',
  'received', 
  'processing',
  'in_transit',
  'delivered',
  'exception',
  'returned'
];

export const COURIER_TYPES: CourierType[] = ['UPS', 'FedEx', 'DHL', 'USPS', 'Other'];

export const PACKAGE_PRIORITIES: PackagePriority[] = ['standard', 'express', 'urgent'];

export const NOTIFICATION_TYPES: NotificationType[] = [
  'package_received',
  'package_in_transit', 
  'package_delivered',
  'package_exception',
  'payment_due',
  'system_maintenance',
  'security_alert'
];

// ================================
// GUARDS DE TIPO
// ================================

export const isUser = (obj: any): obj is User => {
  return obj && typeof obj.id === 'number' && typeof obj.email === 'string';
};

export const isPackage = (obj: any): obj is Package => {
  return obj && typeof obj.id === 'number' && typeof obj.packageCode === 'string';
};

export const isClient = (obj: any): obj is Client => {
  return obj && typeof obj.id === 'number' && typeof obj.customerCode === 'string';
};

export const isApiError = (obj: any): obj is ApiError => {
  return obj && typeof obj.message === 'string' && typeof obj.code === 'string';
};

// ================================
// TIPOS DE EXPORTACIÓN
// ================================

export default {
  User,
  Package,
  Client,
  TrackingEvent,
  Notification,
  DashboardMetrics,
  PackageFilters,
  AppState,
  AppConfig
};