// components/Dashboard.jsx - Dashboard ultra moderno y profesional
import React, { useState, useEffect } from 'react';
import { 
  Package, 
  TrendingUp, 
  Clock, 
  Truck, 
  DollarSign,
  Plus,
  Eye,
  ArrowUpRight,
  Users,
  Star,
  Activity,
  Zap,
  Target,
  BarChart3
} from 'lucide-react';
import PackageService from '../services/PackageService';
import ClientService from '../services/ClientService';

const Dashboard = ({ onNavigateToPackages, onNavigateToClients, onNavigateToTracking }) => {
  const [stats, setStats] = useState({});
  const [clientStats, setClientStats] = useState({});
  const [recentPackages, setRecentPackages] = useState([]);
  const [topClients, setTopClients] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = () => {
    setLoading(true);
    try {
      const packageStats = PackageService.getPackageStats();
      setStats(packageStats);

      const clientStatistics = ClientService.getClientStats();
      setClientStats(clientStatistics);

      const allPackages = PackageService.getAllPackages();
      const recent = allPackages
        .sort((a, b) => new Date(b.dates.created) - new Date(a.dates.created))
        .slice(0, 5);
      setRecentPackages(recent);

      setTopClients(clientStatistics.topSpenders || []);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh',
        background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }}>
        <div style={{ textAlign: 'center', color: 'white' }}>
          <div style={{
            width: '80px',
            height: '80px',
            border: '6px solid rgba(255,255,255,0.2)',
            borderTop: '6px solid white',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 24px'
          }}></div>
          <p style={{ fontSize: '20px', fontWeight: '600' }}>Cargando dashboard...</p>
        </div>
      </div>
    );
  }

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif'
    },
    wrapper: {
      maxWidth: '1400px',
      margin: '0 auto',
      padding: '40px 20px'
    },
    heroSection: {
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      borderRadius: '32px',
      padding: '60px 40px',
      marginBottom: '40px',
      color: 'white',
      position: 'relative',
      overflow: 'hidden',
      boxShadow: '0 32px 64px -12px rgba(102, 126, 234, 0.4)'
    },
    heroBackground: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'url("data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23ffffff" fill-opacity="0.05"%3E%3Ccircle cx="7" cy="7" r="7"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")',
      opacity: 0.3
    },
    heroContent: {
      position: 'relative',
      zIndex: 10
    },
    heroTitle: {
      fontSize: '3.5rem',
      fontWeight: '800',
      marginBottom: '12px',
      textShadow: '0 4px 8px rgba(0,0,0,0.15)',
      background: 'linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%)',
      WebkitBackgroundClip: 'text',
      WebkitTextFillColor: 'transparent',
      backgroundClip: 'text'
    },
    heroSubtitle: {
      fontSize: '1.25rem',
      opacity: 0.95,
      marginBottom: '32px',
      lineHeight: '1.6'
    },
    statusBadges: {
      display: 'flex',
      gap: '16px',
      flexWrap: 'wrap'
    },
    statusBadge: {
      display: 'flex',
      alignItems: 'center',
      backgroundColor: 'rgba(255,255,255,0.15)',
      padding: '12px 20px',
      borderRadius: '50px',
      backdropFilter: 'blur(20px)',
      border: '1px solid rgba(255,255,255,0.2)',
      fontWeight: '600',
      fontSize: '0.95rem'
    },
    statsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
      gap: '32px',
      marginBottom: '48px'
    },
    statCard: {
      backgroundColor: 'white',
      borderRadius: '24px',
      padding: '32px',
      boxShadow: '0 20px 40px -8px rgba(0, 0, 0, 0.08)',
      transition: 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)',
      cursor: 'pointer',
      border: '1px solid rgba(0,0,0,0.04)',
      position: 'relative',
      overflow: 'hidden'
    },
    statCardGlow: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: '4px',
      borderRadius: '24px 24px 0 0'
    },
    statHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    },
    statInfo: {
      flex: 1
    },
    statLabel: {
      fontSize: '0.875rem',
      fontWeight: '700',
      color: '#64748b',
      textTransform: 'uppercase',
      letterSpacing: '0.1em',
      marginBottom: '12px'
    },
    statValue: {
      fontSize: '2.75rem',
      fontWeight: '900',
      color: '#1e293b',
      marginBottom: '8px',
      lineHeight: '1'
    },
    statChange: {
      display: 'flex',
      alignItems: 'center',
      fontSize: '0.95rem',
      fontWeight: '600'
    },
    statIcon: {
      padding: '20px',
      borderRadius: '20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 8px 24px rgba(0,0,0,0.12)'
    },
    mainGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))',
      gap: '40px',
      marginBottom: '48px'
    },
    sectionCard: {
      backgroundColor: 'white',
      borderRadius: '24px',
      padding: '32px',
      boxShadow: '0 20px 40px -8px rgba(0, 0, 0, 0.08)',
      border: '1px solid rgba(0,0,0,0.04)',
      position: 'relative',
      overflow: 'hidden'
    },
    sectionHeader: {
      display: 'flex',
      alignItems: 'center',
      marginBottom: '32px'
    },
    sectionIcon: {
      padding: '16px',
      borderRadius: '16px',
      marginRight: '20px',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      boxShadow: '0 8px 24px rgba(102, 126, 234, 0.25)'
    },
    sectionTitle: {
      fontSize: '1.5rem',
      fontWeight: '800',
      color: '#1e293b'
    },
    actionButton: {
      width: '100%',
      padding: '20px 24px',
      borderRadius: '16px',
      border: 'none',
      color: 'white',
      fontWeight: '700',
      fontSize: '1.1rem',
      cursor: 'pointer',
      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '16px',
      boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
      position: 'relative',
      overflow: 'hidden'
    },
    primaryButton: {
      background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)'
    },
    secondaryButton: {
      background: 'linear-gradient(135deg, #8b5cf6 0%, #6d28d9 100%)'
    },
    tertiaryButton: {
      background: 'linear-gradient(135deg, #6b7280 0%, #374151 100%)'
    },
    quaternaryButton: {
      background: 'linear-gradient(135deg, #10b981 0%, #047857 100%)'
    },
    statusGrid: {
      display: 'grid',
      gap: '16px'
    },
    statusItem: {
      padding: '20px',
      borderRadius: '16px',
      marginBottom: '12px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      transition: 'all 0.3s ease',
      border: '2px solid transparent'
    },
    statusDot: {
      width: '14px',
      height: '14px',
      borderRadius: '50%',
      marginRight: '16px',
      boxShadow: '0 2px 8px rgba(0,0,0,0.15)'
    },
    emptyState: {
      textAlign: 'center',
      padding: '60px 20px'
    },
    emptyIcon: {
      width: '100px',
      height: '100px',
      backgroundColor: '#f1f5f9',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      margin: '0 auto 24px',
      boxShadow: 'inset 0 2px 8px rgba(0,0,0,0.06)'
    }
  };

  return (
    <div style={styles.container}>
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-6px); }
          }
          @keyframes glow {
            0%, 100% { box-shadow: 0 20px 40px -8px rgba(0, 0, 0, 0.08); }
            50% { box-shadow: 0 25px 50px -8px rgba(0, 0, 0, 0.15); }
          }
          .stat-card:hover {
            transform: translateY(-8px) scale(1.02);
            box-shadow: 0 32px 64px -8px rgba(0, 0, 0, 0.18);
            animation: glow 2s ease-in-out infinite;
          }
          .action-button:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 16px 32px rgba(0,0,0,0.25);
          }
          .action-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
            transition: left 0.6s;
          }
          .action-button:hover::before {
            left: 100%;
          }
          .status-item:hover {
            transform: translateX(8px);
            border-color: rgba(0,0,0,0.1);
            box-shadow: 0 8px 24px rgba(0,0,0,0.08);
          }
          .section-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #667eea, #764ba2);
            border-radius: 24px 24px 0 0;
          }
          .float-animation {
            animation: float 3s ease-in-out infinite;
          }
        `}
      </style>
      
      <div style={styles.wrapper}>
        {/* Hero Section */}
        <div style={styles.heroSection}>
          <div style={styles.heroBackground}></div>
          <div style={styles.heroContent}>
            <h1 style={styles.heroTitle}>¡Bienvenido a ITOBOX Courier!</h1>
            <p style={styles.heroSubtitle}>
              Gestiona tus envíos de manera eficiente y mantén a tus clientes informados con nuestra plataforma de última generación
            </p>
            <div style={styles.statusBadges}>
              <span style={styles.statusBadge}>
                <Zap size={20} style={{ marginRight: '12px' }} />
                Sistema Activo
              </span>
              <span style={styles.statusBadge}>
                <Target size={20} style={{ marginRight: '12px' }} />
                100% Operativo
              </span>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div style={styles.statsGrid}>
          {/* Total Packages */}
          <div className="stat-card" style={styles.statCard}>
            <div style={{...styles.statCardGlow, background: 'linear-gradient(90deg, #3b82f6, #1e40af)'}}></div>
            <div style={styles.statHeader}>
              <div style={styles.statInfo}>
                <div style={styles.statLabel}>Total Paquetes</div>
                <div style={styles.statValue}>{stats.total || 0}</div>
                <div style={{...styles.statChange, color: '#10b981'}}>
                  <TrendingUp size={18} style={{ marginRight: '6px' }} />
                  +{stats.todayCreated || 0} hoy
                </div>
              </div>
              <div style={{...styles.statIcon, background: 'linear-gradient(135deg, #dbeafe, #bfdbfe)'}} className="float-animation">
                <Package size={28} color="#3b82f6" />
              </div>
            </div>
          </div>

          {/* Total Clients */}
          <div className="stat-card" style={styles.statCard}>
            <div style={{...styles.statCardGlow, background: 'linear-gradient(90deg, #8b5cf6, #6d28d9)'}}></div>
            <div style={styles.statHeader}>
              <div style={styles.statInfo}>
                <div style={styles.statLabel}>Total Clientes</div>
                <div style={styles.statValue}>{clientStats.total || 0}</div>
                <div style={{...styles.statChange, color: '#8b5cf6'}}>
                  <Users size={18} style={{ marginRight: '6px' }} />
                  +{clientStats.newThisMonth || 0} este mes
                </div>
              </div>
              <div style={{...styles.statIcon, background: 'linear-gradient(135deg, #f3e8ff, #e9d5ff)'}} className="float-animation">
                <Users size={28} color="#8b5cf6" />
              </div>
            </div>
          </div>

          {/* Pending Deliveries */}
          <div className="stat-card" style={styles.statCard}>
            <div style={{...styles.statCardGlow, background: 'linear-gradient(90deg, #f59e0b, #d97706)'}}></div>
            <div style={styles.statHeader}>
              <div style={styles.statInfo}>
                <div style={styles.statLabel}>Entregas Pendientes</div>
                <div style={styles.statValue}>{stats.pendingDeliveries || 0}</div>
                <div style={{...styles.statChange, color: '#f59e0b'}}>
                  <Clock size={18} style={{ marginRight: '6px' }} />
                  En proceso
                </div>
              </div>
              <div style={{...styles.statIcon, background: 'linear-gradient(135deg, #fef3c7, #fde68a)'}} className="float-animation">
                <Truck size={28} color="#f59e0b" />
              </div>
            </div>
          </div>

          {/* Revenue */}
          <div className="stat-card" style={styles.statCard}>
            <div style={{...styles.statCardGlow, background: 'linear-gradient(90deg, #10b981, #047857)'}}></div>
            <div style={styles.statHeader}>
              <div style={styles.statInfo}>
                <div style={styles.statLabel}>Ingresos Totales</div>
                <div style={styles.statValue}>{formatCurrency(clientStats.totalRevenue || 0)}</div>
                <div style={{...styles.statChange, color: '#10b981'}}>
                  <DollarSign size={18} style={{ marginRight: '6px' }} />
                  Acumulado
                </div>
              </div>
              <div style={{...styles.statIcon, background: 'linear-gradient(135deg, #d1fae5, #a7f3d0)'}} className="float-animation">
                <DollarSign size={28} color="#10b981" />
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div style={styles.mainGrid}>
          {/* Quick Actions */}
          <div style={styles.sectionCard} className="section-card">
            <div style={styles.sectionHeader}>
              <div style={styles.sectionIcon}>
                <Zap size={28} />
              </div>
              <h3 style={styles.sectionTitle}>Acciones Rápidas</h3>
            </div>
            
            <div>
              <button
                onClick={onNavigateToPackages}
                className="action-button"
                style={{...styles.actionButton, ...styles.primaryButton}}
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <Plus size={22} style={{ marginRight: '16px' }} />
                  Crear Nuevo Paquete
                </div>
                <ArrowUpRight size={22} />
              </button>
              
              <button
                onClick={onNavigateToClients}
                className="action-button"
                style={{...styles.actionButton, ...styles.secondaryButton}}
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <Users size={22} style={{ marginRight: '16px' }} />
                  Gestionar Clientes
                </div>
                <ArrowUpRight size={22} />
              </button>
              
              <button
                onClick={onNavigateToTracking}
                className="action-button"
                style={{...styles.actionButton, ...styles.tertiaryButton}}
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <Eye size={22} style={{ marginRight: '16px' }} />
                  Tracking Público
                </div>
                <ArrowUpRight size={22} />
              </button>
              
              <button
                onClick={onNavigateToPackages}
                className="action-button"
                style={{...styles.actionButton, ...styles.quaternaryButton, marginBottom: 0}}
              >
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <BarChart3 size={22} style={{ marginRight: '16px' }} />
                  Ver Todos los Paquetes
                </div>
                <ArrowUpRight size={22} />
              </button>
            </div>
          </div>

          {/* Package Status */}
          <div style={styles.sectionCard} className="section-card">
            <div style={styles.sectionHeader}>
              <div style={{...styles.sectionIcon, background: 'linear-gradient(135deg, #f59e0b 0%, #ef4444 100%)'}}>
                <Package size={28} />
              </div>
              <h3 style={styles.sectionTitle}>Estado de Paquetes</h3>
            </div>
            
            <div style={styles.statusGrid}>
              {[
                { status: 'created', label: 'Creados', color: '#3b82f6', bgColor: '#f0f9ff' },
                { status: 'collected', label: 'Recolectados', color: '#f59e0b', bgColor: '#fffbeb' },
                { status: 'in_transit', label: 'En Tránsito', color: '#f97316', bgColor: '#fff7ed' },
                { status: 'out_for_delivery', label: 'En Reparto', color: '#8b5cf6', bgColor: '#faf5ff' },
                { status: 'delivered', label: 'Entregados', color: '#10b981', bgColor: '#ecfdf5' },
                { status: 'returned', label: 'Devueltos', color: '#ef4444', bgColor: '#fef2f2' }
              ].map(({ status, label, color, bgColor }) => {
                const count = stats.byStatus?.[status] || 0;
                const percentage = stats.total > 0 ? (count / stats.total) * 100 : 0;
                
                return (
                  <div key={status} className="status-item" style={{...styles.statusItem, backgroundColor: bgColor}}>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <div style={{...styles.statusDot, backgroundColor: color}}></div>
                      <span style={{ fontWeight: '700', color: '#1e293b', fontSize: '1.1rem' }}>{label}</span>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                      <span style={{ fontSize: '2rem', fontWeight: '900', color: '#1e293b' }}>{count}</span>
                      <span style={{ 
                        fontSize: '0.875rem', 
                        color: '#64748b',
                        backgroundColor: 'white',
                        padding: '6px 12px',
                        borderRadius: '20px',
                        fontWeight: '600',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                      }}>
                        {percentage.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Activity */}
          <div style={styles.sectionCard} className="section-card">
            <div style={styles.sectionHeader}>
              <div style={{...styles.sectionIcon, background: 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)'}}>
                <Activity size={28} />
              </div>
              <h3 style={styles.sectionTitle}>Actividad Reciente</h3>
            </div>
            
            {recentPackages.length === 0 ? (
              <div style={styles.emptyState}>
                <div style={styles.emptyIcon}>
                  <Package size={40} color="#64748b" />
                </div>
                <h4 style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1e293b', marginBottom: '12px' }}>
                  No hay paquetes aún
                </h4>
                <p style={{ color: '#64748b', marginBottom: '32px', fontSize: '1.1rem' }}>
                  Comienza creando tu primer paquete para ver la actividad aquí
                </p>
                <button
                  onClick={onNavigateToPackages}
                  style={{
                    ...styles.actionButton,
                    ...styles.primaryButton,
                    width: 'auto',
                    padding: '16px 32px',
                    display: 'inline-flex',
                    fontSize: '1rem'
                  }}
                >
                  <Plus size={20} style={{ marginRight: '12px' }} />
                  Crear Primer Paquete
                </button>
              </div>
            ) : (
              <div>
                {recentPackages.map((pkg) => (
                  <div key={pkg.id} style={styles.statusItem}>
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      <div style={{
                        backgroundColor: 'white',
                        padding: '12px',
                        borderRadius: '12px',
                        marginRight: '16px',
                        boxShadow: '0 4px 12px rgba(0,0,0,0.1)'
                      }}>
                        <Package size={20} color="#3b82f6" />
                      </div>
                      <div>
                        <div style={{ fontWeight: '700', color: '#1e293b', fontSize: '1.1rem' }}>{pkg.trackingCode}</div>
                        <div style={{ fontSize: '0.95rem', color: '#64748b' }}>{formatDate(pkg.dates.created)}</div>
                      </div>
                    </div>
                    <span style={{
                      fontSize: '0.875rem',
                      fontWeight: '700',
                      padding: '8px 16px',
                      borderRadius: '20px',
                      backgroundColor: '#f0f9ff',
                      color: '#1e40af',
                      boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
                    }}>
                      {PackageService.getStatusLabel(pkg.status)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;