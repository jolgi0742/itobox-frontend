// components/Analytics.jsx - Componente temporal
import React from 'react';
import { BarChart3, TrendingUp, Calendar, DollarSign } from 'lucide-react';

const Analytics = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl">
            Analíticas Avanzadas
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            Análisis detallado y reportes (Próximamente)
          </p>
        </div>

        {/* Coming Soon Content */}
        <div className="bg-white shadow rounded-lg p-12">
          <div className="text-center">
            <BarChart3 className="mx-auto h-24 w-24 text-blue-600" />
            <h2 className="mt-6 text-3xl font-bold text-gray-900">
              Dashboard Avanzado
            </h2>
            <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
              Esta sección incluirá gráficos interactivos, reportes exportables y análisis predictivo.
            </p>
            
            {/* Features Preview */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-blue-100 rounded-full p-4 inline-flex">
                  <TrendingUp className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">
                  Análisis de Tendencias
                </h3>
                <p className="mt-2 text-gray-600">
                  Gráficos interactivos de crecimiento y patrones de envío
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-green-100 rounded-full p-4 inline-flex">
                  <DollarSign className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">
                  Reportes Financieros
                </h3>
                <p className="mt-2 text-gray-600">
                  Ingresos, márgenes y proyecciones exportables
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-purple-100 rounded-full p-4 inline-flex">
                  <Calendar className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="mt-4 text-lg font-medium text-gray-900">
                  Análisis Temporal
                </h3>
                <p className="mt-2 text-gray-600">
                  Patrones por hora, día, semana y mes
                </p>
              </div>
            </div>

            <div className="mt-12">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <p className="text-blue-800 font-medium">
                  💡 Esta será nuestra próxima implementación después de completar la gestión de clientes
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;