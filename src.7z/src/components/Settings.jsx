// components/Settings.jsx - Configuración del Sistema
import React, { useState, useEffect } from 'react';
import { 
  Save, 
  Settings as SettingsIcon, 
  Package, 
  DollarSign,
  Clock,
  MapPin,
  User,
  Mail,
  Phone,
  Download,
  Upload,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import PackageService from '../services/PackageService';

const Settings = () => {
  const [settings, setSettings] = useState({
    company: {
      name: 'ITOBOX Courier',
      address: 'San José, Costa Rica',
      phone: '(506) 8888-8888',
      email: 'info@itoboxcourier.com',
      website: 'www.itoboxcourier.com'
    },
    pricing: {
      baseRate: 2.5,
      expressMultiplier: 2.0,
      urgentMultiplier: 1.5,
      normalMultiplier: 1.0,
      currency: 'USD'
    },
    delivery: {
      normalDays: 3,
      urgentDays: 2,
      expressDays: 1,
      businessHours: '8:00 AM - 6:00 PM'
    },
    notifications: {
      emailEnabled: true,
      smsEnabled: false,
      trackingUpdates: true,
      dailyReports: false
    }
  });

  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('company');
  const [stats, setStats] = useState({});

  useEffect(() => {
    loadSettings();
    loadStats();
  }, []);

  const loadSettings = () => {
    try {
      const savedSettings = localStorage.getItem('itobox_settings');
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const loadStats = () => {
    const packageStats = PackageService.getPackageStats();
    setStats(packageStats);
  };

  const handleSettingChange = (category, field, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [field]: value
      }
    }));
  };

  const saveSettings = async () => {
    setLoading(true);
    try {
      localStorage.setItem('itobox_settings', JSON.stringify(settings));
      alert('Configuración guardada exitosamente');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert('Error al guardar la configuración');
    } finally {
      setLoading(false);
    }
  };

  const exportData = () => {
    try {
      const packages = PackageService.getAllPackages();
      const data = {
        packages,
        settings,
        exportDate: new Date().toISOString(),
        version: '1.0'
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `itobox-backup-${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting data:', error);
      alert('Error al exportar los datos');
    }
  };

  const importData = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target.result);
        
        if (data.packages) {
          localStorage.setItem('itobox_packages', JSON.stringify(data.packages));
        }
        if (data.settings) {
          setSettings(data.settings);
          localStorage.setItem('itobox_settings', JSON.stringify(data.settings));
        }
        
        alert('Datos importados exitosamente');
        loadStats();
      } catch (error) {
        console.error('Error importing data:', error);
        alert('Error al importar los datos. Verifica que el archivo sea válido.');
      }
    };
    reader.readAsText(file);
  };

  const clearAllData = () => {
    if (window.confirm('⚠️ ADVERTENCIA: Esto eliminará TODOS los paquetes y configuraciones. ¿Estás seguro?')) {
      if (window.confirm('Esta acción no se puede deshacer. ¿Continuar?')) {
        localStorage.removeItem('itobox_packages');
        localStorage.removeItem('itobox_package_counter');
        localStorage.removeItem('itobox_settings');
        alert('Todos los datos han sido eliminados');
        window.location.reload();
      }
    }
  };

  const tabs = [
    { id: 'company', label: 'Empresa', icon: User },
    { id: 'pricing', label: 'Precios', icon: DollarSign },
    { id: 'delivery', label: 'Entregas', icon: Clock },
    { id: 'notifications', label: 'Notificaciones', icon: Mail },
    { id: 'data', label: 'Datos', icon: Package }
  ];

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <SettingsIcon className="h-8 w-8 text-blue-600 mr-3" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Configuración del Sistema</h1>
              <p className="text-gray-600">Personaliza ITOBOX Courier según tus necesidades</p>
            </div>
          </div>
          <button
            onClick={saveSettings}
            disabled={loading}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Guardar Cambios
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar Navigation */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4">
              <nav className="space-y-1">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg flex items-center ${
                        activeTab === tab.id
                          ? 'bg-blue-100 text-blue-700'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      <Icon className="h-4 w-4 mr-3" />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            {/* Company Settings */}
            {activeTab === 'company' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Información de la Empresa</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nombre de la Empresa
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.company.name}
                      onChange={(e) => handleSettingChange('company', 'name', e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Teléfono
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <input
                        type="tel"
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        value={settings.company.phone}
                        onChange={(e) => handleSettingChange('company', 'phone', e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Email
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <input
                        type="email"
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        value={settings.company.email}
                        onChange={(e) => handleSettingChange('company', 'email', e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Sitio Web
                    </label>
                    <input
                      type="url"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.company.website}
                      onChange={(e) => handleSettingChange('company', 'website', e.target.value)}
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Dirección
                    </label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <textarea
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        rows="2"
                        value={settings.company.address}
                        onChange={(e) => handleSettingChange('company', 'address', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Pricing Settings */}
            {activeTab === 'pricing' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Configuración de Precios</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Tarifa Base (por kg)
                    </label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                        value={settings.pricing.baseRate}
                        onChange={(e) => handleSettingChange('pricing', 'baseRate', parseFloat(e.target.value))}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Moneda
                    </label>
                    <select
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.pricing.currency}
                      onChange={(e) => handleSettingChange('pricing', 'currency', e.target.value)}
                    >
                      <option value="USD">USD - Dólar</option>
                      <option value="CRC">CRC - Colón</option>
                      <option value="EUR">EUR - Euro</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Multiplicador Express
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.pricing.expressMultiplier}
                      onChange={(e) => handleSettingChange('pricing', 'expressMultiplier', parseFloat(e.target.value))}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Multiplicador Urgente
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.pricing.urgentMultiplier}
                      onChange={(e) => handleSettingChange('pricing', 'urgentMultiplier', parseFloat(e.target.value))}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Delivery Settings */}
            {activeTab === 'delivery' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Configuración de Entregas</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Días para Entrega Normal
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="10"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.delivery.normalDays}
                      onChange={(e) => handleSettingChange('delivery', 'normalDays', parseInt(e.target.value))}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Días para Entrega Urgente
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="5"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.delivery.urgentDays}
                      onChange={(e) => handleSettingChange('delivery', 'urgentDays', parseInt(e.target.value))}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Días para Entrega Express
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="3"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.delivery.expressDays}
                      onChange={(e) => handleSettingChange('delivery', 'expressDays', parseInt(e.target.value))}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Horario de Atención
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      value={settings.delivery.businessHours}
                      onChange={(e) => handleSettingChange('delivery', 'businessHours', e.target.value)}
                      placeholder="8:00 AM - 6:00 PM"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Notifications Settings */}
            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Configuración de Notificaciones</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Notificaciones por Email</p>
                      <p className="text-sm text-gray-500">Enviar updates por correo electrónico</p>
                    </div>
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={settings.notifications.emailEnabled}
                      onChange={(e) => handleSettingChange('notifications', 'emailEnabled', e.target.checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Notificaciones por SMS</p>
                      <p className="text-sm text-gray-500">Enviar updates por mensaje de texto</p>
                    </div>
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={settings.notifications.smsEnabled}
                      onChange={(e) => handleSettingChange('notifications', 'smsEnabled', e.target.checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Updates de Tracking</p>
                      <p className="text-sm text-gray-500">Notificar cambios de estado automáticamente</p>
                    </div>
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={settings.notifications.trackingUpdates}
                      onChange={(e) => handleSettingChange('notifications', 'trackingUpdates', e.target.checked)}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">Reportes Diarios</p>
                      <p className="text-sm text-gray-500">Recibir resumen diario de actividad</p>
                    </div>
                    <input
                      type="checkbox"
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={settings.notifications.dailyReports}
                      onChange={(e) => handleSettingChange('notifications', 'dailyReports', e.target.checked)}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Data Management */}
            {activeTab === 'data' && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-gray-900">Gestión de Datos</h3>
                
                {/* Stats */}
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-medium text-gray-900 mb-3">Estadísticas del Sistema</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Total de Paquetes</p>
                      <p className="text-lg font-semibold text-gray-900">{stats.total || 0}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Paquetes Entregados</p>
                      <p className="text-lg font-semibold text-gray-900">{stats.byStatus?.delivered || 0}</p>
                    </div>
                  </div>
                </div>

                {/* Export/Import */}
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Respaldo de Datos</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Exporta todos tus datos para crear un respaldo o migrar a otro sistema.
                    </p>
                    <button
                      onClick={exportData}
                      className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Exportar Datos
                    </button>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Restaurar Datos</h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Importa datos desde un archivo de respaldo.
                    </p>
                    <label className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 flex items-center cursor-pointer inline-flex">
                      <Upload className="h-4 w-4 mr-2" />
                      Importar Datos
                      <input
                        type="file"
                        accept=".json"
                        onChange={importData}
                        className="hidden"
                      />
                    </label>
                  </div>

                  <div className="border-t pt-4">
                    <h4 className="font-medium text-red-600 mb-2 flex items-center">
                      <AlertTriangle className="h-4 w-4 mr-2" />
                      Zona de Peligro
                    </h4>
                    <p className="text-sm text-gray-600 mb-3">
                      Elimina todos los datos del sistema. Esta acción no se puede deshacer.
                    </p>
                    <button
                      onClick={clearAllData}
                      className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 flex items-center"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Eliminar Todos los Datos
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;