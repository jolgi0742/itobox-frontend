import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  Home,
  Package,
  Users,
  MapPin,
  BarChart3,
  Settings,
  HelpCircle,
  FileText,
  Truck,
  Clock,
  X
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { useLanguage } from '@/contexts/LanguageContext';
import { cn } from '@/utils/cn';

interface NavigationItem {
  name: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
  roles: string[];
  badge?: string;
}

const navigation: NavigationItem[] = [
  {
    name: 'dashboard.title',
    href: '/dashboard',
    icon: Home,
    roles: ['admin', 'agent', 'client']
  },
  {
    name: 'packages.title',
    href: '/packages',
    icon: Package,
    roles: ['admin', 'agent', 'client']
  },
  {
    name: 'prealerts.title',
    href: '/prealerts',
    icon: Clock,
    roles: ['admin', 'agent', 'client']
  },
  {
    name: 'tracking.title',
    href: '/tracking',
    icon: MapPin,
    roles: ['admin', 'agent']
  },
  {
    name: 'clients.title',
    href: '/clients',
    icon: Users,
    roles: ['admin', 'agent']
  },
  {
    name: 'shipments.title',
    href: '/shipments',
    icon: Truck,
    roles: ['admin', 'agent']
  },
  {
    name: 'reports.title',
    href: '/reports',
    icon: BarChart3,
    roles: ['admin']
  },
  {
    name: 'settings.title',
    href: '/settings',
    icon: Settings,
    roles: ['admin', 'agent', 'client']
  },
  {
    name: 'help.title',
    href: '/help',
    icon: HelpCircle,
    roles: ['admin', 'agent', 'client']
  }
];

export const Sidebar: React.FC = () => {
  const { user } = useAuth();
  const { state, setSidebarOpen, setMobileMenuOpen } = useApp();
  const { t } = useLanguage();
  const location = useLocation();

  const filteredNavigation = navigation.filter(item => 
    item.roles.includes(user?.role || '')
  );

  const handleLinkClick = () => {
    // Close mobile menu when clicking on a link
    setMobileMenuOpen(false);
  };

  const sidebarContent = (
    <>
      {/* Logo */}
      <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <img
            src="/logo.png"
            alt="ITOBOX"
            className="h-8 w-auto"
          />
          <span className="ml-2 text-xl font-bold text-itobox-primary">
            ITOBOX
          </span>
        </div>
        
        {/* Close button for mobile */}
        <button
          onClick={() => setMobileMenuOpen(false)}
          className="md:hidden p-1 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
        {filteredNavigation.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.href;
          
          return (
            <Link
              key={item.name}
              to={item.href}
              onClick={handleLinkClick}
              className={cn(
                'flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200',
                isActive
                  ? 'bg-itobox-primary text-white'
                  : 'text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
              )}
            >
              <Icon className="h-5 w-5 mr-3" />
              {t(item.name)}
              {item.badge && (
                <span className="ml-auto bg-red-500 text-white text-xs rounded-full px-2 py-1">
                  {item.badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* User Info */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-center">
          <div className="w-10 h-10 bg-itobox-primary rounded-full flex items-center justify-center text-white font-medium">
            {user?.profile?.firstName?.[0] || user?.email?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="ml-3 overflow-hidden">
            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 truncate">
              {user?.profile?.firstName} {user?.profile?.lastName}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
              {user?.email}
            </p>
          </div>
        </div>
      </div>
    </>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <div
        className={cn(
          'hidden md:flex md:flex-col md:fixed md:inset-y-0 transition-all duration-300 z-30',
          state.ui.sidebarOpen ? 'md:w-64' : 'md:w-0'
        )}
      >
        <div className="flex flex-col flex-1 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 shadow-sm overflow-hidden">
          {state.ui.sidebarOpen && sidebarContent}
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {state.ui.mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0 bg-gray-600 bg-opacity-75"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative flex flex-col w-64 h-full bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 shadow-xl">
            {sidebarContent}
          </div>
        </div>
      )}
    </>
  );
};