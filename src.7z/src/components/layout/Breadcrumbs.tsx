import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

interface BreadcrumbItem {
  name: string;
  href?: string;
  current?: boolean;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
  className?: string;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ items, className }) => {
  const { t } = useLanguage();

  return (
    <nav className={`flex ${className}`} aria-label="Breadcrumb">
      <ol className="flex items-center space-x-2">
        {/* Home link */}
        <li>
          <Link
            to="/dashboard"
            className="text-gray-400 hover:text-gray-500 transition-colors"
          >
            <Home className="h-4 w-4" />
            <span className="sr-only">{t('dashboard.title')}</span>
          </Link>
        </li>

        {items.map((item, index) => (
          <li key={item.name} className="flex items-center">
            <ChevronRight className="h-4 w-4 text-gray-400 mx-2" />
            {item.current ? (
              <span className="text-sm font-medium text-gray-500">
                {t(item.name)}
              </span>
            ) : (
              <Link
                to={item.href || '#'}
                className="text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
              >
                {t(item.name)}
              </Link>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
};
