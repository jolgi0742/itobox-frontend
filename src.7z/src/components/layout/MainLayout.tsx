import React from 'react';
import { Header } from './Header';
import { Sidebar } from './Sidebar';
import { ToastContainer } from './ToastContainer';
import { useApp } from '@/contexts/AppContext';
import { cn } from '@/utils/cn';

interface MainLayoutProps {
  children: React.ReactNode;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const { state } = useApp();

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Sidebar />
      
      <div
        className={cn(
          'flex flex-col transition-all duration-300',
          state.ui.sidebarOpen ? 'md:ml-64' : 'md:ml-0'
        )}
      >
        <Header />
        
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>

      <ToastContainer />
    </div>
  );
};