// components/tracking/PublicTracking.jsx
import React, { useState } from 'react';
import { 
  Search, 
  Package as PackageIcon, 
  MapPin, 
  Clock, 
  Phone, 
  Calendar,
  CheckCircle,
  Truck,
  Home,
  RotateCcw,
  Navigation,
  AlertCircle
} from 'lucide-react';
import PackageService from '../../services/PackageService';

const PublicTracking = () => {
  const [trackingCode, setTrackingCode] = useState('');
  const [package_, setPackage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (e) => {
    e.preventDefault();
    
    if (!trackingCode.trim()) {
      setError('Por favor ingresa un código de tracking');
      return;
    }

    setLoading(true);
    setError('');
    setPackage(null);

    try {
      const result = PackageService.getPackageByTrackingCode(trackingCode.trim());
      
      if (result) {
        setPackage(result);
      } else {
        setError('Código de tracking no encontrado. Verifica que esté correcto.');
      }
    } catch (err) {
      setError('Error al buscar el paquete. Intenta nuevamente.');
      console.error('Error searching package:', err);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusIcon = (status) => {
    const icons = {
      created: <PackageIcon className="h-6 w-6" />,
      collected: <CheckCircle className="h-6 w-6" />,
      in_transit: <Truck className="h-6 w-6" />,
      out_for_delivery: <Navigation className="h-6 w-6" />,
      delivered: <Home className="h-6 w-6" />,
      returned: <RotateCcw className="h-6 w-6" />
    };
    return icons[status] || <PackageIcon className="h-6 w-6" />;
  };

  const getStatusProgress = (status) => {
    const progress = {
      created: 1,
      collected: 2,
      in_transit: 3,
      out_for_delivery: 4,
      delivered: 5,
      returned: 1
    };
    return progress[status] || 1;
  };

  const getStatusMessage = (status) => {
    const messages = {
      created: 'Tu paquete ha sido creado y está listo para ser recolectado.',
      collected: 'Tu paquete ha sido recolectado y está en nuestro centro de distribución.',
      in_transit: 'Tu paquete está en camino hacia su destino.',
      out_for_delivery: 'Tu paquete está siendo entregado. ¡Estará contigo pronto!',
      delivered: '¡Tu paquete ha sido entregado exitosamente!',
      returned: 'Tu paquete ha sido devuelto al remitente.'
    };
    return messages[status] || 'Estado del paquete';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Rastrea tu Paquete
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Ingresa tu código de tracking para conocer el estado actual de tu envío
          </p>
        </div>

        {/* Search Form */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="Ingresa tu código de tracking (ej: ITO-2025-001234)"
                className="w-full pl-12 pr-4 py-4 text-lg border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                value={trackingCode}
                onChange={(e) => setTrackingCode(e.target.value)}
              />
            </div>
            
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-600 text-white py-4 px-6 rounded-xl text-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
                  Buscando...
                </>
              ) : (
                <>
                  <Search className="h-5 w-5 mr-3" />
                  Rastrear Paquete
                </>
              )}
            </button>
          </form>

          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center">
              <AlertCircle className="h-5 w-5 text-red-600 mr-3" />
              <p className="text-red-700">{error}</p>
            </div>
          )}
        </div>

        {/* Package Information */}
        {package_ && (
          <div className="space-y-8">
            {/* Status Overview */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <div className="text-center mb-8">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full ${PackageService.getStatusColor(package_.status)} mb-4`}>
                  {getStatusIcon(package_.status)}
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  {PackageService.getStatusLabel(package_.status)}
                </h2>
                <p className="text-gray-600">{getStatusMessage(package_.status)}</p>
              </div>

              {/* Current Location */}
              <div className="bg-gray-50 rounded-xl p-4 flex items-center justify-center">
                <MapPin className="h-5 w-5 text-gray-500 mr-2" />
                <span className="text-gray-700">
                  Ubicación actual: <strong>{package_.location.current}</strong>
                </span>
              </div>
            </div>

            {/* Progress Tracker */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Progreso del Envío</h3>
              
              <div className="relative">
                <div className="flex items-center">
                  {['created', 'collected', 'in_transit', 'out_for_delivery', 'delivered'].map((status, index) => {
                    const isActive = getStatusProgress(package_.status) > index;
                    const isCurrent = getStatusProgress(package_.status) === index + 1;
                    
                    return (
                      <React.Fragment key={status}>
                        <div className={`flex items-center justify-center w-12 h-12 rounded-full border-2 ${
                          isActive 
                            ? 'bg-blue-600 border-blue-600 text-white' 
                            : isCurrent
                            ? 'bg-blue-100 border-blue-600 text-blue-600'
                            : 'bg-gray-100 border-gray-300 text-gray-400'
                        }`}>
                          {getStatusIcon(status)}
                        </div>
                        
                        {index < 4 && (
                          <div className={`flex-1 h-1 mx-4 ${
                            isActive ? 'bg-blue-600' : 'bg-gray-300'
                          }`} />
                        )}
                      </React.Fragment>
                    );
                  })}
                </div>
                
                <div className="flex justify-between mt-4 text-sm text-gray-600">
                  <span>Creado</span>
                  <span>Recolectado</span>
                  <span>En Tránsito</span>
                  <span>En Reparto</span>
                  <span>Entregado</span>
                </div>
              </div>
            </div>

            {/* Package Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Shipping Information */}
              <div className="bg-white rounded-2xl shadow-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Información del Envío</h3>
                
                <div className="space-y-4">
                  <div className="flex items-center">
                    <PackageIcon className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Código de Tracking</p>
                      <p className="font-medium text-gray-900">{package_.trackingCode}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Fecha de Envío</p>
                      <p className="font-medium text-gray-900">{formatDate(package_.dates.created)}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-400 mr-3" />
                    <div>
                      <p className="text-sm text-gray-500">Entrega Estimada</p>
                      <p className="font-medium text-gray-900">{formatDate(package_.dates.estimated_delivery)}</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${PackageService.getPriorityColor(package_.packageDetails.priority)}`}>
                      {PackageService.getPriorityLabel(package_.packageDetails.priority)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-white rounded-2xl shadow-xl p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Información de Contacto</h3>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Destinatario</p>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="font-medium text-gray-900">{package_.recipient.name}</p>
                      <p className="text-sm text-gray-600 flex items-center mt-1">
                        <Phone className="h-4 w-4 mr-1" />
                        {package_.recipient.phone}
                      </p>
                    </div>
                  </div>
                  
                  <div>
                    <p className="text-sm text-gray-500 mb-2">Dirección de Entrega</p>
                    <div className="bg-gray-50 rounded-lg p-3">
                      <p className="text-sm text-gray-700">{package_.recipient.address}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tracking History */}
            <div className="bg-white rounded-2xl shadow-xl p-8">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Historial de Tracking</h3>
              
              <div className="space-y-4">
                {package_.location.history.map((entry, index) => (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                        <MapPin className="h-5 w-5 text-blue-600" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-base font-medium text-gray-900">{entry.location}</p>
                      <p className="text-sm text-gray-500">{formatDate(entry.timestamp)}</p>
                      {entry.note && (
                        <p className="text-sm text-gray-600 mt-1">{entry.note}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Information */}
            <div className="bg-blue-50 rounded-2xl p-6 text-center">
              <p className="text-blue-800 mb-2">
                ¿Tienes alguna pregunta sobre tu envío?
              </p>
              <p className="text-blue-600">
                Contáctanos al <strong>(506) 8888-8888</strong> o 
                <strong> info@itoboxcourier.com</strong>
              </p>
            </div>
          </div>
        )}

        {/* Instructions */}
        {!package_ && !loading && (
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              ¿Cómo rastrear tu paquete?
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-semibold">1</span>
                </div>
                <h4 className="font-medium text-gray-900 mb-2">Encuentra tu código</h4>
                <p className="text-sm text-gray-600">
                  Busca el código de tracking en tu recibo o email de confirmación
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-semibold">2</span>
                </div>
                <h4 className="font-medium text-gray-900 mb-2">Ingresa el código</h4>
                <p className="text-sm text-gray-600">
                  Escribe tu código de tracking en el campo de búsqueda
                </p>
              </div>
              
              <div className="text-center">
                <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-3">
                  <span className="text-blue-600 font-semibold">3</span>
                </div>
                <h4 className="font-medium text-gray-900 mb-2">Ve el estado</h4>
                <p className="text-sm text-gray-600">
                  Conoce la ubicación actual y el progreso de tu envío
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PublicTracking;