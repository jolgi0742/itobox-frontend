// components/clients/ClientDetails.jsx
import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Edit, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Building,
  Package,
  DollarSign,
  Calendar,
  Star,
  Gift,
  Activity,
  TrendingUp,
  CreditCard,
  Eye,
  Plus
} from 'lucide-react';
import ClientService from '../../services/ClientService';
import PackageService from '../../services/PackageService';

const ClientDetails = ({ clientId, onEdit, onBack, onCreatePackage }) => {
  const [client, setClient] = useState(null);
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadClientData();
  }, [clientId]);

  const loadClientData = () => {
    setLoading(true);
    try {
      const clientData = ClientService.getClientById(clientId);
      if (clientData) {
        setClient(clientData);
        
        // Cargar paquetes del cliente
        const clientPackages = ClientService.getClientPackages(clientId);
        setPackages(clientPackages);
      }
    } catch (error) {
      console.error('Error loading client data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const formatDateTime = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-ES', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const calculateStatistics = () => {
    if (!packages.length) return { thisMonth: 0, lastMonth: 0, growth: 0 };
    
    const now = new Date();
    const thisMonth = packages.filter(pkg => {
      const pkgDate = new Date(pkg.dates.created);
      return pkgDate.getMonth() === now.getMonth() && pkgDate.getFullYear() === now.getFullYear();
    }).length;
    
    const lastMonth = packages.filter(pkg => {
      const pkgDate = new Date(pkg.dates.created);
      const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1);
      return pkgDate.getMonth() === lastMonthDate.getMonth() && pkgDate.getFullYear() === lastMonthDate.getFullYear();
    }).length;
    
    const growth = lastMonth > 0 ? ((thisMonth - lastMonth) / lastMonth) * 100 : thisMonth > 0 ? 100 : 0;
    
    return { thisMonth, lastMonth, growth };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!client) {
    return (
      <div className="text-center py-12">
        <User className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Cliente no encontrado</h3>
        <div className="mt-6">
          <button
            onClick={onBack}
            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver a la lista
          </button>
        </div>
      </div>
    );
  }

  const stats = calculateStatistics();

  const tabs = [
    { id: 'overview', label: 'Resumen', icon: User },
    { id: 'packages', label: 'Paquetes', icon: Package },
    { id: 'contact', label: 'Contacto', icon: Phone },
    { id: 'account', label: 'Cuenta', icon: CreditCard }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={onBack}
                className="p-2 text-gray-400 hover:text-gray-600"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              
              <div className="flex items-center space-x-4">
                <div className="h-16 w-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                  {client.businessInfo.isCompany ? (
                    <Building className="h-8 w-8 text-white" />
                  ) : (
                    <span className="text-white text-xl font-bold">
                      {client.personalInfo.firstName.charAt(0)}{client.personalInfo.lastName.charAt(0)}
                    </span>
                  )}
                </div>
                
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">{client.personalInfo.fullName}</h1>
                  <div className="flex items-center space-x-4 mt-1">
                    <span className="text-sm text-gray-500">{client.clientCode}</span>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ClientService.getStatusColor(client.accountInfo.status)}`}>
                      {ClientService.getStatusLabel(client.accountInfo.status)}
                    </span>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${ClientService.getCustomerTypeColor(client.accountInfo.customerType)}`}>
                      {client.accountInfo.customerType === 'vip' && <Star className="h-3 w-3 mr-1" />}
                      {ClientService.getCustomerTypeLabel(client.accountInfo.customerType)}
                    </span>
                  </div>
                  {client.businessInfo.isCompany && (
                    <p className="text-sm text-gray-600 mt-1">{client.businessInfo.companyName}</p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={() => onCreatePackage && onCreatePackage(client.id)}
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md text-sm font-medium hover:bg-green-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Nuevo Paquete
              </button>
              
              <button
                onClick={() => onEdit(client.id)}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Edit className="h-4 w-4 mr-2" />
                Editar
              </button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-t border-gray-200">
          <nav className="flex space-x-8 px-6">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon className="h-4 w-4 mr-2" />
                  {tab.label}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Stats Cards */}
          <div className="lg:col-span-3 grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <Package className="h-8 w-8 text-blue-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-500">Total Paquetes</p>
                  <p className="text-2xl font-semibold text-gray-900">{client.statistics.totalPackages}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-green-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-500">Total Gastado</p>
                  <p className="text-2xl font-semibold text-gray-900">{formatCurrency(client.statistics.totalSpent)}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <TrendingUp className="h-8 w-8 text-purple-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-500">Este Mes</p>
                  <p className="text-2xl font-semibold text-gray-900">{stats.thisMonth}</p>
                  {stats.growth !== 0 && (
                    <p className={`text-xs ${stats.growth > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {stats.growth > 0 ? '+' : ''}{stats.growth.toFixed(1)}%
                    </p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center">
                <Gift className="h-8 w-8 text-orange-600" />
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-500">Puntos Fidelidad</p>
                  <p className="text-2xl font-semibold text-gray-900">{client.accountInfo.loyaltyPoints}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Info */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Información Rápida</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p className="text-sm font-medium text-gray-900">{client.personalInfo.email}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Phone className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Teléfono</p>
                    <p className="text-sm font-medium text-gray-900">{client.personalInfo.phone}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Ubicación</p>
                    <p className="text-sm font-medium text-gray-900">
                      {client.contactInfo.primaryAddress.city}, {client.contactInfo.primaryAddress.state}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Cliente desde</p>
                    <p className="text-sm font-medium text-gray-900">{formatDate(client.dates.created)}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Activity className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Última actividad</p>
                    <p className="text-sm font-medium text-gray-900">
                      {client.dates.lastActivity ? formatDate(client.dates.lastActivity) : 'Sin actividad'}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <DollarSign className="h-5 w-5 text-gray-400 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Descuento</p>
                    <p className="text-sm font-medium text-green-600">{client.accountInfo.discountRate}%</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Favorite Services */}
            {client.statistics.favoriteServices.length > 0 && (
              <div className="mt-6">
                <p className="text-sm text-gray-500 mb-2">Servicios Preferidos</p>
                <div className="flex flex-wrap gap-2">
                  {client.statistics.favoriteServices.slice(0, 3).map((service, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                    >
                      {PackageService.getPriorityLabel(service)}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Tags */}
            {client.tags.length > 0 && (
              <div className="mt-6">
                <p className="text-sm text-gray-500 mb-2">Etiquetas</p>
                <div className="flex flex-wrap gap-2">
                  {client.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Actividad Reciente</h3>
            
            {packages.length === 0 ? (
              <div className="text-center py-8">
                <Package className="mx-auto h-8 w-8 text-gray-400" />
                <p className="mt-2 text-sm text-gray-500">Sin actividad aún</p>
              </div>
            ) : (
              <div className="space-y-4">
                {packages.slice(0, 5).map((pkg) => (
                  <div key={pkg.id} className="flex items-center space-x-3">
                    <div className={`w-2 h-2 rounded-full ${PackageService.getStatusColor(pkg.status).includes('green') ? 'bg-green-400' : 'bg-blue-400'}`}></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {pkg.trackingCode}
                      </p>
                      <p className="text-xs text-gray-500">
                        {formatDateTime(pkg.dates.created)}
                      </p>
                    </div>
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${PackageService.getStatusColor(pkg.status)}`}>
                      {PackageService.getStatusLabel(pkg.status)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Packages Tab */}
      {activeTab === 'packages' && (
        <div className="bg-white shadow rounded-lg">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium text-gray-900">Historial de Paquetes</h3>
              <button
                onClick={() => onCreatePackage && onCreatePackage(client.id)}
                className="inline-flex items-center px-3 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Nuevo Paquete
              </button>
            </div>
          </div>
          
          <div className="p-6">
            {packages.length === 0 ? (
              <div className="text-center py-12">
                <Package className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-sm font-medium text-gray-900">Sin paquetes</h3>
                <p className="mt-1 text-sm text-gray-500">Este cliente aún no ha enviado paquetes.</p>
                <div className="mt-6">
                  <button
                    onClick={() => onCreatePackage && onCreatePackage(client.id)}
                    className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Crear primer paquete
                  </button>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Código
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Destinatario
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Estado
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Costo
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Fecha
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Acciones
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {packages.map((pkg) => (
                      <tr key={pkg.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">{pkg.trackingCode}</div>
                          <div className="text-sm text-gray-500">{pkg.packageDetails.description}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{pkg.recipient.name}</div>
                          <div className="text-sm text-gray-500">{pkg.recipient.phone}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${PackageService.getStatusColor(pkg.status)}`}>
                            {PackageService.getStatusLabel(pkg.status)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatCurrency(pkg.cost)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(pkg.dates.created)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <button
                            className="text-blue-600 hover:text-blue-900"
                            title="Ver detalles"
                          >
                            <Eye className="h-4 w-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Contact Tab */}
      {activeTab === 'contact' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Primary Address */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Dirección Principal</h3>
            <div className="space-y-3">
              <div>
                <p className="text-sm text-gray-500">Dirección</p>
                <p className="text-sm font-medium text-gray-900">{client.contactInfo.primaryAddress.street}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Ciudad</p>
                <p className="text-sm font-medium text-gray-900">{client.contactInfo.primaryAddress.city}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Provincia</p>
                <p className="text-sm font-medium text-gray-900">{client.contactInfo.primaryAddress.state}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Código Postal</p>
                <p className="text-sm font-medium text-gray-900">{client.contactInfo.primaryAddress.zipCode || '-'}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">País</p>
                <p className="text-sm font-medium text-gray-900">{client.contactInfo.primaryAddress.country}</p>
              </div>
            </div>
          </div>

          {/* Emergency Contact */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Contacto de Emergencia</h3>
            {client.contactInfo.emergencyContact.name ? (
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-gray-500">Nombre</p>
                  <p className="text-sm font-medium text-gray-900">{client.contactInfo.emergencyContact.name}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Teléfono</p>
                  <p className="text-sm font-medium text-gray-900">{client.contactInfo.emergencyContact.phone}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Parentesco</p>
                  <p className="text-sm font-medium text-gray-900">{client.contactInfo.emergencyContact.relationship}</p>
                </div>
              </div>
            ) : (
              <p className="text-sm text-gray-500">No hay contacto de emergencia registrado</p>
            )}
          </div>

          {/* Alternative Addresses */}
          {client.contactInfo.alternativeAddresses.length > 0 && (
            <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Direcciones Alternativas</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {client.contactInfo.alternativeAddresses.map((address, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-medium text-gray-900 mb-2">{address.label}</h4>
                    <p className="text-sm text-gray-600">{address.street}</p>
                    <p className="text-sm text-gray-600">{address.city}, {address.state}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Account Tab */}
      {activeTab === 'account' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Account Information */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Información de Cuenta</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">Tipo de Cliente</p>
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-sm font-medium ${ClientService.getCustomerTypeColor(client.accountInfo.customerType)}`}>
                  {ClientService.getCustomerTypeLabel(client.accountInfo.customerType)}
                </span>
              </div>
              <div>
                <p className="text-sm text-gray-500">Límite de Crédito</p>
                <p className="text-sm font-medium text-gray-900">{formatCurrency(client.accountInfo.creditLimit)}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Términos de Pago</p>
                <p className="text-sm font-medium text-gray-900">{client.accountInfo.paymentTerms}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Método de Pago Preferido</p>
                <p className="text-sm font-medium text-gray-900">{client.accountInfo.preferredPaymentMethod}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Descuento</p>
                <p className="text-sm font-medium text-green-600">{client.accountInfo.discountRate}%</p>
              </div>
            </div>
          </div>

          {/* Business Information */}
          {client.businessInfo.isCompany && (
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Información Empresarial</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-gray-500">Nombre de la Empresa</p>
                  <p className="text-sm font-medium text-gray-900">{client.businessInfo.companyName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">RUC/NIT</p>
                  <p className="text-sm font-medium text-gray-900">{client.businessInfo.taxId}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Industria</p>
                  <p className="text-sm font-medium text-gray-900">{client.businessInfo.industry || '-'}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Número de Empleados</p>
                  <p className="text-sm font-medium text-gray-900">{client.businessInfo.employeeCount || '-'}</p>
                </div>
                {client.businessInfo.website && (
                  <div>
                    <p className="text-sm text-gray-500">Sitio Web</p>
                    <a
                      href={client.businessInfo.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm font-medium text-blue-600 hover:text-blue-800"
                    >
                      {client.businessInfo.website}
                    </a>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Preferences */}
          <div className="bg-white rounded-lg shadow p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Preferencias</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-gray-500">Método de Comunicación</p>
                <p className="text-sm font-medium text-gray-900">{client.preferences.communicationMethod}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Idioma</p>
                <p className="text-sm font-medium text-gray-900">{client.preferences.language}</p>
              </div>
              <div>
                <p className="text-sm text-gray-500">Newsletter</p>
                <p className="text-sm font-medium text-gray-900">
                  {client.preferences.newsletterSubscribed ? 'Suscrito' : 'No suscrito'}
                </p>
              </div>
              {client.preferences.specialInstructions && (
                <div>
                  <p className="text-sm text-gray-500">Instrucciones Especiales</p>
                  <p className="text-sm font-medium text-gray-900">{client.preferences.specialInstructions}</p>
                </div>
              )}
            </div>
          </div>

          {/* Notes */}
          {client.notes && (
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Notas</h3>
              <p className="text-sm text-gray-700">{client.notes}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ClientDetails;