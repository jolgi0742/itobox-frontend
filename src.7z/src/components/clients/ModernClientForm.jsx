// components/clients/ModernClientForm.jsx - Formulario de clientes ultra moderno
import React, { useState, useEffect } from 'react';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Building,
  CreditCard,
  Star,
  Save,
  ArrowLeft,
  CheckCircle,
  AlertCircle,
  Upload,
  Camera
} from 'lucide-react';

const ModernClientForm = ({ clientData, onSave, onCancel, isEditing = false }) => {
  const [formData, setFormData] = useState({
    personal: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      secondaryPhone: '',
      dateOfBirth: '',
      identification: ''
    },
    address: {
      street: '',
      city: '',
      state: '',
      zipCode: '',
      country: 'Costa Rica'
    },
    business: {
      isBusinessClient: false,
      companyName: '',
      position: '',
      taxId: '',
      industry: '',
      website: ''
    },
    preferences: {
      clientType: 'individual',
      preferredContact: 'email',
      notifications: {
        email: true,
        sms: true,
        whatsapp: false
      },
      language: 'es'
    },
    additional: {
      notes: '',
      creditLimit: 0,
      paymentTerms: 'immediate',
      discount: 0
    }
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [errors, setErrors] = useState({});
  const [avatar, setAvatar] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);

  const steps = [
    { id: 1, title: 'Personal', icon: User },
    { id: 2, title: 'Dirección', icon: MapPin },
    { id: 3, title: 'Empresa', icon: Building },
    { id: 4, title: 'Preferencias', icon: Star },
    { id: 5, title: 'Confirmación', icon: CheckCircle }
  ];

  const clientTypes = [
    { id: 'individual', name: 'Individual', description: 'Cliente personal', color: '#6b7280' },
    { id: 'business', name: 'Empresa', description: 'Cliente corporativo', color: '#3b82f6' },
    { id: 'premium', name: 'Premium', description: 'Cliente premium', color: '#8b5cf6' },
    { id: 'vip', name: 'VIP', description: 'Cliente VIP', color: '#f59e0b' }
  ];

  const industries = [
    'Tecnología', 'Retail', 'Manufactura', 'Servicios', 'Salud',
    'Educación', 'Finanzas', 'Gobierno', 'Otros'
  ];

  useEffect(() => {
    if (clientData && isEditing) {
      setFormData(clientData);
      if (clientData.avatar) {
        setPreviewUrl(clientData.avatar);
      }
    }
  }, [clientData, isEditing]);

  const handleInputChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handleNestedChange = (section, subsection, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [subsection]: {
          ...prev[section][subsection],
          [field]: value
        }
      }
    }));
  };

  const handleAvatarChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setAvatar(file);
      const reader = new FileReader();
      reader.onload = (e) => setPreviewUrl(e.target.result);
      reader.readAsDataURL(file);
    }
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    switch (step) {
      case 1:
        if (!formData.personal.firstName) newErrors['personal.firstName'] = 'Nombre requerido';
        if (!formData.personal.lastName) newErrors['personal.lastName'] = 'Apellido requerido';
        if (!formData.personal.email) newErrors['personal.email'] = 'Email requerido';
        if (!formData.personal.phone) newErrors['personal.phone'] = 'Teléfono requerido';
        break;
      case 2:
        if (!formData.address.street) newErrors['address.street'] = 'Dirección requerida';
        if (!formData.address.city) newErrors['address.city'] = 'Ciudad requerida';
        break;
      case 3:
        if (formData.business.isBusinessClient && !formData.business.companyName) {
          newErrors['business.companyName'] = 'Nombre de empresa requerido';
        }
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 5));
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = () => {
    if (validateStep(currentStep)) {
      const finalData = { ...formData };
      if (avatar) {
        finalData.avatar = previewUrl;
      }
      onSave(finalData);
    }
  };

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
      padding: '40px 20px'
    },
    wrapper: {
      maxWidth: '1000px',
      margin: '0 auto'
    },
    header: {
      marginBottom: '40px'
    },
    backButton: {
      display: 'flex',
      alignItems: 'center',
      background: 'white',
      border: 'none',
      padding: '12px 20px',
      borderRadius: '12px',
      cursor: 'pointer',
      marginBottom: '24px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      transition: 'all 0.3s ease'
    },
    title: {
      fontSize: '2.5rem',
      fontWeight: '800',
      color: '#1e293b',
      marginBottom: '8px'
    },
    subtitle: {
      color: '#64748b',
      fontSize: '1.1rem'
    },
    stepperContainer: {
      background: 'white',
      borderRadius: '20px',
      padding: '32px',
      boxShadow: '0 20px 40px -8px rgba(0, 0, 0, 0.08)',
      marginBottom: '32px'
    },
    stepper: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '32px'
    },
    step: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      position: 'relative',
      flex: 1
    },
    stepIcon: {
      width: '60px',
      height: '60px',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '12px',
      transition: 'all 0.3s ease'
    },
    stepTitle: {
      fontSize: '0.875rem',
      fontWeight: '600',
      textAlign: 'center'
    },
    stepLine: {
      position: 'absolute',
      top: '30px',
      left: '50%',
      width: '100%',
      height: '2px',
      backgroundColor: '#e2e8f0',
      zIndex: -1
    },
    formCard: {
      background: 'white',
      borderRadius: '20px',
      padding: '40px',
      boxShadow: '0 20px 40px -8px rgba(0, 0, 0, 0.08)',
      marginBottom: '32px'
    },
    formGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
      gap: '24px'
    },
    inputGroup: {
      marginBottom: '24px'
    },
    label: {
      display: 'block',
      fontSize: '0.875rem',
      fontWeight: '700',
      color: '#374151',
      marginBottom: '8px',
      textTransform: 'uppercase',
      letterSpacing: '0.05em'
    },
    input: {
      width: '100%',
      padding: '16px 20px',
      borderRadius: '12px',
      border: '2px solid #e2e8f0',
      fontSize: '1rem',
      transition: 'all 0.3s ease',
      boxSizing: 'border-box'
    },
    select: {
      width: '100%',
      padding: '16px 20px',
      borderRadius: '12px',
      border: '2px solid #e2e8f0',
      fontSize: '1rem',
      backgroundColor: 'white',
      cursor: 'pointer',
      transition: 'all 0.3s ease'
    },
    avatarSection: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      marginBottom: '32px'
    },
    avatarPreview: {
      width: '120px',
      height: '120px',
      borderRadius: '50%',
      border: '4px solid #e2e8f0',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '16px',
      overflow: 'hidden',
      backgroundColor: '#f8fafc'
    },
    avatarUpload: {
      display: 'none'
    },
    avatarButton: {
      background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
      color: 'white',
      border: 'none',
      padding: '12px 24px',
      borderRadius: '12px',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      fontSize: '0.875rem',
      fontWeight: '600'
    },
    typeCard: {
      border: '2px solid #e2e8f0',
      borderRadius: '16px',
      padding: '24px',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      marginBottom: '16px',
      textAlign: 'center'
    },
    typeCardActive: {
      borderColor: '#3b82f6',
      backgroundColor: '#f0f9ff',
      boxShadow: '0 8px 24px rgba(59, 130, 246, 0.15)'
    },
    checkbox: {
      display: 'flex',
      alignItems: 'center',
      padding: '16px',
      backgroundColor: '#f8fafc',
      borderRadius: '12px',
      marginBottom: '12px',
      cursor: 'pointer'
    },
    buttonGroup: {
      display: 'flex',
      gap: '16px',
      justifyContent: 'space-between',
      marginTop: '32px'
    },
    button: {
      padding: '16px 32px',
      borderRadius: '12px',
      border: 'none',
      fontSize: '1rem',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    },
    primaryButton: {
      background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
      color: 'white',
      boxShadow: '0 8px 24px rgba(59, 130, 246, 0.25)'
    },
    secondaryButton: {
      backgroundColor: '#f1f5f9',
      color: '#64748b',
      border: '2px solid #e2e8f0'
    },
    error: {
      color: '#ef4444',
      fontSize: '0.875rem',
      marginTop: '4px',
      display: 'flex',
      alignItems: 'center',
      gap: '4px'
    },
    toggle: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '20px',
      backgroundColor: '#f8fafc',
      borderRadius: '16px',
      marginBottom: '24px'
    },
    toggleSwitch: {
      position: 'relative',
      width: '60px',
      height: '30px',
      backgroundColor: '#e2e8f0',
      borderRadius: '15px',
      cursor: 'pointer',
      transition: 'all 0.3s ease'
    },
    toggleSwitchActive: {
      backgroundColor: '#3b82f6'
    },
    toggleKnob: {
      position: 'absolute',
      top: '3px',
      left: '3px',
      width: '24px',
      height: '24px',
      backgroundColor: 'white',
      borderRadius: '50%',
      transition: 'all 0.3s ease',
      boxShadow: '0 2px 4px rgba(0,0,0,0.2)'
    },
    toggleKnobActive: {
      transform: 'translateX(30px)'
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div style={styles.formCard}>
            <div style={styles.avatarSection}>
              <div style={styles.avatarPreview}>
                {previewUrl ? (
                  <img src={previewUrl} alt="Avatar" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                ) : (
                  <User size={48} color="#64748b" />
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={handleAvatarChange}
                style={styles.avatarUpload}
                id="avatar-upload"
              />
              <label htmlFor="avatar-upload" style={styles.avatarButton}>
                <Camera size={16} />
                Subir Foto
              </label>
            </div>

            <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b', textAlign: 'center' }}>
              Información Personal
            </h3>
            
            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Nombre *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['personal.firstName'] ? { borderColor: '#ef4444' } : {})
                  }}
                  value={formData.personal.firstName}
                  onChange={(e) => handleInputChange('personal', 'firstName', e.target.value)}
                  placeholder="Juan"
                />
                {errors['personal.firstName'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['personal.firstName']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Apellido *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['personal.lastName'] ? { borderColor: '#ef4444' } : {})
                  }}
                  value={formData.personal.lastName}
                  onChange={(e) => handleInputChange('personal', 'lastName', e.target.value)}
                  placeholder="Pérez"
                />
                {errors['personal.lastName'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['personal.lastName']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Email *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['personal.email'] ? { borderColor: '#ef4444' } : {})
                  }}
                  type="email"
                  value={formData.personal.email}
                  onChange={(e) => handleInputChange('personal', 'email', e.target.value)}
                  placeholder="juan@ejemplo.com"
                />
                {errors['personal.email'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['personal.email']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Teléfono *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['personal.phone'] ? { borderColor: '#ef4444' } : {})
                  }}
                  value={formData.personal.phone}
                  onChange={(e) => handleInputChange('personal', 'phone', e.target.value)}
                  placeholder="+506 8888-8888"
                />
                {errors['personal.phone'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['personal.phone']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Teléfono Secundario</label>
                <input
                  style={styles.input}
                  value={formData.personal.secondaryPhone}
                  onChange={(e) => handleInputChange('personal', 'secondaryPhone', e.target.value)}
                  placeholder="+506 2222-2222"
                />
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Identificación</label>
                <input
                  style={styles.input}
                  value={formData.personal.identification}
                  onChange={(e) => handleInputChange('personal', 'identification', e.target.value)}
                  placeholder="1-1234-5678"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div style={styles.formCard}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b' }}>
              Dirección
            </h3>
            <div style={styles.formGrid}>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={styles.label}>Dirección *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['address.street'] ? { borderColor: '#ef4444' } : {})
                  }}
                  value={formData.address.street}
                  onChange={(e) => handleInputChange('address', 'street', e.target.value)}
                  placeholder="Calle y número"
                />
                {errors['address.street'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['address.street']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Ciudad *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['address.city'] ? { borderColor: '#ef4444' } : {})
                  }}
                  value={formData.address.city}
                  onChange={(e) => handleInputChange('address', 'city', e.target.value)}
                  placeholder="San José"
                />
                {errors['address.city'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['address.city']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Provincia</label>
                <select
                  style={styles.select}
                  value={formData.address.state}
                  onChange={(e) => handleInputChange('address', 'state', e.target.value)}
                >
                  <option value="">Seleccionar...</option>
                  <option value="San José">San José</option>
                  <option value="Alajuela">Alajuela</option>
                  <option value="Cartago">Cartago</option>
                  <option value="Heredia">Heredia</option>
                  <option value="Guanacaste">Guanacaste</option>
                  <option value="Puntarenas">Puntarenas</option>
                  <option value="Limón">Limón</option>
                </select>
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Código Postal</label>
                <input
                  style={styles.input}
                  value={formData.address.zipCode}
                  onChange={(e) => handleInputChange('address', 'zipCode', e.target.value)}
                  placeholder="10101"
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div style={styles.formCard}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b' }}>
              Información de Empresa
            </h3>

            <div style={styles.toggle}>
              <div>
                <h4 style={{ fontSize: '1.1rem', fontWeight: '600', marginBottom: '4px' }}>
                  Cliente Empresarial
                </h4>
                <p style={{ color: '#64748b', margin: 0 }}>
                  Marcar si es un cliente corporativo
                </p>
              </div>
              <div
                style={{
                  ...styles.toggleSwitch,
                  ...(formData.business.isBusinessClient ? styles.toggleSwitchActive : {})
                }}
                onClick={() => handleInputChange('business', 'isBusinessClient', !formData.business.isBusinessClient)}
              >
                <div style={{
                  ...styles.toggleKnob,
                  ...(formData.business.isBusinessClient ? styles.toggleKnobActive : {})
                }}></div>
              </div>
            </div>

            {formData.business.isBusinessClient && (
              <div style={styles.formGrid}>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>Nombre de la Empresa *</label>
                  <input
                    style={{
                      ...styles.input,
                      ...(errors['business.companyName'] ? { borderColor: '#ef4444' } : {})
                    }}
                    value={formData.business.companyName}
                    onChange={(e) => handleInputChange('business', 'companyName', e.target.value)}
                    placeholder="Empresa S.A."
                  />
                  {errors['business.companyName'] && (
                    <div style={styles.error}>
                      <AlertCircle size={16} />
                      {errors['business.companyName']}
                    </div>
                  )}
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Cargo</label>
                  <input
                    style={styles.input}
                    value={formData.business.position}
                    onChange={(e) => handleInputChange('business', 'position', e.target.value)}
                    placeholder="Gerente General"
                  />
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Cédula Jurídica</label>
                  <input
                    style={styles.input}
                    value={formData.business.taxId}
                    onChange={(e) => handleInputChange('business', 'taxId', e.target.value)}
                    placeholder="3-101-123456"
                  />
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Industria</label>
                  <select
                    style={styles.select}
                    value={formData.business.industry}
                    onChange={(e) => handleInputChange('business', 'industry', e.target.value)}
                  >
                    <option value="">Seleccionar...</option>
                    {industries.map(industry => (
                      <option key={industry} value={industry}>{industry}</option>
                    ))}
                  </select>
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Sitio Web</label>
                  <input
                    style={styles.input}
                    value={formData.business.website}
                    onChange={(e) => handleInputChange('business', 'website', e.target.value)}
                    placeholder="https://empresa.com"
                  />
                </div>
              </div>
            )}
          </div>
        );

      case 4:
        return (
          <div style={styles.formCard}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b' }}>
              Preferencias del Cliente
            </h3>

            <h4 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '16px' }}>
              Tipo de Cliente
            </h4>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', marginBottom: '32px' }}>
              {clientTypes.map((type) => (
                <div
                  key={type.id}
                  style={{
                    ...styles.typeCard,
                    ...(formData.preferences.clientType === type.id ? styles.typeCardActive : {})
                  }}
                  onClick={() => handleInputChange('preferences', 'clientType', type.id)}
                >
                  <div style={{
                    width: '48px',
                    height: '48px',
                    borderRadius: '50%',
                    backgroundColor: type.color,
                    margin: '0 auto 12px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    {type.id === 'vip' ? <Star size={24} color="white" /> : <User size={24} color="white" />}
                  </div>
                  <h5 style={{ fontSize: '1.1rem', fontWeight: '600', marginBottom: '4px' }}>
                    {type.name}
                  </h5>
                  <p style={{ color: '#64748b', fontSize: '0.875rem', margin: 0 }}>
                    {type.description}
                  </p>
                </div>
              ))}
            </div>

            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Contacto Preferido</label>
                <select
                  style={styles.select}
                  value={formData.preferences.preferredContact}
                  onChange={(e) => handleInputChange('preferences', 'preferredContact', e.target.value)}
                >
                  <option value="email">Email</option>
                  <option value="phone">Teléfono</option>
                  <option value="sms">SMS</option>
                  <option value="whatsapp">WhatsApp</option>
                </select>
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Idioma</label>
                <select
                  style={styles.select}
                  value={formData.preferences.language}
                  onChange={(e) => handleInputChange('preferences', 'language', e.target.value)}
                >
                  <option value="es">Español</option>
                  <option value="en">English</option>
                </select>
              </div>
            </div>

            <h4 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '16px' }}>
              Notificaciones
            </h4>

            <div style={styles.checkbox} onClick={() => handleNestedChange('preferences', 'notifications', 'email', !formData.preferences.notifications.email)}>
              <input
                type="checkbox"
                checked={formData.preferences.notifications.email}
                onChange={() => {}}
                style={{ marginRight: '12px' }}
              />
              <span style={{ fontWeight: '600' }}>Notificaciones por Email</span>
            </div>

            <div style={styles.checkbox} onClick={() => handleNestedChange('preferences', 'notifications', 'sms', !formData.preferences.notifications.sms)}>
              <input
                type="checkbox"
                checked={formData.preferences.notifications.sms}
                onChange={() => {}}
                style={{ marginRight: '12px' }}
              />
              <span style={{ fontWeight: '600' }}>Notificaciones por SMS</span>
            </div>

            <div style={styles.checkbox} onClick={() => handleNestedChange('preferences', 'notifications', 'whatsapp', !formData.preferences.notifications.whatsapp)}>
              <input
                type="checkbox"
                checked={formData.preferences.notifications.whatsapp}
                onChange={() => {}}
                style={{ marginRight: '12px' }}
              />
              <span style={{ fontWeight: '600' }}>Notificaciones por WhatsApp</span>
            </div>
          </div>
        );

      case 5:
        return (
          <div style={styles.formCard}>
            <div style={{ textAlign: 'center', marginBottom: '32px' }}>
              <CheckCircle size={64} color="#10b981" style={{ marginBottom: '16px' }} />
              <h3 style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1e293b' }}>
                Confirmar Cliente
              </h3>
              <p style={{ color: '#64748b' }}>
                Revisa la información antes de {isEditing ? 'actualizar' : 'crear'} el cliente
              </p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '24px' }}>
              <div>
                <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Información Personal</h4>
                <p>{formData.personal.firstName} {formData.personal.lastName}</p>
                <p>{formData.personal.email}</p>
                <p>{formData.personal.phone}</p>
              </div>

              <div>
                <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Dirección</h4>
                <p>{formData.address.street}</p>
                <p>{formData.address.city}, {formData.address.state}</p>
                <p>{formData.address.zipCode}</p>
              </div>

              {formData.business.isBusinessClient && (
                <div>
                  <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Empresa</h4>
                  <p>{formData.business.companyName}</p>
                  <p>{formData.business.position}</p>
                  <p>{formData.business.industry}</p>
                </div>
              )}

              <div>
                <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Preferencias</h4>
                <p>Tipo: {clientTypes.find(t => t.id === formData.preferences.clientType)?.name}</p>
                <p>Contacto: {formData.preferences.preferredContact}</p>
                <p>Idioma: {formData.preferences.language === 'es' ? 'Español' : 'English'}</p>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.wrapper}>
        <div style={styles.header}>
          <button
            style={styles.backButton}
            onClick={onCancel}
            onMouseEnter={(e) => {
              e.target.style.transform = 'translateY(-2px)';
              e.target.style.boxShadow = '0 8px 24px rgba(0,0,0,0.15)';
            }}
            onMouseLeave={(e) => {
              e.target.style.transform = 'translateY(0)';
              e.target.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
            }}
          >
            <ArrowLeft size={20} style={{ marginRight: '8px' }} />
            Regresar
          </button>
          
          <h1 style={styles.title}>
            {isEditing ? 'Editar Cliente' : 'Nuevo Cliente'}
          </h1>
          <p style={styles.subtitle}>
            Completa la información del cliente
          </p>
        </div>

        <div style={styles.stepperContainer}>
          <div style={styles.stepper}>
            {steps.map((step, index) => {
              const isActive = step.id === currentStep;
              const isCompleted = step.id < currentStep;
              const IconComponent = step.icon;
              
              return (
                <div key={step.id} style={styles.step}>
                  {index < steps.length - 1 && (
                    <div style={{
                      ...styles.stepLine,
                      backgroundColor: isCompleted ? '#10b981' : '#e2e8f0'
                    }}></div>
                  )}
                  
                  <div style={{
                    ...styles.stepIcon,
                    backgroundColor: isCompleted ? '#10b981' : isActive ? '#3b82f6' : '#f1f5f9',
                    color: isCompleted || isActive ? 'white' : '#64748b',
                    transform: isActive ? 'scale(1.1)' : 'scale(1)',
                    boxShadow: isActive ? '0 8px 24px rgba(59, 130, 246, 0.25)' : 'none'
                  }}>
                    {isCompleted ? <CheckCircle size={24} /> : <IconComponent size={24} />}
                  </div>
                  
                  <span style={{
                    ...styles.stepTitle,
                    color: isCompleted || isActive ? '#1e293b' : '#64748b'
                  }}>
                    {step.title}
                  </span>
                </div>
              );
            })}
          </div>

          {renderStepContent()}

          <div style={styles.buttonGroup}>
            <button
              style={{
                ...styles.button,
                ...styles.secondaryButton,
                opacity: currentStep === 1 ? 0.5 : 1,
                cursor: currentStep === 1 ? 'not-allowed' : 'pointer'
              }}
              onClick={prevStep}
              disabled={currentStep === 1}
            >
              <ArrowLeft size={20} />
              Anterior
            </button>

            {currentStep < 5 ? (
              <button
                style={{...styles.button, ...styles.primaryButton}}
                onClick={nextStep}
              >
                Siguiente
                <ArrowLeft size={20} style={{ transform: 'rotate(180deg)' }} />
              </button>
            ) : (
              <button
                style={{...styles.button, ...styles.primaryButton}}
                onClick={handleSubmit}
              >
                <Save size={20} />
                {isEditing ? 'Actualizar Cliente' : 'Crear Cliente'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModernClientForm;