// components/clients/ClientForm.jsx
import React, { useState, useEffect } from 'react';
import { 
  Save, 
  X, 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Building,
  CreditCard,
  Settings,
  Plus,
  Trash2,
  AlertCircle
} from 'lucide-react';
import ClientService from '../../services/ClientService';

const ClientForm = ({ clientId = null, onSave, onCancel }) => {
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [activeTab, setActiveTab] = useState('personal');
  const [formData, setFormData] = useState({
    personalInfo: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      dateOfBirth: '',
      documentType: 'cedula',
      documentNumber: ''
    },
    contactInfo: {
      primaryAddress: {
        street: '',
        city: '',
        state: '',
        zipCode: '',
        country: 'Costa Rica'
      },
      alternativeAddresses: [],
      emergencyContact: {
        name: '',
        phone: '',
        relationship: ''
      }
    },
    businessInfo: {
      isCompany: false,
      companyName: '',
      taxId: '',
      industry: '',
      employeeCount: '',
      website: ''
    },
    accountInfo: {
      customerType: 'individual',
      creditLimit: 0,
      paymentTerms: 'immediate',
      preferredPaymentMethod: 'cash'
    },
    preferences: {
      communicationMethod: 'email',
      newsletterSubscribed: false,
      language: 'es',
      specialInstructions: ''
    },
    notes: '',
    tags: []
  });

  const isEditing = Boolean(clientId);

  useEffect(() => {
    if (isEditing) {
      loadClient();
    }
  }, [clientId]);

  const loadClient = () => {
    try {
      const client = ClientService.getClientById(clientId);
      if (client) {
        setFormData({
          personalInfo: client.personalInfo,
          contactInfo: client.contactInfo,
          businessInfo: client.businessInfo,
          accountInfo: client.accountInfo,
          preferences: client.preferences,
          notes: client.notes || '',
          tags: client.tags || []
        });
      }
    } catch (error) {
      console.error('Error loading client:', error);
    }
  };

  const handleInputChange = (section, field, value, subField = null) => {
    if (subField) {
      setFormData(prev => ({
        ...prev,
        [section]: {
          ...prev[section],
          [field]: {
            ...prev[section][field],
            [subField]: value
          }
        }
      }));
    } else if (section) {
      setFormData(prev => ({
        ...prev,
        [section]: {
          ...prev[section],
          [field]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value
      }));
    }

    // Limpiar errores relacionados
    const errorKey = subField ? `${section}.${field}.${subField}` : section ? `${section}.${field}` : field;
    if (errors[errorKey]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[errorKey];
        return newErrors;
      });
    }
  };

  const addAlternativeAddress = () => {
    setFormData(prev => ({
      ...prev,
      contactInfo: {
        ...prev.contactInfo,
        alternativeAddresses: [
          ...prev.contactInfo.alternativeAddresses,
          {
            label: '',
            street: '',
            city: '',
            state: '',
            zipCode: '',
            isDefault: false
          }
        ]
      }
    }));
  };

  const removeAlternativeAddress = (index) => {
    setFormData(prev => ({
      ...prev,
      contactInfo: {
        ...prev.contactInfo,
        alternativeAddresses: prev.contactInfo.alternativeAddresses.filter((_, i) => i !== index)
      }
    }));
  };

  const updateAlternativeAddress = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      contactInfo: {
        ...prev.contactInfo,
        alternativeAddresses: prev.contactInfo.alternativeAddresses.map((addr, i) => 
          i === index ? { ...addr, [field]: value } : addr
        )
      }
    }));
  };

  const addTag = (tag) => {
    if (tag && !formData.tags.includes(tag)) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tag]
      }));
    }
  };

  const removeTag = (tagToRemove) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const validateForm = () => {
    const newErrors = {};

    // Validar información personal
    if (!formData.personalInfo.firstName.trim()) {
      newErrors['personalInfo.firstName'] = 'El nombre es requerido';
    }
    if (!formData.personalInfo.lastName.trim()) {
      newErrors['personalInfo.lastName'] = 'El apellido es requerido';
    }
    if (!formData.personalInfo.email.trim()) {
      newErrors['personalInfo.email'] = 'El email es requerido';
    } else if (!/\S+@\S+\.\S+/.test(formData.personalInfo.email)) {
      newErrors['personalInfo.email'] = 'El email no es válido';
    }
    if (!formData.personalInfo.phone.trim()) {
      newErrors['personalInfo.phone'] = 'El teléfono es requerido';
    }

    // Validar dirección principal
    if (!formData.contactInfo.primaryAddress.street.trim()) {
      newErrors['contactInfo.primaryAddress.street'] = 'La dirección es requerida';
    }
    if (!formData.contactInfo.primaryAddress.city.trim()) {
      newErrors['contactInfo.primaryAddress.city'] = 'La ciudad es requerida';
    }
    if (!formData.contactInfo.primaryAddress.state.trim()) {
      newErrors['contactInfo.primaryAddress.state'] = 'La provincia es requerida';
    }

    // Validar información empresarial si es empresa
    if (formData.businessInfo.isCompany) {
      if (!formData.businessInfo.companyName.trim()) {
        newErrors['businessInfo.companyName'] = 'El nombre de la empresa es requerido';
      }
      if (!formData.businessInfo.taxId.trim()) {
        newErrors['businessInfo.taxId'] = 'El RUC/NIT es requerido';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      if (isEditing) {
        await ClientService.updateClient(clientId, formData);
      } else {
        await ClientService.createClient(formData);
      }
      onSave();
    } catch (error) {
      console.error('Error saving client:', error);
      alert(`Error al guardar el cliente: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const getFieldError = (field) => {
    return errors[field] ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500';
  };

  const tabs = [
    { id: 'personal', label: 'Personal', icon: User },
    { id: 'contact', label: 'Contacto', icon: MapPin },
    { id: 'business', label: 'Empresa', icon: Building },
    { id: 'account', label: 'Cuenta', icon: CreditCard },
    { id: 'preferences', label: 'Preferencias', icon: Settings }
  ];

  const costaRicaProvinces = [
    'San José', 'Alajuela', 'Cartago', 'Heredia', 
    'Guanacaste', 'Puntarenas', 'Limón'
  ];

  return (
    <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-900">
          {isEditing ? 'Editar Cliente' : 'Crear Nuevo Cliente'}
        </h2>
      </div>

      {/* Tabs Navigation */}
      <div className="border-b border-gray-200">
        <nav className="flex space-x-8 px-6">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="h-4 w-4 mr-2" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      <form onSubmit={handleSubmit} className="p-6">
        {/* Personal Information */}
        {activeTab === 'personal' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nombre *
                </label>
                <input
                  type="text"
                  className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('personalInfo.firstName')}`}
                  value={formData.personalInfo.firstName}
                  onChange={(e) => handleInputChange('personalInfo', 'firstName', e.target.value)}
                  placeholder="Juan"
                />
                {errors['personalInfo.firstName'] && (
                  <p className="mt-1 text-sm text-red-600">{errors['personalInfo.firstName']}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Apellido *
                </label>
                <input
                  type="text"
                  className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('personalInfo.lastName')}`}
                  value={formData.personalInfo.lastName}
                  onChange={(e) => handleInputChange('personalInfo', 'lastName', e.target.value)}
                  placeholder="Pérez"
                />
                {errors['personalInfo.lastName'] && (
                  <p className="mt-1 text-sm text-red-600">{errors['personalInfo.lastName']}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="email"
                    className={`w-full pl-10 pr-3 py-2 border rounded-md focus:ring-2 ${getFieldError('personalInfo.email')}`}
                    value={formData.personalInfo.email}
                    onChange={(e) => handleInputChange('personalInfo', 'email', e.target.value)}
                    placeholder="juan@email.com"
                  />
                </div>
                {errors['personalInfo.email'] && (
                  <p className="mt-1 text-sm text-red-600">{errors['personalInfo.email']}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Teléfono *
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <input
                    type="tel"
                    className={`w-full pl-10 pr-3 py-2 border rounded-md focus:ring-2 ${getFieldError('personalInfo.phone')}`}
                    value={formData.personalInfo.phone}
                    onChange={(e) => handleInputChange('personalInfo', 'phone', e.target.value)}
                    placeholder="8888-8888"
                  />
                </div>
                {errors['personalInfo.phone'] && (
                  <p className="mt-1 text-sm text-red-600">{errors['personalInfo.phone']}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Fecha de Nacimiento
                </label>
                <input
                  type="date"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.personalInfo.dateOfBirth}
                  onChange={(e) => handleInputChange('personalInfo', 'dateOfBirth', e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo de Documento
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.personalInfo.documentType}
                  onChange={(e) => handleInputChange('personalInfo', 'documentType', e.target.value)}
                >
                  <option value="cedula">Cédula</option>
                  <option value="passport">Pasaporte</option>
                  <option value="other">Otro</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Número de Documento
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.personalInfo.documentNumber}
                  onChange={(e) => handleInputChange('personalInfo', 'documentNumber', e.target.value)}
                  placeholder="1-1234-5678"
                />
              </div>
            </div>
          </div>
        )}

        {/* Contact Information */}
        {activeTab === 'contact' && (
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Dirección Principal</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Dirección *
                  </label>
                  <input
                    type="text"
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('contactInfo.primaryAddress.street')}`}
                    value={formData.contactInfo.primaryAddress.street}
                    onChange={(e) => handleInputChange('contactInfo', 'primaryAddress', e.target.value, 'street')}
                    placeholder="Calle, avenida, número de casa"
                  />
                  {errors['contactInfo.primaryAddress.street'] && (
                    <p className="mt-1 text-sm text-red-600">{errors['contactInfo.primaryAddress.street']}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Ciudad *
                  </label>
                  <input
                    type="text"
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('contactInfo.primaryAddress.city')}`}
                    value={formData.contactInfo.primaryAddress.city}
                    onChange={(e) => handleInputChange('contactInfo', 'primaryAddress', e.target.value, 'city')}
                    placeholder="San José"
                  />
                  {errors['contactInfo.primaryAddress.city'] && (
                    <p className="mt-1 text-sm text-red-600">{errors['contactInfo.primaryAddress.city']}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Provincia *
                  </label>
                  <select
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('contactInfo.primaryAddress.state')}`}
                    value={formData.contactInfo.primaryAddress.state}
                    onChange={(e) => handleInputChange('contactInfo', 'primaryAddress', e.target.value, 'state')}
                  >
                    <option value="">Seleccionar provincia</option>
                    {costaRicaProvinces.map(province => (
                      <option key={province} value={province}>{province}</option>
                    ))}
                  </select>
                  {errors['contactInfo.primaryAddress.state'] && (
                    <p className="mt-1 text-sm text-red-600">{errors['contactInfo.primaryAddress.state']}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Código Postal
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.contactInfo.primaryAddress.zipCode}
                    onChange={(e) => handleInputChange('contactInfo', 'primaryAddress', e.target.value, 'zipCode')}
                    placeholder="10101"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    País
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.contactInfo.primaryAddress.country}
                    onChange={(e) => handleInputChange('contactInfo', 'primaryAddress', e.target.value, 'country')}
                  />
                </div>
              </div>
            </div>

            {/* Alternative Addresses */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-gray-900">Direcciones Alternativas</h3>
                <button
                  type="button"
                  onClick={addAlternativeAddress}
                  className="bg-blue-600 text-white px-3 py-1 rounded-md text-sm hover:bg-blue-700 flex items-center"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Agregar
                </button>
              </div>

              {formData.contactInfo.alternativeAddresses.map((address, index) => (
                <div key={index} className="border border-gray-200 rounded-md p-4 mb-4">
                  <div className="flex items-center justify-between mb-3">
                    <input
                      type="text"
                      placeholder="Etiqueta (ej: Casa, Oficina)"
                      className="text-sm font-medium bg-transparent border-b border-gray-300 focus:border-blue-500 outline-none"
                      value={address.label}
                      onChange={(e) => updateAlternativeAddress(index, 'label', e.target.value)}
                    />
                    <button
                      type="button"
                      onClick={() => removeAlternativeAddress(index)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div className="md:col-span-2">
                      <input
                        type="text"
                        placeholder="Dirección"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                        value={address.street}
                        onChange={(e) => updateAlternativeAddress(index, 'street', e.target.value)}
                      />
                    </div>
                    <div>
                      <input
                        type="text"
                        placeholder="Ciudad"
                        className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                        value={address.city}
                        onChange={(e) => updateAlternativeAddress(index, 'city', e.target.value)}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Emergency Contact */}
            <div>
              <h3 className="text-lg font-medium text-gray-900 mb-4">Contacto de Emergencia</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.contactInfo.emergencyContact.name}
                    onChange={(e) => handleInputChange('contactInfo', 'emergencyContact', e.target.value, 'name')}
                    placeholder="María Pérez"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Teléfono
                  </label>
                  <input
                    type="tel"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.contactInfo.emergencyContact.phone}
                    onChange={(e) => handleInputChange('contactInfo', 'emergencyContact', e.target.value, 'phone')}
                    placeholder="8888-8888"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Parentesco
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.contactInfo.emergencyContact.relationship}
                    onChange={(e) => handleInputChange('contactInfo', 'emergencyContact', e.target.value, 'relationship')}
                  >
                    <option value="">Seleccionar</option>
                    <option value="spouse">Cónyuge</option>
                    <option value="parent">Padre/Madre</option>
                    <option value="sibling">Hermano/a</option>
                    <option value="child">Hijo/a</option>
                    <option value="friend">Amigo/a</option>
                    <option value="other">Otro</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Business Information */}
        {activeTab === 'business' && (
          <div className="space-y-6">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="isCompany"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                checked={formData.businessInfo.isCompany}
                onChange={(e) => handleInputChange('businessInfo', 'isCompany', e.target.checked)}
              />
              <label htmlFor="isCompany" className="ml-2 text-sm text-gray-700">
                Este cliente representa una empresa
              </label>
            </div>

            {formData.businessInfo.isCompany && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nombre de la Empresa *
                  </label>
                  <input
                    type="text"
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('businessInfo.companyName')}`}
                    value={formData.businessInfo.companyName}
                    onChange={(e) => handleInputChange('businessInfo', 'companyName', e.target.value)}
                    placeholder="Empresa S.A."
                  />
                  {errors['businessInfo.companyName'] && (
                    <p className="mt-1 text-sm text-red-600">{errors['businessInfo.companyName']}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    RUC/NIT *
                  </label>
                  <input
                    type="text"
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('businessInfo.taxId')}`}
                    value={formData.businessInfo.taxId}
                    onChange={(e) => handleInputChange('businessInfo', 'taxId', e.target.value)}
                    placeholder="3-101-123456"
                  />
                  {errors['businessInfo.taxId'] && (
                    <p className="mt-1 text-sm text-red-600">{errors['businessInfo.taxId']}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Industria
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.businessInfo.industry}
                    onChange={(e) => handleInputChange('businessInfo', 'industry', e.target.value)}
                  >
                    <option value="">Seleccionar industria</option>
                    <option value="technology">Tecnología</option>
                    <option value="retail">Comercio</option>
                    <option value="manufacturing">Manufactura</option>
                    <option value="services">Servicios</option>
                    <option value="healthcare">Salud</option>
                    <option value="education">Educación</option>
                    <option value="finance">Finanzas</option>
                    <option value="other">Otro</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Número de Empleados
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.businessInfo.employeeCount}
                    onChange={(e) => handleInputChange('businessInfo', 'employeeCount', e.target.value)}
                  >
                    <option value="">Seleccionar</option>
                    <option value="1-10">1-10</option>
                    <option value="11-50">11-50</option>
                    <option value="51-200">51-200</option>
                    <option value="201-500">201-500</option>
                    <option value="500+">500+</option>
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Sitio Web
                  </label>
                  <input
                    type="url"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={formData.businessInfo.website}
                    onChange={(e) => handleInputChange('businessInfo', 'website', e.target.value)}
                    placeholder="https://www.empresa.com"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Account Information */}
        {activeTab === 'account' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tipo de Cliente
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.accountInfo.customerType}
                  onChange={(e) => handleInputChange('accountInfo', 'customerType', e.target.value)}
                >
                  <option value="individual">Individual</option>
                  <option value="business">Empresa</option>
                  <option value="premium">Premium</option>
                  <option value="vip">VIP</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Límite de Crédito ($)
                </label>
                <input
                  type="number"
                  min="0"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.accountInfo.creditLimit}
                  onChange={(e) => handleInputChange('accountInfo', 'creditLimit', parseFloat(e.target.value) || 0)}
                  placeholder="1000"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Términos de Pago
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.accountInfo.paymentTerms}
                  onChange={(e) => handleInputChange('accountInfo', 'paymentTerms', e.target.value)}
                >
                  <option value="immediate">Inmediato</option>
                  <option value="15_days">15 días</option>
                  <option value="30_days">30 días</option>
                  <option value="60_days">60 días</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Método de Pago Preferido
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.accountInfo.preferredPaymentMethod}
                  onChange={(e) => handleInputChange('accountInfo', 'preferredPaymentMethod', e.target.value)}
                >
                  <option value="cash">Efectivo</option>
                  <option value="card">Tarjeta</option>
                  <option value="transfer">Transferencia</option>
                  <option value="invoice">Factura</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Preferences */}
        {activeTab === 'preferences' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Método de Comunicación
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.preferences.communicationMethod}
                  onChange={(e) => handleInputChange('preferences', 'communicationMethod', e.target.value)}
                >
                  <option value="email">Email</option>
                  <option value="sms">SMS</option>
                  <option value="phone">Teléfono</option>
                  <option value="whatsapp">WhatsApp</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Idioma
                </label>
                <select
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  value={formData.preferences.language}
                  onChange={(e) => handleInputChange('preferences', 'language', e.target.value)}
                >
                  <option value="es">Español</option>
                  <option value="en">English</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="newsletter"
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                    checked={formData.preferences.newsletterSubscribed}
                    onChange={(e) => handleInputChange('preferences', 'newsletterSubscribed', e.target.checked)}
                  />
                  <label htmlFor="newsletter" className="ml-2 text-sm text-gray-700">
                    Suscribirse al boletín de noticias
                  </label>
                </div>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Instrucciones Especiales
                </label>
                <textarea
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                  rows="3"
                  value={formData.preferences.specialInstructions}
                  onChange={(e) => handleInputChange('preferences', 'specialInstructions', e.target.value)}
                  placeholder="Horarios específicos, direcciones especiales, etc."
                />
              </div>
            </div>

            {/* Tags */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Etiquetas
              </label>
              <div className="flex flex-wrap gap-2 mb-2">
                {formData.tags.map((tag, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="ml-1 text-blue-600 hover:text-blue-800"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </span>
                ))}
              </div>
              <input
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                placeholder="Agregar etiqueta (presiona Enter)"
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag(e.target.value.trim());
                    e.target.value = '';
                  }
                }}
              />
            </div>

            {/* Notes */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notas
              </label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                rows="4"
                value={formData.notes}
                onChange={(e) => handleInputChange(null, 'notes', e.target.value)}
                placeholder="Notas adicionales sobre el cliente..."
              />
            </div>
          </div>
        )}

        {/* Form Actions */}
        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200 mt-8">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 flex items-center"
          >
            <X className="h-4 w-4 mr-2" />
            Cancelar
          </button>
          
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            {isEditing ? 'Actualizar Cliente' : 'Crear Cliente'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ClientForm;