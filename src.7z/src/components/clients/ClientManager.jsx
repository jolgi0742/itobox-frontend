// components/clients/ClientManager.jsx
import React, { useState } from 'react';
import ClientList from './ClientList';
import ClientForm from './ClientForm';
import ClientDetails from './ClientDetails';

const ClientManager = ({ onNavigateToPackages }) => {
  const [currentView, setCurrentView] = useState('list'); // 'list', 'create', 'edit', 'details'
  const [selectedClientId, setSelectedClientId] = useState(null);

  const handleCreateClient = () => {
    setCurrentView('create');
    setSelectedClientId(null);
  };

  const handleEditClient = (clientId) => {
    setCurrentView('edit');
    setSelectedClientId(clientId);
  };

  const handleViewClient = (clientId) => {
    setCurrentView('details');
    setSelectedClientId(clientId);
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedClientId(null);
  };

  const handleSaveSuccess = () => {
    setCurrentView('list');
    setSelectedClientId(null);
  };

  const handleCreatePackageForClient = (clientId) => {
    // Navegar a crear paquete con cliente preseleccionado
    if (onNavigateToPackages) {
      onNavigateToPackages('create', { preselectedClientId: clientId });
    }
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'create':
        return (
          <ClientForm
            onSave={handleSaveSuccess}
            onCancel={handleBackToList}
          />
        );
      
      case 'edit':
        return (
          <ClientForm
            clientId={selectedClientId}
            onSave={handleSaveSuccess}
            onCancel={handleBackToList}
          />
        );
      
      case 'details':
        return (
          <ClientDetails
            clientId={selectedClientId}
            onEdit={handleEditClient}
            onBack={handleBackToList}
            onCreatePackage={handleCreatePackageForClient}
          />
        );
      
      default:
        return (
          <ClientList
            onCreateClient={handleCreateClient}
            onEditClient={handleEditClient}
            onViewClient={handleViewClient}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                {currentView === 'create' && 'Crear Nuevo Cliente'}
                {currentView === 'edit' && 'Editar Cliente'}
                {currentView === 'details' && 'Perfil del Cliente'}
                {currentView === 'list' && 'Gestión de Clientes'}
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                {currentView === 'list' && 'Administra la base de datos de clientes de ITOBOX Courier'}
                {(currentView === 'create' || currentView === 'edit') && 'Completa la información del cliente'}
                {currentView === 'details' && 'Información completa y historial del cliente'}
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        {renderCurrentView()}
      </div>
    </div>
  );
};

export default ClientManager;