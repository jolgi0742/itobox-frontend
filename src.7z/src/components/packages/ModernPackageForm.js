// components/packages/ModernPackageForm.jsx - Formulario ultra moderno
import React, { useState, useEffect } from 'react';
import {
  Package,
  MapPin,
  User,
  Phone,
  Mail,
  DollarSign,
  Calendar,
  Truck,
  Save,
  X,
  CheckCircle,
  AlertCircle,
  ArrowLeft
} from 'lucide-react';

const ModernPackageForm = ({ packageData, onSave, onCancel, isEditing = false }) => {
  const [formData, setFormData] = useState({
    recipient: {
      name: '',
      phone: '',
      email: '',
      address: {
        street: '',
        city: '',
        state: '',
        zipCode: '',
        country: 'Costa Rica'
      }
    },
    sender: {
      name: '',
      phone: '',
      email: '',
      address: {
        street: '',
        city: '',
        state: '',
        zipCode: '',
        country: 'Costa Rica'
      }
    },
    package: {
      description: '',
      weight: '',
      dimensions: {
        length: '',
        width: '',
        height: ''
      },
      value: '',
      category: 'standard'
    },
    service: {
      type: 'standard',
      priority: 'normal',
      insurance: false,
      signatureRequired: false
    },
    pricing: {
      basePrice: 0,
      insurancePrice: 0,
      totalPrice: 0
    }
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [errors, setErrors] = useState({});
  const [isCalculating, setIsCalculating] = useState(false);

  useEffect(() => {
    if (packageData && isEditing) {
      setFormData(packageData);
    }
  }, [packageData, isEditing]);

  const steps = [
    { id: 1, title: 'Destinatario', icon: User },
    { id: 2, title: 'Remitente', icon: MapPin },
    { id: 3, title: 'Paquete', icon: Package },
    { id: 4, title: 'Servicio', icon: Truck },
    { id: 5, title: 'Confirmación', icon: CheckCircle }
  ];

  const serviceTypes = [
    { id: 'standard', name: 'Estándar', time: '3-5 días', price: 15 },
    { id: 'express', name: 'Express', time: '1-2 días', price: 25 },
    { id: 'overnight', name: 'Nocturno', time: '24 horas', price: 45 }
  ];

  const calculatePrice = () => {
    setIsCalculating(true);
    setTimeout(() => {
      const basePrice = serviceTypes.find(s => s.id === formData.service.type)?.price || 15;
      const weight = parseFloat(formData.package.weight) || 1;
      const insurance = formData.service.insurance ? parseFloat(formData.package.value) * 0.02 : 0;
      
      const calculatedPrice = basePrice + (weight * 2) + insurance;
      
      setFormData(prev => ({
        ...prev,
        pricing: {
          basePrice,
          insurancePrice: insurance,
          totalPrice: calculatedPrice
        }
      }));
      setIsCalculating(false);
    }, 1000);
  };

  useEffect(() => {
    if (currentStep === 4) {
      calculatePrice();
    }
  }, [formData.service, formData.package.weight, formData.package.value, currentStep]);

  const handleInputChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handleAddressChange = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        address: {
          ...prev[section].address,
          [field]: value
        }
      }
    }));
  };

  const validateStep = (step) => {
    const newErrors = {};
    
    switch (step) {
      case 1:
        if (!formData.recipient.name) newErrors['recipient.name'] = 'Nombre requerido';
        if (!formData.recipient.phone) newErrors['recipient.phone'] = 'Teléfono requerido';
        if (!formData.recipient.address.street) newErrors['recipient.address.street'] = 'Dirección requerida';
        if (!formData.recipient.address.city) newErrors['recipient.address.city'] = 'Ciudad requerida';
        break;
      case 2:
        if (!formData.sender.name) newErrors['sender.name'] = 'Nombre requerido';
        if (!formData.sender.phone) newErrors['sender.phone'] = 'Teléfono requerido';
        break;
      case 3:
        if (!formData.package.description) newErrors['package.description'] = 'Descripción requerida';
        if (!formData.package.weight) newErrors['package.weight'] = 'Peso requerido';
        break;
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 5));
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const handleSubmit = () => {
    if (validateStep(currentStep)) {
      onSave(formData);
    }
  };

  const styles = {
    container: {
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
      padding: '40px 20px'
    },
    wrapper: {
      maxWidth: '1200px',
      margin: '0 auto'
    },
    header: {
      marginBottom: '40px'
    },
    backButton: {
      display: 'flex',
      alignItems: 'center',
      background: 'white',
      border: 'none',
      padding: '12px 20px',
      borderRadius: '12px',
      cursor: 'pointer',
      marginBottom: '24px',
      boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
      transition: 'all 0.3s ease'
    },
    title: {
      fontSize: '2.5rem',
      fontWeight: '800',
      color: '#1e293b',
      marginBottom: '8px'
    },
    subtitle: {
      color: '#64748b',
      fontSize: '1.1rem'
    },
    stepperContainer: {
      background: 'white',
      borderRadius: '20px',
      padding: '32px',
      boxShadow: '0 20px 40px -8px rgba(0, 0, 0, 0.08)',
      marginBottom: '32px'
    },
    stepper: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: '32px'
    },
    step: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      position: 'relative',
      flex: 1
    },
    stepIcon: {
      width: '60px',
      height: '60px',
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '12px',
      transition: 'all 0.3s ease'
    },
    stepTitle: {
      fontSize: '0.875rem',
      fontWeight: '600',
      textAlign: 'center'
    },
    stepLine: {
      position: 'absolute',
      top: '30px',
      left: '50%',
      width: '100%',
      height: '2px',
      backgroundColor: '#e2e8f0',
      zIndex: -1
    },
    formCard: {
      background: 'white',
      borderRadius: '20px',
      padding: '40px',
      boxShadow: '0 20px 40px -8px rgba(0, 0, 0, 0.08)',
      marginBottom: '32px'
    },
    formGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
      gap: '24px'
    },
    inputGroup: {
      marginBottom: '24px'
    },
    label: {
      display: 'block',
      fontSize: '0.875rem',
      fontWeight: '700',
      color: '#374151',
      marginBottom: '8px',
      textTransform: 'uppercase',
      letterSpacing: '0.05em'
    },
    input: {
      width: '100%',
      padding: '16px 20px',
      borderRadius: '12px',
      border: '2px solid #e2e8f0',
      fontSize: '1rem',
      transition: 'all 0.3s ease',
      boxSizing: 'border-box'
    },
    inputFocus: {
      borderColor: '#3b82f6',
      boxShadow: '0 0 0 3px rgba(59, 130, 246, 0.1)'
    },
    inputError: {
      borderColor: '#ef4444',
      boxShadow: '0 0 0 3px rgba(239, 68, 68, 0.1)'
    },
    select: {
      width: '100%',
      padding: '16px 20px',
      borderRadius: '12px',
      border: '2px solid #e2e8f0',
      fontSize: '1rem',
      backgroundColor: 'white',
      cursor: 'pointer',
      transition: 'all 0.3s ease'
    },
    serviceCard: {
      border: '2px solid #e2e8f0',
      borderRadius: '16px',
      padding: '24px',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      marginBottom: '16px'
    },
    serviceCardActive: {
      borderColor: '#3b82f6',
      backgroundColor: '#f0f9ff',
      boxShadow: '0 8px 24px rgba(59, 130, 246, 0.15)'
    },
    checkbox: {
      display: 'flex',
      alignItems: 'center',
      padding: '16px',
      backgroundColor: '#f8fafc',
      borderRadius: '12px',
      marginBottom: '12px',
      cursor: 'pointer'
    },
    buttonGroup: {
      display: 'flex',
      gap: '16px',
      justifyContent: 'space-between',
      marginTop: '32px'
    },
    button: {
      padding: '16px 32px',
      borderRadius: '12px',
      border: 'none',
      fontSize: '1rem',
      fontWeight: '600',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      display: 'flex',
      alignItems: 'center',
      gap: '8px'
    },
    primaryButton: {
      background: 'linear-gradient(135deg, #3b82f6 0%, #1e40af 100%)',
      color: 'white',
      boxShadow: '0 8px 24px rgba(59, 130, 246, 0.25)'
    },
    secondaryButton: {
      backgroundColor: '#f1f5f9',
      color: '#64748b',
      border: '2px solid #e2e8f0'
    },
    priceCard: {
      background: 'linear-gradient(135deg, #10b981 0%, #047857 100%)',
      color: 'white',
      borderRadius: '20px',
      padding: '32px',
      textAlign: 'center'
    },
    error: {
      color: '#ef4444',
      fontSize: '0.875rem',
      marginTop: '4px',
      display: 'flex',
      alignItems: 'center',
      gap: '4px'
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div style={styles.formCard}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b' }}>
              Información del Destinatario
            </h3>
            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Nombre Completo *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['recipient.name'] ? styles.inputError : {})
                  }}
                  value={formData.recipient.name}
                  onChange={(e) => handleInputChange('recipient', 'name', e.target.value)}
                  placeholder="Nombre del destinatario"
                />
                {errors['recipient.name'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['recipient.name']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Teléfono *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['recipient.phone'] ? styles.inputError : {})
                  }}
                  value={formData.recipient.phone}
                  onChange={(e) => handleInputChange('recipient', 'phone', e.target.value)}
                  placeholder="+506 8888-8888"
                />
                {errors['recipient.phone'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['recipient.phone']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Email</label>
                <input
                  style={styles.input}
                  type="email"
                  value={formData.recipient.email}
                  onChange={(e) => handleInputChange('recipient', 'email', e.target.value)}
                  placeholder="email@ejemplo.com"
                />
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Dirección *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['recipient.address.street'] ? styles.inputError : {})
                  }}
                  value={formData.recipient.address.street}
                  onChange={(e) => handleAddressChange('recipient', 'street', e.target.value)}
                  placeholder="Calle y número"
                />
                {errors['recipient.address.street'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['recipient.address.street']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Ciudad *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['recipient.address.city'] ? styles.inputError : {})
                  }}
                  value={formData.recipient.address.city}
                  onChange={(e) => handleAddressChange('recipient', 'city', e.target.value)}
                  placeholder="Ciudad"
                />
                {errors['recipient.address.city'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['recipient.address.city']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Código Postal</label>
                <input
                  style={styles.input}
                  value={formData.recipient.address.zipCode}
                  onChange={(e) => handleAddressChange('recipient', 'zipCode', e.target.value)}
                  placeholder="10101"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div style={styles.formCard}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b' }}>
              Información del Remitente
            </h3>
            <div style={styles.formGrid}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Nombre Completo *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['sender.name'] ? styles.inputError : {})
                  }}
                  value={formData.sender.name}
                  onChange={(e) => handleInputChange('sender', 'name', e.target.value)}
                  placeholder="Tu nombre"
                />
                {errors['sender.name'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['sender.name']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Teléfono *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['sender.phone'] ? styles.inputError : {})
                  }}
                  value={formData.sender.phone}
                  onChange={(e) => handleInputChange('sender', 'phone', e.target.value)}
                  placeholder="+506 8888-8888"
                />
                {errors['sender.phone'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['sender.phone']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Email</label>
                <input
                  style={styles.input}
                  type="email"
                  value={formData.sender.email}
                  onChange={(e) => handleInputChange('sender', 'email', e.target.value)}
                  placeholder="tu@email.com"
                />
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div style={styles.formCard}>
            <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b' }}>
              Detalles del Paquete
            </h3>
            <div style={styles.formGrid}>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={styles.label}>Descripción del Contenido *</label>
                <textarea
                  style={{
                    ...styles.input,
                    height: '120px',
                    resize: 'vertical',
                    ...(errors['package.description'] ? styles.inputError : {})
                  }}
                  value={formData.package.description}
                  onChange={(e) => handleInputChange('package', 'description', e.target.value)}
                  placeholder="Describe el contenido del paquete..."
                />
                {errors['package.description'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['package.description']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Peso (kg) *</label>
                <input
                  style={{
                    ...styles.input,
                    ...(errors['package.weight'] ? styles.inputError : {})
                  }}
                  type="number"
                  step="0.1"
                  value={formData.package.weight}
                  onChange={(e) => handleInputChange('package', 'weight', e.target.value)}
                  placeholder="1.5"
                />
                {errors['package.weight'] && (
                  <div style={styles.error}>
                    <AlertCircle size={16} />
                    {errors['package.weight']}
                  </div>
                )}
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Valor Declarado (USD)</label>
                <input
                  style={styles.input}
                  type="number"
                  value={formData.package.value}
                  onChange={(e) => handleInputChange('package', 'value', e.target.value)}
                  placeholder="100.00"
                />
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Categoría</label>
                <select
                  style={styles.select}
                  value={formData.package.category}
                  onChange={(e) => handleInputChange('package', 'category', e.target.value)}
                >
                  <option value="standard">Estándar</option>
                  <option value="fragile">Frágil</option>
                  <option value="electronics">Electrónicos</option>
                  <option value="documents">Documentos</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div>
            <div style={styles.formCard}>
              <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '24px', color: '#1e293b' }}>
                Tipo de Servicio
              </h3>
              
              {serviceTypes.map((service) => (
                <div
                  key={service.id}
                  style={{
                    ...styles.serviceCard,
                    ...(formData.service.type === service.id ? styles.serviceCardActive : {})
                  }}
                  onClick={() => handleInputChange('service', 'type', service.id)}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div>
                      <h4 style={{ fontSize: '1.25rem', fontWeight: '600', marginBottom: '4px' }}>
                        {service.name}
                      </h4>
                      <p style={{ color: '#64748b', marginBottom: '0' }}>
                        Tiempo de entrega: {service.time}
                      </p>
                    </div>
                    <div style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1e293b' }}>
                      ${service.price}
                    </div>
                  </div>
                </div>
              ))}

              <h4 style={{ fontSize: '1.25rem', fontWeight: '600', marginTop: '32px', marginBottom: '16px' }}>
                Servicios Adicionales
              </h4>

              <div
                style={styles.checkbox}
                onClick={() => handleInputChange('service', 'insurance', !formData.service.insurance)}
              >
                <input
                  type="checkbox"
                  checked={formData.service.insurance}
                  onChange={() => {}}
                  style={{ marginRight: '12px' }}
                />
                <span style={{ fontWeight: '600' }}>Seguro (2% del valor declarado)</span>
              </div>

              <div
                style={styles.checkbox}
                onClick={() => handleInputChange('service', 'signatureRequired', !formData.service.signatureRequired)}
              >
                <input
                  type="checkbox"
                  checked={formData.service.signatureRequired}
                  onChange={() => {}}
                  style={{ marginRight: '12px' }}
                />
                <span style={{ fontWeight: '600' }}>Firma requerida</span>
              </div>
            </div>

            <div style={styles.priceCard}>
              {isCalculating ? (
                <div>
                  <div style={{ 
                    width: '40px', 
                    height: '40px', 
                    border: '3px solid rgba(255,255,255,0.3)',
                    borderTop: '3px solid white',
                    borderRadius: '50%',
                    animation: 'spin 1s linear infinite',
                    margin: '0 auto 16px'
                  }}></div>
                  <p>Calculando precio...</p>
                </div>
              ) : (
                <div>
                  <h3 style={{ fontSize: '1.5rem', fontWeight: '700', marginBottom: '16px' }}>
                    Resumen de Costos
                  </h3>
                  <div style={{ marginBottom: '16px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                      <span>Envío base:</span>
                      <span>${formData.pricing.basePrice}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                      <span>Por peso:</span>
                      <span>${((parseFloat(formData.package.weight) || 1) * 2).toFixed(2)}</span>
                    </div>
                    {formData.service.insurance && (
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                        <span>Seguro:</span>
                        <span>${formData.pricing.insurancePrice.toFixed(2)}</span>
                      </div>
                    )}
                  </div>
                  <div style={{ borderTop: '1px solid rgba(255,255,255,0.3)', paddingTop: '16px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '1.5rem', fontWeight: '700' }}>
                      <span>Total:</span>
                      <span>${formData.pricing.totalPrice.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        );

      case 5:
        return (
          <div style={styles.formCard}>
            <div style={{ textAlign: 'center', marginBottom: '32px' }}>
              <CheckCircle size={64} color="#10b981" style={{ marginBottom: '16px' }} />
              <h3 style={{ fontSize: '1.5rem', fontWeight: '700', color: '#1e293b' }}>
                Confirmar Envío
              </h3>
              <p style={{ color: '#64748b' }}>
                Revisa la información antes de crear el paquete
              </p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '24px' }}>
              <div>
                <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Destinatario</h4>
                <p>{formData.recipient.name}</p>
                <p>{formData.recipient.phone}</p>
                <p>{formData.recipient.address.street}, {formData.recipient.address.city}</p>
              </div>

              <div>
                <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Paquete</h4>
                <p>{formData.package.description}</p>
                <p>Peso: {formData.package.weight} kg</p>
                <p>Valor: ${formData.package.value || '0'}</p>
              </div>

              <div>
                <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Servicio</h4>
                <p>{serviceTypes.find(s => s.id === formData.service.type)?.name}</p>
                {formData.service.insurance && <p>✓ Con seguro</p>}
                {formData.service.signatureRequired && <p>✓ Firma requerida</p>}
              </div>

              <div>
                <h4 style={{ fontWeight: '600', marginBottom: '12px' }}>Total</h4>
                <p style={{ fontSize: '1.5rem', fontWeight: '700', color: '#10b981' }}>
                  ${formData.pricing.totalPrice.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div style={styles.container}>
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
      
      <div style={styles.wrapper}>
        <div style={styles.header}>
          <button
            style={styles.backButton}
            onClick={onCancel}
            onMouseEnter={(e) => {
              e.target.style.transform = 'translateY(-2px)';
              e.target.style.boxShadow = '0 8px 24px rgba(0,0,0,0.15)';
            }}
            onMouseLeave={(e) => {
              e.target.style.transform = 'translateY(0)';
              e.target.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
            }}
          >
            <ArrowLeft size={20} style={{ marginRight: '8px' }} />
            Regresar
          </button>
          
          <h1 style={styles.title}>
            {isEditing ? 'Editar Paquete' : 'Crear Nuevo Paquete'}
          </h1>
          <p style={styles.subtitle}>
            Completa la información para {isEditing ? 'actualizar' : 'crear'} el paquete
          </p>
        </div>

        <div style={styles.stepperContainer}>
          <div style={styles.stepper}>
            {steps.map((step, index) => {
              const isActive = step.id === currentStep;
              const isCompleted = step.id < currentStep;
              const IconComponent = step.icon;
              
              return (
                <div key={step.id} style={styles.step}>
                  {index < steps.length - 1 && (
                    <div style={{
                      ...styles.stepLine,
                      backgroundColor: isCompleted ? '#10b981' : '#e2e8f0'
                    }}></div>
                  )}
                  
                  <div style={{
                    ...styles.stepIcon,
                    backgroundColor: isCompleted ? '#10b981' : isActive ? '#3b82f6' : '#f1f5f9',
                    color: isCompleted || isActive ? 'white' : '#64748b',
                    transform: isActive ? 'scale(1.1)' : 'scale(1)',
                    boxShadow: isActive ? '0 8px 24px rgba(59, 130, 246, 0.25)' : 'none'
                  }}>
                    {isCompleted ? <CheckCircle size={24} /> : <IconComponent size={24} />}
                  </div>
                  
                  <span style={{
                    ...styles.stepTitle,
                    color: isCompleted || isActive ? '#1e293b' : '#64748b'
                  }}>
                    {step.title}
                  </span>
                </div>
              );
            })}
          </div>

          {renderStepContent()}

          <div style={styles.buttonGroup}>
            <button
              style={{
                ...styles.button,
                ...styles.secondaryButton,
                opacity: currentStep === 1 ? 0.5 : 1,
                cursor: currentStep === 1 ? 'not-allowed' : 'pointer'
              }}
              onClick={prevStep}
              disabled={currentStep === 1}
            >
              <ArrowLeft size={20} />
              Anterior
            </button>

            {currentStep < 5 ? (
              <button
                style={{...styles.button, ...styles.primaryButton}}
                onClick={nextStep}
              >
                Siguiente
                <ArrowLeft size={20} style={{ transform: 'rotate(180deg)' }} />
              </button>
            ) : (
              <button
                style={{...styles.button, ...styles.primaryButton}}
                onClick={handleSubmit}
              >
                <Save size={20} />
                {isEditing ? 'Actualizar Paquete' : 'Crear Paquete'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ModernPackageForm;