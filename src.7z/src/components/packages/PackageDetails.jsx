// components/packages/PackageDetails.jsx
import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  Edit, 
  MapPin, 
  Clock, 
  User, 
  Package as PackageIcon,
  DollarSign,
  Phone,
  Mail,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Truck,
  Home,
  RotateCcw,
  Navigation,
  Save
} from 'lucide-react';
import PackageService from '../../services/PackageService';

const PackageDetails = ({ packageId, onEdit, onBack }) => {
  const [pkg, setPkg] = useState(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [showStatusUpdate, setShowStatusUpdate] = useState(false);
  const [newStatus, setNewStatus] = useState('');
  const [newLocation, setNewLocation] = useState('');
  const [statusNote, setStatusNote] = useState('');

  useEffect(() => {
    loadPackage();
  }, [packageId]);

  const loadPackage = () => {
    setLoading(true);
    try {
      const packageData = PackageService.getPackageById(packageId);
      if (packageData) {
        setPkg(packageData);
      }
    } catch (error) {
      console.error('Error loading package:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async () => {
    if (!newStatus) return;

    setUpdating(true);
    try {
      await PackageService.updatePackageStatus(
        packageId, 
        newStatus, 
        newLocation || pkg.location.current, 
        statusNote
      );
      
      loadPackage(); // Recargar datos
      setShowStatusUpdate(false);
      setNewStatus('');
      setNewLocation('');
      setStatusNote('');
    } catch (error) {
      console.error('Error updating status:', error);
      alert('Error al actualizar el estado del paquete');
    } finally {
      setUpdating(false);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    return new Date(dateString).toLocaleString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusIcon = (status) => {
    const icons = {
      created: <PackageIcon className="h-5 w-5" />,
      collected: <CheckCircle className="h-5 w-5" />,
      in_transit: <Truck className="h-5 w-5" />,
      out_for_delivery: <Navigation className="h-5 w-5" />,
      delivered: <Home className="h-5 w-5" />,
      returned: <RotateCcw className="h-5 w-5" />
    };
    return icons[status] || <PackageIcon className="h-5 w-5" />;
  };

  const getStatusProgress = (status) => {
    const progress = {
      created: 1,
      collected: 2,
      in_transit: 3,
      out_for_delivery: 4,
      delivered: 5,
      returned: 1
    };
    return progress[status] || 1;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!pkg) {
    return (
      <div className="text-center py-12">
        <PackageIcon className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Paquete no encontrado</h3>
        <div className="mt-6">
          <button
            onClick={onBack}
            className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver a la lista
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={onBack}
              className="p-2 text-gray-400 hover:text-gray-600"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{pkg.trackingCode}</h1>
              <p className="text-sm text-gray-500">{pkg.packageDetails.description}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${PackageService.getStatusColor(pkg.status)}`}>
              {getStatusIcon(pkg.status)}
              <span className="ml-2">{PackageService.getStatusLabel(pkg.status)}</span>
            </span>
            
            <button
              onClick={() => onEdit(pkg.id)}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <Edit className="h-4 w-4 mr-2" />
              Editar
            </button>
            
            <button
              onClick={() => setShowStatusUpdate(true)}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700"
            >
              <Clock className="h-4 w-4 mr-2" />
              Actualizar Estado
            </button>
          </div>
        </div>
      </div>

      {/* Progress Tracker */}
      <div className="bg-white shadow rounded-lg p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Estado del Envío</h2>
        
        <div className="relative">
          <div className="flex items-center">
            {['created', 'collected', 'in_transit', 'out_for_delivery', 'delivered'].map((status, index) => {
              const isActive = getStatusProgress(pkg.status) > index;
              const isCurrent = getStatusProgress(pkg.status) === index + 1;
              
              return (
                <React.Fragment key={status}>
                  <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                    isActive 
                      ? 'bg-blue-600 border-blue-600 text-white' 
                      : isCurrent
                      ? 'bg-blue-100 border-blue-600 text-blue-600'
                      : 'bg-gray-100 border-gray-300 text-gray-400'
                  }`}>
                    {getStatusIcon(status)}
                  </div>
                  
                  {index < 4 && (
                    <div className={`flex-1 h-0.5 mx-4 ${
                      isActive ? 'bg-blue-600' : 'bg-gray-300'
                    }`} />
                  )}
                </React.Fragment>
              );
            })}
          </div>
          
          <div className="flex justify-between mt-2 text-xs text-gray-600">
            <span>Creado</span>
            <span>Recolectado</span>
            <span>En Tránsito</span>
            <span>En Reparto</span>
            <span>Entregado</span>
          </div>
        </div>

        <div className="mt-4 p-3 bg-gray-50 rounded-md flex items-center">
          <MapPin className="h-4 w-4 text-gray-500 mr-2" />
          <span className="text-sm text-gray-700">
            Ubicación actual: <strong>{pkg.location.current}</strong>
          </span>
        </div>
      </div>

      {/* Información Principal */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Remitente */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <User className="h-5 w-5 mr-2 text-blue-600" />
            Remitente
          </h3>
          
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-500">Nombre</p>
              <p className="text-sm text-gray-900">{pkg.sender.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Teléfono</p>
              <p className="text-sm text-gray-900 flex items-center">
                <Phone className="h-4 w-4 mr-1" />
                {pkg.sender.phone}
              </p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Dirección</p>
              <p className="text-sm text-gray-900">{pkg.sender.address}</p>
            </div>
            {pkg.sender.email && (
              <div>
                <p className="text-sm font-medium text-gray-500">Email</p>
                <p className="text-sm text-gray-900 flex items-center">
                  <Mail className="h-4 w-4 mr-1" />
                  {pkg.sender.email}
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Destinatario */}
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-green-600" />
            Destinatario
          </h3>
          
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-500">Nombre</p>
              <p className="text-sm text-gray-900">{pkg.recipient.name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Teléfono</p>
              <p className="text-sm text-gray-900 flex items-center">
                <Phone className="h-4 w-4 mr-1" />
                {pkg.recipient.phone}
              </p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Dirección</p>
              <p className="text-sm text-gray-900">{pkg.recipient.address}</p>
            </div>
            {pkg.recipient.email && (
              <div>
                <p className="text-sm font-medium text-gray-500">Email</p>
                <p className="text-sm text-gray-900 flex items-center">
                  <Mail className="h-4 w-4 mr-1" />
                  {pkg.recipient.email}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Detalles del Paquete */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
          <PackageIcon className="h-5 w-5 mr-2 text-orange-600" />
          Detalles del Paquete
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-500">Descripción</p>
              <p className="text-sm text-gray-900">{pkg.packageDetails.description}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Peso</p>
              <p className="text-sm text-gray-900">{pkg.packageDetails.weight} kg</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Dimensiones</p>
              <p className="text-sm text-gray-900">
                {pkg.packageDetails.dimensions.length} x {pkg.packageDetails.dimensions.width} x {pkg.packageDetails.dimensions.height} cm
              </p>
            </div>
          </div>
          
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-500">Prioridad</p>
              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${PackageService.getPriorityColor(pkg.packageDetails.priority)}`}>
                {PackageService.getPriorityLabel(pkg.packageDetails.priority)}
              </span>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Valor Declarado</p>
              <p className="text-sm text-gray-900 flex items-center">
                <DollarSign className="h-4 w-4 mr-1" />
                {pkg.packageDetails.value || 0}
              </p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Costo de Envío</p>
              <p className="text-sm text-gray-900 flex items-center">
                <DollarSign className="h-4 w-4 mr-1" />
                {pkg.cost}
              </p>
            </div>
          </div>
          
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-gray-500">Fecha de Creación</p>
              <p className="text-sm text-gray-900 flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                {formatDate(pkg.dates.created)}
              </p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Entrega Estimada</p>
              <p className="text-sm text-gray-900 flex items-center">
                <Calendar className="h-4 w-4 mr-1" />
                {formatDate(pkg.dates.estimated_delivery)}
              </p>
            </div>
            {pkg.packageDetails.fragile && (
              <div className="flex items-center text-yellow-600">
                <AlertTriangle className="h-4 w-4 mr-1" />
                <span className="text-sm font-medium">Frágil</span>
              </div>
            )}
          </div>
        </div>

        {pkg.notes && (
          <div className="mt-4 p-3 bg-gray-50 rounded-md">
            <p className="text-sm font-medium text-gray-500 mb-1">Notas</p>
            <p className="text-sm text-gray-900">{pkg.notes}</p>
          </div>
        )}
      </div>

      {/* Historial de Tracking */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
          <Clock className="h-5 w-5 mr-2 text-purple-600" />
          Historial de Tracking
        </h3>
        
        <div className="space-y-4">
          {pkg.location.history.map((entry, index) => (
            <div key={index} className="flex items-start space-x-3">
              <div className="flex-shrink-0">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <MapPin className="h-4 w-4 text-blue-600" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900">{entry.location}</p>
                <p className="text-sm text-gray-500">{formatDate(entry.timestamp)}</p>
                {entry.note && (
                  <p className="text-sm text-gray-600 mt-1">{entry.note}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal para actualizar estado */}
      {showStatusUpdate && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Actualizar Estado del Paquete
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nuevo Estado
                  </label>
                  <select
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value)}
                  >
                    <option value="">Seleccionar estado</option>
                    <option value="created">Creado</option>
                    <option value="collected">Recolectado</option>
                    <option value="in_transit">En Tránsito</option>
                    <option value="out_for_delivery">En Reparto</option>
                    <option value="delivered">Entregado</option>
                    <option value="returned">Devuelto</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nueva Ubicación (Opcional)
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    placeholder="Deja vacío para mantener ubicación actual"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nota (Opcional)
                  </label>
                  <textarea
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500"
                    rows="2"
                    value={statusNote}
                    onChange={(e) => setStatusNote(e.target.value)}
                    placeholder="Información adicional sobre el cambio"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowStatusUpdate(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleStatusUpdate}
                  disabled={!newStatus || updating}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center"
                >
                  {updating ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <Save className="h-4 w-4 mr-2" />
                  )}
                  Actualizar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PackageDetails;