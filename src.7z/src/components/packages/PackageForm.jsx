// components/packages/PackageForm.jsx
import React, { useState, useEffect } from 'react';
import { 
  Save, 
  X, 
  User, 
  MapPin, 
  Package as PackageIcon, 
  DollarSign,
  Calendar,
  AlertTriangle,
  Phone,
  Mail,
  Users,
  Plus
} from 'lucide-react';
import PackageService from '../../services/PackageService';
import ClientService from '../../services/ClientService';

const PackageForm = ({ packageId = null, preselectedClientId = null, onSave, onCancel }) => {
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [clients, setClients] = useState([]);
  const [selectedClient, setSelectedClient] = useState(null);
  const [useExistingClient, setUseExistingClient] = useState(false);
  const [formData, setFormData] = useState({
    clientId: preselectedClientId || null,
    sender: {
      name: '',
      phone: '',
      address: '',
      email: ''
    },
    recipient: {
      name: '',
      phone: '',
      address: '',
      email: ''
    },
    packageDetails: {
      description: '',
      weight: '',
      dimensions: {
        length: '',
        width: '',
        height: ''
      },
      value: '',
      fragile: false,
      priority: 'normal'
    },
    cost: '',
    estimated_delivery: '',
    notes: ''
  });

  const isEditing = Boolean(packageId);

  useEffect(() => {
    loadClients();
    if (isEditing) {
      loadPackage();
    } else {
      // Auto-calcular fecha estimada para nuevos paquetes
      calculateEstimatedDelivery('normal');
      
      // Si hay cliente preseleccionado, cargarlo
      if (preselectedClientId) {
        const client = ClientService.getClientById(preselectedClientId);
        if (client) {
          setSelectedClient(client);
          setUseExistingClient(true);
          prefillFromClient(client);
        }
      }
    }
  }, [packageId, preselectedClientId]);

  const loadClients = () => {
    try {
      const allClients = ClientService.getClientsForSelect();
      setClients(allClients);
    } catch (error) {
      console.error('Error loading clients:', error);
    }
  };

  const loadPackage = () => {
    try {
      const pkg = PackageService.getPackageById(packageId);
      if (pkg) {
        setFormData({
          clientId: pkg.clientId || null,
          sender: pkg.sender,
          recipient: pkg.recipient,
          packageDetails: pkg.packageDetails,
          cost: pkg.cost || '',
          estimated_delivery: pkg.dates.estimated_delivery ? 
            new Date(pkg.dates.estimated_delivery).toISOString().split('T')[0] : '',
          notes: pkg.notes || ''
        });

        // Si tiene cliente asociado, cargarlo
        if (pkg.clientId) {
          const client = ClientService.getClientById(pkg.clientId);
          if (client) {
            setSelectedClient(client);
            setUseExistingClient(true);
          }
        }
      }
    } catch (error) {
      console.error('Error loading package:', error);
    }
  };

  const handleClientChange = (clientId) => {
    setFormData(prev => ({ ...prev, clientId }));
    
    if (clientId) {
      const client = ClientService.getClientById(clientId);
      if (client) {
        setSelectedClient(client);
        prefillFromClient(client);
      }
    } else {
      setSelectedClient(null);
      clearClientData();
    }
  };

  const prefillFromClient = (client) => {
    setFormData(prev => ({
      ...prev,
      sender: {
        name: client.personalInfo.fullName,
        phone: client.personalInfo.phone,
        address: client.contactInfo.primaryAddress.street + ', ' + 
                 client.contactInfo.primaryAddress.city + ', ' + 
                 client.contactInfo.primaryAddress.state,
        email: client.personalInfo.email
      }
    }));
  };

  const clearClientData = () => {
    setFormData(prev => ({
      ...prev,
      sender: {
        name: '',
        phone: '',
        address: '',
        email: ''
      }
    }));
  };

  const toggleClientMode = () => {
    setUseExistingClient(!useExistingClient);
    if (!useExistingClient) {
      // Cambiar a modo cliente existente
      setFormData(prev => ({ ...prev, clientId: null }));
      setSelectedClient(null);
      clearClientData();
    } else {
      // Cambiar a modo cliente nuevo
      setFormData(prev => ({ ...prev, clientId: null }));
      setSelectedClient(null);
    }
  };

  const handleInputChange = (section, field, value) => {
    if (section === 'dimensions') {
      setFormData(prev => ({
        ...prev,
        packageDetails: {
          ...prev.packageDetails,
          dimensions: {
            ...prev.packageDetails.dimensions,
            [field]: value
          }
        }
      }));
    } else if (section) {
      setFormData(prev => ({
        ...prev,
        [section]: {
          ...prev[section],
          [field]: value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: value
      }));
    }

    // Limpiar error del campo cuando el usuario comience a escribir
    if (errors[`${section}.${field}`] || errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[`${section}.${field}`];
        delete newErrors[field];
        return newErrors;
      });
    }

    // Auto-calcular fecha estimada cuando cambie la prioridad
    if (section === 'packageDetails' && field === 'priority') {
      calculateEstimatedDelivery(value);
    }

    // Auto-calcular costo cuando cambien dimensiones o peso
    if ((section === 'packageDetails' && ['weight'].includes(field)) || 
        (section === 'dimensions' && ['length', 'width', 'height'].includes(field))) {
      calculateCost();
    }
  };

  const calculateEstimatedDelivery = (priority) => {
    const estimated = PackageService.calculateEstimatedDelivery(priority);
    const dateString = new Date(estimated).toISOString().split('T')[0];
    setFormData(prev => ({
      ...prev,
      estimated_delivery: dateString
    }));
  };

  const calculateCost = () => {
    setTimeout(() => {
      const { weight, dimensions } = formData.packageDetails;
      const { priority } = formData.packageDetails;
      
      if (weight && dimensions.length && dimensions.width && dimensions.height) {
        // Cálculo básico de costo
        const volumeWeight = (dimensions.length * dimensions.width * dimensions.height) / 5000; // kg volumétrico
        const billableWeight = Math.max(parseFloat(weight), volumeWeight);
        
        let baseCost = billableWeight * 2.5; // $2.5 por kg
        
        // Ajuste por prioridad
        const priorityMultiplier = {
          normal: 1,
          urgent: 1.5,
          express: 2
        };
        
        baseCost *= priorityMultiplier[priority] || 1;
        
        // Aplicar descuento del cliente si existe
        if (selectedClient && selectedClient.discount > 0) {
          const discount = selectedClient.discount / 100;
          baseCost = baseCost * (1 - discount);
        }
        
        setFormData(prev => ({
          ...prev,
          cost: Math.ceil(baseCost).toString()
        }));
      }
    }, 100);
  };

  const validateForm = () => {
    const newErrors = {};

    // Validar remitente
    if (!formData.sender.name.trim()) {
      newErrors['sender.name'] = 'El nombre del remitente es requerido';
    }
    if (!formData.sender.phone.trim()) {
      newErrors['sender.phone'] = 'El teléfono del remitente es requerido';
    }
    if (!formData.sender.address.trim()) {
      newErrors['sender.address'] = 'La dirección del remitente es requerida';
    }

    // Validar destinatario
    if (!formData.recipient.name.trim()) {
      newErrors['recipient.name'] = 'El nombre del destinatario es requerido';
    }
    if (!formData.recipient.phone.trim()) {
      newErrors['recipient.phone'] = 'El teléfono del destinatario es requerido';
    }
    if (!formData.recipient.address.trim()) {
      newErrors['recipient.address'] = 'La dirección del destinatario es requerida';
    }

    // Validar detalles del paquete
    if (!formData.packageDetails.description.trim()) {
      newErrors['packageDetails.description'] = 'La descripción es requerida';
    }
    if (!formData.packageDetails.weight || formData.packageDetails.weight <= 0) {
      newErrors['packageDetails.weight'] = 'El peso debe ser mayor a 0';
    }
    if (!formData.packageDetails.dimensions.length || formData.packageDetails.dimensions.length <= 0) {
      newErrors['packageDetails.dimensions.length'] = 'El largo debe ser mayor a 0';
    }
    if (!formData.packageDetails.dimensions.width || formData.packageDetails.dimensions.width <= 0) {
      newErrors['packageDetails.dimensions.width'] = 'El ancho debe ser mayor a 0';
    }
    if (!formData.packageDetails.dimensions.height || formData.packageDetails.dimensions.height <= 0) {
      newErrors['packageDetails.dimensions.height'] = 'El alto debe ser mayor a 0';
    }
    if (!formData.cost || formData.cost <= 0) {
      newErrors['cost'] = 'El costo debe ser mayor a 0';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      // Preparar datos para el servicio
      const packageData = {
        ...formData,
        packageDetails: {
          ...formData.packageDetails,
          weight: parseFloat(formData.packageDetails.weight),
          dimensions: {
            length: parseFloat(formData.packageDetails.dimensions.length),
            width: parseFloat(formData.packageDetails.dimensions.width),
            height: parseFloat(formData.packageDetails.dimensions.height)
          },
          value: formData.packageDetails.value ? parseFloat(formData.packageDetails.value) : 0
        },
        cost: parseFloat(formData.cost),
        estimated_delivery: new Date(formData.estimated_delivery).toISOString()
      };

      let savedPackage;
      if (isEditing) {
        savedPackage = await PackageService.updatePackage(packageId, packageData);
      } else {
        savedPackage = await PackageService.createPackage(packageData);
      }

      // Si hay cliente asociado, vincularlo y actualizar estadísticas
      if (formData.clientId && savedPackage) {
        try {
          await ClientService.linkPackageToClient(savedPackage.id, formData.clientId);
        } catch (error) {
          console.error('Error linking package to client:', error);
          // No bloquear el guardado por este error
        }
      }

      onSave();
    } catch (error) {
      console.error('Error saving package:', error);
      alert('Error al guardar el paquete');
    } finally {
      setLoading(false);
    }
  };

  const getFieldError = (field) => {
    return errors[field] ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : 'border-gray-300 focus:ring-blue-500 focus:border-blue-500';
  };

  return (
    <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg">
      <div className="px-6 py-4 border-b border-gray-200">
        <h2 className="text-xl font-semibold text-gray-900">
          {isEditing ? 'Editar Paquete' : 'Crear Nuevo Paquete'}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-8">
        {/* Selección de Cliente */}
        <div className="bg-purple-50 p-4 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-gray-900 flex items-center">
              <Users className="h-5 w-5 mr-2 text-purple-600" />
              Cliente
            </h3>
            <label className="flex items-center">
              <input
                type="checkbox"
                className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                checked={useExistingClient}
                onChange={toggleClientMode}
              />
              <span className="ml-2 text-sm text-gray-700">Usar cliente existente</span>
            </label>
          </div>

          {useExistingClient ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Seleccionar Cliente
                </label>
                <div className="flex space-x-2">
                  <select
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500"
                    value={formData.clientId || ''}
                    onChange={(e) => handleClientChange(e.target.value)}
                  >
                    <option value="">Seleccionar cliente...</option>
                    {clients.map((client) => (
                      <option key={client.value} value={client.value}>
                        {client.label}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    className="px-3 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 flex items-center"
                    title="Crear nuevo cliente"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {selectedClient && (
                <div className="bg-white rounded-lg p-4 border border-purple-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-900">{selectedClient.label}</p>
                      <p className="text-sm text-gray-500">{selectedClient.email}</p>
                      {selectedClient.discount > 0 && (
                        <p className="text-sm text-green-600 font-medium">
                          Descuento aplicado: {selectedClient.discount}%
                        </p>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                        Cliente Registrado
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white rounded-lg p-4 border border-purple-200">
              <p className="text-sm text-gray-600">
                <span className="font-medium">Modo cliente nuevo:</span> Los datos del remitente se usarán para crear un nuevo registro de cliente automáticamente.
              </p>
            </div>
          )}
        </div>
        {/* Información del Remitente */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <User className="h-5 w-5 mr-2 text-blue-600" />
            Información del Remitente
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nombre Completo *
              </label>
              <input
                type="text"
                className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('sender.name')}`}
                value={formData.sender.name}
                onChange={(e) => handleInputChange('sender', 'name', e.target.value)}
                placeholder="Nombre del remitente"
              />
              {errors['sender.name'] && (
                <p className="mt-1 text-sm text-red-600">{errors['sender.name']}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Teléfono *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="tel"
                  className={`w-full pl-10 pr-3 py-2 border rounded-md focus:ring-2 ${getFieldError('sender.phone')}`}
                  value={formData.sender.phone}
                  onChange={(e) => handleInputChange('sender', 'phone', e.target.value)}
                  placeholder="8888-8888"
                />
              </div>
              {errors['sender.phone'] && (
                <p className="mt-1 text-sm text-red-600">{errors['sender.phone']}</p>
              )}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Dirección *
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <textarea
                  className={`w-full pl-10 pr-3 py-2 border rounded-md focus:ring-2 ${getFieldError('sender.address')}`}
                  rows="2"
                  value={formData.sender.address}
                  onChange={(e) => handleInputChange('sender', 'address', e.target.value)}
                  placeholder="Dirección completa del remitente"
                />
              </div>
              {errors['sender.address'] && (
                <p className="mt-1 text-sm text-red-600">{errors['sender.address']}</p>
              )}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email (Opcional)
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="email"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={formData.sender.email}
                  onChange={(e) => handleInputChange('sender', 'email', e.target.value)}
                  placeholder="email@ejemplo.com"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Información del Destinatario */}
        <div className="bg-green-50 p-4 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <MapPin className="h-5 w-5 mr-2 text-green-600" />
            Información del Destinatario
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nombre Completo *
              </label>
              <input
                type="text"
                className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('recipient.name')}`}
                value={formData.recipient.name}
                onChange={(e) => handleInputChange('recipient', 'name', e.target.value)}
                placeholder="Nombre del destinatario"
              />
              {errors['recipient.name'] && (
                <p className="mt-1 text-sm text-red-600">{errors['recipient.name']}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Teléfono *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="tel"
                  className={`w-full pl-10 pr-3 py-2 border rounded-md focus:ring-2 ${getFieldError('recipient.phone')}`}
                  value={formData.recipient.phone}
                  onChange={(e) => handleInputChange('recipient', 'phone', e.target.value)}
                  placeholder="8888-8888"
                />
              </div>
              {errors['recipient.phone'] && (
                <p className="mt-1 text-sm text-red-600">{errors['recipient.phone']}</p>
              )}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Dirección *
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <textarea
                  className={`w-full pl-10 pr-3 py-2 border rounded-md focus:ring-2 ${getFieldError('recipient.address')}`}
                  rows="2"
                  value={formData.recipient.address}
                  onChange={(e) => handleInputChange('recipient', 'address', e.target.value)}
                  placeholder="Dirección completa del destinatario"
                />
              </div>
              {errors['recipient.address'] && (
                <p className="mt-1 text-sm text-red-600">{errors['recipient.address']}</p>
              )}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Email (Opcional)
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="email"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={formData.recipient.email}
                  onChange={(e) => handleInputChange('recipient', 'email', e.target.value)}
                  placeholder="email@ejemplo.com"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Detalles del Paquete */}
        <div className="bg-orange-50 p-4 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <PackageIcon className="h-5 w-5 mr-2 text-orange-600" />
            Detalles del Paquete
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Descripción del Contenido *
              </label>
              <input
                type="text"
                className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('packageDetails.description')}`}
                value={formData.packageDetails.description}
                onChange={(e) => handleInputChange('packageDetails', 'description', e.target.value)}
                placeholder="Ej: Documentos, electrónicos, ropa, etc."
              />
              {errors['packageDetails.description'] && (
                <p className="mt-1 text-sm text-red-600">{errors['packageDetails.description']}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Peso (kg) *
              </label>
              <input
                type="number"
                step="0.1"
                min="0.1"
                className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('packageDetails.weight')}`}
                value={formData.packageDetails.weight}
                onChange={(e) => handleInputChange('packageDetails', 'weight', e.target.value)}
                placeholder="0.5"
              />
              {errors['packageDetails.weight'] && (
                <p className="mt-1 text-sm text-red-600">{errors['packageDetails.weight']}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Valor Declarado ($)
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="number"
                  min="0"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={formData.packageDetails.value}
                  onChange={(e) => handleInputChange('packageDetails', 'value', e.target.value)}
                  placeholder="100"
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Dimensiones (cm) *
              </label>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <input
                    type="number"
                    min="1"
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('packageDetails.dimensions.length')}`}
                    value={formData.packageDetails.dimensions.length}
                    onChange={(e) => handleInputChange('dimensions', 'length', e.target.value)}
                    placeholder="Largo"
                  />
                  {errors['packageDetails.dimensions.length'] && (
                    <p className="mt-1 text-xs text-red-600">{errors['packageDetails.dimensions.length']}</p>
                  )}
                </div>
                <div>
                  <input
                    type="number"
                    min="1"
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('packageDetails.dimensions.width')}`}
                    value={formData.packageDetails.dimensions.width}
                    onChange={(e) => handleInputChange('dimensions', 'width', e.target.value)}
                    placeholder="Ancho"
                  />
                  {errors['packageDetails.dimensions.width'] && (
                    <p className="mt-1 text-xs text-red-600">{errors['packageDetails.dimensions.width']}</p>
                  )}
                </div>
                <div>
                  <input
                    type="number"
                    min="1"
                    className={`w-full px-3 py-2 border rounded-md focus:ring-2 ${getFieldError('packageDetails.dimensions.height')}`}
                    value={formData.packageDetails.dimensions.height}
                    onChange={(e) => handleInputChange('dimensions', 'height', e.target.value)}
                    placeholder="Alto"
                  />
                  {errors['packageDetails.dimensions.height'] && (
                    <p className="mt-1 text-xs text-red-600">{errors['packageDetails.dimensions.height']}</p>
                  )}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prioridad *
              </label>
              <select
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={formData.packageDetails.priority}
                onChange={(e) => handleInputChange('packageDetails', 'priority', e.target.value)}
              >
                <option value="normal">Normal (3 días)</option>
                <option value="urgent">Urgente (2 días)</option>
                <option value="express">Express (1 día)</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fecha Estimada de Entrega *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="date"
                  className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  value={formData.estimated_delivery}
                  onChange={(e) => handleInputChange(null, 'estimated_delivery', e.target.value)}
                />
              </div>
            </div>

            <div className="md:col-span-2">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="fragile"
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  checked={formData.packageDetails.fragile}
                  onChange={(e) => handleInputChange('packageDetails', 'fragile', e.target.checked)}
                />
                <label htmlFor="fragile" className="ml-2 text-sm text-gray-700 flex items-center">
                  <AlertTriangle className="h-4 w-4 mr-1 text-yellow-600" />
                  Paquete frágil (requiere manejo especial)
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Costo y Notas */}
        <div className="bg-purple-50 p-4 rounded-lg">
          <h3 className="text-lg font-medium text-gray-900 mb-4 flex items-center">
            <DollarSign className="h-5 w-5 mr-2 text-purple-600" />
            Costo y Notas
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Costo de Envío ($) *
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  className={`w-full pl-10 pr-3 py-2 border rounded-md focus:ring-2 ${getFieldError('cost')}`}
                  value={formData.cost}
                  onChange={(e) => handleInputChange(null, 'cost', e.target.value)}
                  placeholder="25.00"
                />
              </div>
              {errors['cost'] && (
                <p className="mt-1 text-sm text-red-600">{errors['cost']}</p>
              )}
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Notas Adicionales
              </label>
              <textarea
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                rows="3"
                value={formData.notes}
                onChange={(e) => handleInputChange(null, 'notes', e.target.value)}
                placeholder="Instrucciones especiales, horarios de entrega, etc."
              />
            </div>
          </div>
        </div>

        {/* Botones de acción */}
        <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
          <button
            type="button"
            onClick={onCancel}
            className="px-6 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 flex items-center"
          >
            <X className="h-4 w-4 mr-2" />
            Cancelar
          </button>
          
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 flex items-center"
          >
            {loading ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            {isEditing ? 'Actualizar Paquete' : 'Crear Paquete'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PackageForm;