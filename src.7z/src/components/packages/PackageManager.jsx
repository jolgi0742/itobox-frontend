// components/packages/PackageManager.jsx
import React, { useState } from 'react';
import PackageList from './PackageList';
import PackageForm from './PackageForm';
import PackageDetails from './PackageDetails';

const PackageManager = () => {
  const [currentView, setCurrentView] = useState('list'); // 'list', 'create', 'edit', 'details'
  const [selectedPackageId, setSelectedPackageId] = useState(null);

  const handleCreatePackage = () => {
    setCurrentView('create');
    setSelectedPackageId(null);
  };

  const handleEditPackage = (packageId) => {
    setCurrentView('edit');
    setSelectedPackageId(packageId);
  };

  const handleViewPackage = (packageId) => {
    setCurrentView('details');
    setSelectedPackageId(packageId);
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedPackageId(null);
  };

  const handleSaveSuccess = () => {
    setCurrentView('list');
    setSelectedPackageId(null);
  };

  const renderCurrentView = () => {
    switch (currentView) {
      case 'create':
        return (
          <PackageForm
            onSave={handleSaveSuccess}
            onCancel={handleBackToList}
          />
        );
      
      case 'edit':
        return (
          <PackageForm
            packageId={selectedPackageId}
            onSave={handleSaveSuccess}
            onCancel={handleBackToList}
          />
        );
      
      case 'details':
        return (
          <PackageDetails
            packageId={selectedPackageId}
            onEdit={handleEditPackage}
            onBack={handleBackToList}
          />
        );
      
      default:
        return (
          <PackageList
            onCreatePackage={handleCreatePackage}
            onEditPackage={handleEditPackage}
            onViewPackage={handleViewPackage}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <div className="md:flex md:items-center md:justify-between">
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                {currentView === 'create' && 'Crear Nuevo Paquete'}
                {currentView === 'edit' && 'Editar Paquete'}
                {currentView === 'details' && 'Detalles del Paquete'}
                {currentView === 'list' && 'Gestión de Paquetes'}
              </h1>
              <p className="mt-1 text-sm text-gray-500">
                {currentView === 'list' && 'Administra todos los paquetes de ITOBOX Courier'}
                {(currentView === 'create' || currentView === 'edit') && 'Completa la información del paquete'}
                {currentView === 'details' && 'Información completa y tracking del paquete'}
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        {renderCurrentView()}
      </div>
    </div>
  );
};

export default PackageManager;